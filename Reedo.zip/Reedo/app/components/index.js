import DictionaryItem from './DictionaryItem/DictionaryItem';
import PhaseDetailItem from './PhaseDetailItem/PhaseDetailItem';
import PhaseItem from './PhaseItem/PhaseItemView';
import RootHeader from './RootHeader/RootHeaderView';
import LessonItem from './LessonItem/LessonItemView';
import ChooseQuestion from './ChooseQuestion/ChooseQuestionView';
import Progress from './Progress/ProgressView';

export default {
    DictionaryItem,
    PhaseDetailItem,
    PhaseItem,
    RootHeader,
    LessonItem,
    Progress,
    ChooseQuestion
};
