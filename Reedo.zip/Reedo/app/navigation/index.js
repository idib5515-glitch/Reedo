import React, { Component } from 'react';
import RootNavigation from './RootNavigation';
import NavigationService from './NavigationService';

class AppNavigator extends Component {
    render() {
        return (
            <RootNavigation
                ref={navigatorRef => {
                    NavigationService.setTopLevelNavigator(navigatorRef);
                }}
            />
        );
    }
}

export default AppNavigator;
