import { createStackNavigator } from 'react-navigation';

import Lessons from '../screens/Lessons';

const LessonsNavigation = createStackNavigator({
    LessonsList: {
        screen: Lessons
    }
});

export default Lessons;
