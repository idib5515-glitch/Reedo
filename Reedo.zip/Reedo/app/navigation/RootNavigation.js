import React from 'react';
import {
    createBottomTabNavigator,
    createAppContainer,
    createStackNavigator
} from 'react-navigation';
import Ionicons from 'react-native-vector-icons/Ionicons';

import Phrases from '../screens/Phrases';
import Dictionary from '../screens/Dictionary';
import Favorites from '../screens/Favorites';
import PhaseDetail from '../screens/PhraseDetail';
import LessonsNavigation from './LessonsNavigation';
import DictionaryItemDetail from '../screens/DictionaryItemDetail';
import LessonDetail from '../screens/LessonDetail';

const MainTabNavigation = createBottomTabNavigator(
    {
        Phrases: {
            screen: Phrases
        },
        Dictionary: {
            screen: Dictionary
        },
        Lessons: {
            screen: LessonsNavigation
        },
        Favorites: {
            screen: Favorites
        }
    },
    {
        initialRouteName: 'Phrases',
        defaultNavigationOptions: ({ navigation }) => ({
            tabBarIcon: ({ focused, horizontal, tintColor }) => {
                const { routeName } = navigation.state;
                let IconComponent = Ionicons;
                let iconName;
                switch (routeName) {
                    case 'Phrases':
                        iconName = 'ios-home';
                        break;
                    case 'Dictionary':
                        iconName = 'ios-apps';
                        break;
                    case 'Favorites':
                        iconName = 'ios-cart';
                        break;
                    case 'Lessons':
                        iconName = 'ios-book';
                    default:
                        break;
                }

                return (
                    <IconComponent
                        name={iconName}
                        color={tintColor}
                        size={22}
                    />
                );
            }
        })
    }
);

const RootNavigation = createStackNavigator(
    {
        MainTabNavigation: {
            screen: MainTabNavigation,
            navigationOptions: { header: null }
        },
        PhaseDetail: {
            screen: PhaseDetail,
            navigationOptions: { header: null }
        },
        DictionaryItemDetail: {
            screen: DictionaryItemDetail
        },
        LessonDetail: {
            screen: LessonDetail
        }
    },
    {
        initialRouteName: 'MainTabNavigation'
    }
);

export default createAppContainer(RootNavigation);
