/* App config for images
 */
const images = {
    icons: {
        //logo: require('../assets/images/icons/logo.png'),
        noData: require('../assets/img/no-data.png')
    },
    phases: {
        accomodation: require('../assets/img/accomodation.jpg'),
        animals: require('../assets/img/animals.jpg'),
        colors: require('../assets/img/colors.jpeg'),
        common: require('../assets/img/common.png'),
        date: require('../assets/img/date.jpg'),
        directions: require('../assets/img/directions.jpg'),
        eat: require('../assets/img/eat.jpg'),
        emergency: require('../assets/img/emergency.png'),
        greeting: require('../assets/img/greeting.jpg'),
        health: require('../assets/img/health.png'),
        numbers: require('../assets/img/numbers.jpg'),
        romance: require('../assets/img/romance.jpg'),
        shoping: require('../assets/img/shoping.jpg'),
        time: require('../assets/img/time.jpg'),
        transportation: require('../assets/img/transportation.jpg'),
        weather: require('../assets/img/weather.jpg')
    },
    lessons: {
        cardImage: require('../assets/img/exclusive.jpg'),
        cat: require('../assets/img/cat.jpg'),
        man: require('../assets/img/man.jpeg'),
        sentence: require('../assets/img/sentence.jpg'),
        naming: require('../assets/img/naming.jpg'),
        grammar: require('../assets/img/grammar.jpeg')
    }
};

export default images;
