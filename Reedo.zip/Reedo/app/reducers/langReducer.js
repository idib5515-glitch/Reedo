/**
 * Loading reducer made seperate for easy blacklisting
 * Avoid data persist
 */
import createReducer from 'app/lib/createReducer';
import * as types from '../actions/types';

const initialState = {
    lang: 'am'
};

export const langReducer = createReducer(initialState, {
    [types.SET_LANG](state, action) {
        return { ...state, lang: action.lang };
    }
});
