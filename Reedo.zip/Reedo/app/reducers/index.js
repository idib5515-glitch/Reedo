/*
 * combines all th existing reducers
 */
import * as loadingReducer from './loadingReducer';
import * as loginReducer from './loginReducer';
import * as dataReducer from './dataReducer';
import * as favoriteReducer from './favoriteReducer';
import * as langReducer from './langReducer';

export default Object.assign(
    loginReducer,
    loadingReducer,
    dataReducer,
    langReducer,
    favoriteReducer
);
