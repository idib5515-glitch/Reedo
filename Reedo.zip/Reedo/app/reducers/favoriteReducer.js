/**
 * Loading reducer made seperate for easy blacklisting
 * Avoid data persist
 */
import createReducer from 'app/lib/createReducer';
import * as types from '../actions/types';

const initialState = {
    favorites: []
};

export const favoriteReducer = createReducer(initialState, {
    [types.MAKE_FAVORITE](state, action) {
        console.log(action.item);

        let tempFavorites = state.favorites;
        const isItemFound = tempFavorites.find(
            word => word.id === action.item.id
        );
        if (isItemFound) {
            tempFavorites.splice(tempFavorites.indexOf(action.item), 1);
        } else {
            tempFavorites.push(action.item);
        }
        return { ...state };
    }
});
