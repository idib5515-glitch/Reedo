/**
 * Loading reducer made seperate for easy blacklisting
 * Avoid data persist
 */
import createReducer from 'app/lib/createReducer';
import * as types from '../actions/types';

const initialState = {
    data: []
};

export const dataReducer = createReducer(initialState, {
    [types.LOAD_DATA_RESPONSE](state, action) {
        return { ...state, data: action.data };
    },
    [types.ALTER_DATA](state, action) {
        return { ...state, data: action.data };
    }
});
