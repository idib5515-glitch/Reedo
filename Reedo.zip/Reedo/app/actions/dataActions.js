import * as types from './types';

export const loadData = () => ({
    type: types.LOAD_DATA_REQUEST
});

export const handleLoadingDataSuccess = data => ({
    type: types.LOAD_DATA_RESPONSE,
    data
});

export const handleLoadingDataFailed = () => ({
    type: types.LOAD_DATA_FAILED
});

export const alterData = data => ({
    type: types.ALTER_DATA,
    data
});
