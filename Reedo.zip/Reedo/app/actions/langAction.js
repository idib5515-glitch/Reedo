import * as types from './types';

export const setLanguage = lang => ({
    type: types.SET_LANG,
    lang
});
