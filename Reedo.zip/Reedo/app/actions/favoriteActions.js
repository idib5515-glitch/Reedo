import * as types from './types';

export const makeItemFavorite = item => ({
    type: types.MAKE_FAVORITE,
    item
});
