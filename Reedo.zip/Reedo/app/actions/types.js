//loaders
export const LOGIN_ENABLE_LOADER = 'LOGIN_ENABLE_LOADER';
export const LOGIN_DISABLE_LOADER = 'LOGIN_DISABLE_LOADER';

// login
export const LOGIN_REQUEST = 'LOGIN_REQUEST';
export const LOGIN_RESPONSE = 'LOGIN_RESPONSE';
export const LOGIN_FAILED = 'LOGIN_FAILED';

// loading data
export const LOAD_DATA_REQUEST = 'LOAD_DATA_REQUEST';
export const LOAD_DATA_RESPONSE = 'LOAD_DATA_RESPONSE';
export const LOAD_DATA_FAILED = 'LOAD_DATA_FAILED';
export const ALTER_DATA = 'ALTER_DATA';

// Favorites
export const MAKE_FAVORITE = 'MAKE_FAVORITE';

// lang
export const SET_LANG = 'SET_LANG';
