const data = [
    {
        'id': 1,
        word_AF: 'yeey',
        word_ENG: 'yes',
        word_AM: ' አወ',
        category: 'common',
        audioFile: require('./audio/yeey.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        'id': 2,
        word_AF: 'gadda gey',
        word_ENG: 'Thank you',
        word_AM: 'አመሰግናለሁ',
        category: 'common',
        audioFile: require('./audio/gadda-gey.m4a')
    },
    {
        'id': 3,
        word_AF: 'maganey',
        word_ENG: 'Please',
        word_AM: 'እባክህ',
        category: 'common',
        audioFile: require('./audio/maganey.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: ''
    },
    {
        id: 4,
        word_AF: 'qafu ab',
        word_ENG: 'Excuse me',
        word_AM: 'ይቅርታ',
        category: 'common',
        audioFile: require('./audio/qafu-ab.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: ''
    },
    {
        id: 5,
        word_AF: 'maaxiga',
        word_ENG: 'I don\'t know',
        word_AM: ' አላውቅም',
        category: 'common',
        audioFile: require('./audio/maaxiga.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 6,
        word_AF: 'nagaleela',
        word_ENG: 'How are you',
        word_AM: 'እንዴት ናችሁ',
        category: 'greeting',
        audioFile: require('./audio/nagaleela.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 7,
        word_AF: 'wagarileela',
        word_ENG: 'I am fine.',
        word_AM: 'ደህና ነኝ',
        category: 'greeting',
        audioFile: require('./audio/wagrileela.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 8,
        word_AF: 'macisse',
        word_ENG: 'Good morning',
        word_AM: 'እንደምን አደራችሁ',
        category: 'greeting',
        audioFile: require('./audio/maacisse.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 9,
        word_AF: 'nagasse',
        word_ENG: 'Good afternoon',
        word_AM: 'እንደምን ዋላችሁ',
        category: 'greeting',
        audioFile: require('./audio/nagasse.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 10,
        word_AF: 'nagay kassoyte',
        word_ENG: 'Good evening',
        word_AM: 'እንደምን አመሻችሁ',
        category: 'greeting',
        audioFile: require('./audio/nagay-kassowtee.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 11,
        word_AF: 'cato',
        word_ENG: 'help',
        word_AM: 'እርዳታ',
        category: 'emergency',
        audioFile: require('./audio/cato.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 12,
        word_AF: 'gira',
        word_ENG: 'fire',
        word_AM: ' እሳት',
        category: 'emergency',
        audioFile: require('./audio/gira.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 13,
        word_AF: 'garqa',
        word_ENG: 'thief',
        word_AM: 'ሌባ',
        category: 'emergency',
        audioFile: require('./audio/garqa.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 14,
        word_AF: 'poolise hay (seec)',
        word_ENG: 'call to police',
        word_AM: 'ለፖሊስ ደዉል',
        category: 'emergency',
        audioFile: require('./audio/gira.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 15,
        word_AF: 'daylaabe fan gex  ',
        word_ENG: 'go to doctor',
        word_AM: 'ወደ ሃኪም ሂድ',
        category: 'emergency',
        audioFile: require('./audio/daylabe-fan-gex.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 16,
        word_AF: 'rihim teh tani?',
        word_ENG: 'are you married?',
        word_AM: ' አግብታሃል(ሻል)?',
        category: 'romance',
        audioFile: require('./audio/rihimteh-tani.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 17,
        word_AF: 'koo kaciyyoh',
        word_ENG: 'I love you',
        word_AM: 'እወድሃለሁ',
        category: 'romance',
        audioFile: require('./audio/gira.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 18,
        word_AF: 'tikket ankel xaamah',
        word_ENG: 'Where can I buy ticket?',
        word_AM: 'ትኬት የሚገዛው የት ነው?',
        category: 'transportation',
        audioFile: require('./audio/tekket-ankel-xaamaah.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 20,
        word_AF: 'atu gexenta',
        word_ENG: 'are you a passenger?',
        word_AM: 'ተሳፋሪ ነህ?',
        category: 'transportation',
        audioFile: require('./audio/atu-gexenta.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 21,
        word_AF: 'gabbi',
        word_ENG: 'South',
        word_AM: 'ደቡብ',
        category: 'directions',
        audioFile: require('./audio/gabbi.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 22,
        word_AF: 'kilbata',
        word_ENG: 'North',
        word_AM: 'ሰሜን',
        category: 'directions',
        audioFile: require('./audio/kilbata.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 23,
        word_AF: 'carra',
        word_ENG: 'West',
        word_AM: 'ምዕራብ',
        category: 'directions',
        audioFile: require('./audio/carra.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 233,
        word_AF: 'ayro\'mawqa',
        word_ENG: 'East',
        word_AM: 'ምስራቅ',
        category: 'directions',
        audioFile: require('./audio/ayrommawqa.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 24,
        word_AF: 'ayro mawqa fan gex ',
        word_ENG: 'Go to east',
        word_AM: 'ወደ ምሰራቅ ሂድ',
        category: 'directions',
        audioFile: require('./audio/ayro-mawqa-fan-gex.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 25,
        word_AF: 'qeero kalo(kuraaqa) ',
        word_ENG: 'Breakfast',
        word_AM: 'ቁርስ',
        category: 'eating',
        audioFile: require('./audio/qeero-kalo.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 266,
        word_AF: 'mayo',
        word_ENG: 'Lunch',
        word_AM: 'ምሳ እራት',
        category: 'eating',
        audioFile: require('./audio/gira.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 26,
        word_AF: 'diraara',
        word_ENG: 'Dinner',
        word_AM: 'እራት',
        category: 'eating',
        audioFile: require('./audio/Diraari.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 27,
        word_AF: 'iniki',
        word_ENG: 'One',
        word_AM: 'አንድ',
        category: 'numbers',
        audioFile: require('./audio/1-iniki.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 28,
        word_AF: 'nammay',
        word_ENG: 'Two',
        word_AM: 'ሁለት',
        category: 'numbers',
        audioFile: require('./audio/2-nammaya.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 29,
        word_AF: 'sidocu',
        word_ENG: 'Three',
        word_AM: 'ሶስት',
        category: 'numbers',
        audioFile: require('./audio/3-sidiicoyu.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 30,
        word_AF: 'fereeyi',
        word_ENG: 'Four',
        word_AM: 'አራት',
        category: 'numbers',
        audioFile: require('./audio/4-fereeyi.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 31,
        word_AF: 'konooyu',
        word_ENG: 'Five',
        word_AM: 'አምስት',
        category: 'numbers',
        audioFile: require('./audio/5-konooyu.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 32,
        word_AF: 'boolu',
        word_ENG: 'Hundred',
        word_AM: 'መቶ',
        category: 'numbers',
        audioFile: require('./audio/100-boolu.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 321,
        word_AF: 'alfi',
        word_ENG: 'Thousand',
        word_AM: 'ሺ',
        category: 'numbers',
        audioFile: require('./audio/1000-alfi.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: false
    },
    {
        id: 33,
        word_AF: 'Adda',
        word_ENG: 'Depth',
        word_AM: 'ጥልቀት',
        audioFile: require('./audio/gira.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: true,
        synonyms: [],
        antonyms: [],
        defination: 'gubal tan akkiy (gammik teenal culma akki)'
    },
    {
        id: 34,
        word_AF: 'Afkan',
        word_ENG: 'Directions',
        word_AM: 'አቅጣጫ',
        audioFile: require('./audio/gira.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: true,
        synonyms: [],
        antonyms: [],
        defination: 'qaxakteen yakke ascossa'
    },
    {
        id: 35,
        word_AF: 'Baada',
        word_ENG: 'World',
        word_AM: 'አለም',
        audioFile: require('./audio/gira.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: true,
        synonyms: [],
        antonyms: [],
        defination: 'inkih tan  gallil tan baaxo'
    },
    {
        id: 36,
        word_AF: 'Baacat(gayya)',
        word_ENG: 'Ocean',
        word_AM: 'ውቅያኖስ',
        audioFile: require('./audio/gira.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: true,
        synonyms: [],
        antonyms: [],
        defination: 'kaxxa bada'
    },
    {
        id: 37,
        word_AF: 'Caffali',
        word_ENG: 'Barley',
        word_AM: 'ገብስ',
        audioFile: require('./audio/gira.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: true,
        synonyms: [],
        antonyms: [],
        defination: 'buqrel taabuk sehda takme daro'
    },
    {
        id: 38,
        word_AF: 'Cusul',
        word_ENG: 'Arm',
        word_AM: 'ክንድ',
        audioFile: require('./audio/gira.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: true,
        synonyms: [],
        antonyms: [],
        defination: 'gaba elle xammaqita gabak gude'
    },
    {
        id: 39,
        word_AF: 'Daaba',
        word_ENG: 'Brow of hill',
        word_AM: 'ኮረብታ አናት',
        audioFile: require('./audio/gira.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: true,
        synonyms: [],
        antonyms: [],
        defination: 'qeley baaxok fayyae'
    },
    {
        id: 40,
        word_AF: 'Essere',
        word_ENG: 'Asked',
        word_AM: 'ጠየቁት',
        audioFile: require('./audio/gira.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: true,
        synonyms: [],
        antonyms: [],
        defination: 'tuktenah hen essero'
    },
    {
        id: 41,
        word_AF: 'Fiyeena',
        word_ENG: 'Broom',
        word_AM: 'መጥረጊያ',
        audioFile: require('./audio/gira.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: true,
        synonyms: [],
        antonyms: [],
        defination: 'tuktena edde fiyan uwwaytu'
    },
    {
        id: 42,
        word_AF: 'Gaadisiyya',
        word_ENG: 'Join',
        word_AM: 'መገጣጠም',
        audioFile: require('./audio/gira.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: true,
        synonyms: [],
        antonyms: [],
        defination: 'ittak tiggiriqqem siitak xakabaanama'
    },
    {
        id: 43,
        word_AF: 'Haasawa',
        word_ENG: 'Conversation',
        word_AM: 'ንግግር',
        audioFile: require('./audio/gira.m4a'),
        hasTryOutAudioFile: false,
        tryOutAudioFile: '',
        isInDictionary: true,
        synonyms: [],
        antonyms: [],
        defination: 'nammanumakkiiy wohuuk daga yakke mari ittalluk aba yaba'
    },

    {
        "id": 432,
        "word_AF": "namma-kabi ittengeyi",
        "word_ENG": "bilateral agreement",
        "word_AM": "ሁለትዮሽ ስምምነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "namma kaabi ittin waya"
        ],
        "defination": "namma marih fanat   yakkeh yan  ittin geyi"
    },
    {
        "id": 474,
        "word_AF": "doodle abto",
        "word_ENG": "legal action",
        "word_AM": "ህጋዊ ድርጊት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "dood sinni  abto"
        ],
        "defination": "madaqal takke abto"
    },
    {
        "id": 516,
        "word_AF": "cisaabisê cate",
        "word_ENG": "acoutant's assistant",
        "word_AM": "ሂሣብ መዝገብ ያዥረዳት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": "cisaabise qoklah yan numu"
    },
    {
        "id": 558,
        "word_AF": "madqâ maysaraaraca",
        "word_ENG": "amendment of law",
        "word_AM": "ህግን ማሻሻል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "madqa baysa"
        ],
        "defination": "madqa missoosaanama"
    },
    {
        "id": 600,
        "word_AF": "doolat madqah maysaraaraca",
        "word_ENG": "amendment of conustitution",
        "word_AM": "ህገ መንግስትን ማሻሻል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": "doolat madqah maysaasa"
    },
    {
        "id": 642,
        "word_AF": "kullimih aman tisso",
        "word_ENG": "comprehensive  insurant",
        "word_AM": "ሁሉም አቀፍ ዋስትና ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "kulliimih xakak sinna"
        ],
        "defination": "inkih yan marih aman daccarisimaama"
    },
    {
        "id": 684,
        "word_AF": "qande",
        "word_ENG": "army",
        "word_AM": "ሀይል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "gabqasa"
        ],
        "defination": "tikya lee gaadu"
    },
    {
        "id": 726,
        "word_AF": "welu",
        "word_ENG": "aspect",
        "word_AM": "ሁኔታ አሰራር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": "tulle takkenna"
    },
    {
        "id": 768,
        "word_AF": "cawal abtoh waddiroowo",
        "word_ENG": "retroactive pay ",
        "word_AM": "ሁዋላ ክፍያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 810,
        "word_AF": "madqâ maasayya",
        "word_ENG": "article(law)",
        "word_AM": "ህገ አንቀጽ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": "madqa elle daabintekke"
    },
    {
        "id": 852,
        "word_AF": "kitoobâ mayyuq cato",
        "word_ENG": "assustance of publishing",
        "word_AM": "ህትመት እገዛ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 894,
        "word_AF": "mabla",
        "word_ENG": "opinion",
        "word_AM": "ሀሳብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": "misikical yakke akkala"
    },
    {
        "id": 936,
        "word_AF": "ayyunyti assamaqqa",
        "word_ENG": "social well being",
        "word_AM": "ህብረተሰብ ምቾት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 978,
        "word_AF": "loowô gacsa",
        "word_ENG": "balance sheet",
        "word_AM": "ሂሳብ ሚዛን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "loowo gacsa"
        ],
        "defination": "loowo ittat haanama"
    },
    {
        "id": 1020,
        "word_AF": "wadi huuri",
        "word_ENG": "life boat",
        "word_AM": "ሂይወት አንድ ጀልባ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "qidim huuri"
        ],
        "defination": "badal takke qawwalaylah catô huuri"
    },
    {
        "id": 1062,
        "word_AF": "waado le cagalentî kombani",
        "word_ENG": "limeted company",
        "word_AM": "ኀላፊነቱ የተወሰነ የግል ካምፓኒ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": "waado sinni yangalen kombaani"
    },
    {
        "id": 1104,
        "word_AF": "saseyna",
        "word_ENG": "clan destine",
        "word_AM": "ህቡዕ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "waqinal gaaceyna"
        ],
        "defination": "yam boqorreh yan ala/numu"
    },
    {
        "id": 1146,
        "word_AF": "saso",
        "word_ENG": "clan destineness",
        "word_AM": "ህቡነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "mamballaya"
        ],
        "defination": "anbooqoriyya"
    },
    {
        "id": 1188,
        "word_AF": "ittal qiku",
        "word_ENG": "coalition",
        "word_AM": "ህብረት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "baxsa"
        ],
        "defination": "inkiino"
    },
    {
        "id": 1230,
        "word_AF": "loowo",
        "word_ENG": "accounting",
        "word_AM": "ሂሣብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": "loowo sinna"
    },
    {
        "id": 1272,
        "word_AF": "tû-mabulu",
        "word_ENG": "concept",
        "word_AM": "ሀሣብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 1314,
        "word_AF": "taqziyya",
        "word_ENG": "condolences",
        "word_AM": "/የ/ሀዘን መግለጫ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": "rabeh yammaarih buxah marat aban gufne"
    },
    {
        "id": 1356,
        "word_AF": "alaaqa garwah ittingey",
        "word_ENG": "agreement relative  to  the rights of the children",
        "word_AM": "ህፃናት መብት ስምምነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 1398,
        "word_AF": "qaransimó",
        "word_ENG": "celestial or heavenitly body ",
        "word_AM": "ህዋ አካላት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 1440,
        "word_AF": "lammaya",
        "word_ENG": "couple",
        "word_AM": "ሁለት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 1482,
        "word_AF": "assacokka",
        "word_ENG": "critic",
        "word_AM": "ሂስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "assakata"
        ],
        "defination": ""
    },
    {
        "id": 1524,
        "word_AF": "ayyunyti ixxidadala",
        "word_ENG": "populition growth",
        "word_AM": "ህዝብ እድገት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "uyyuntak ixxi dagna"
        ],
        "defination": "ummattak  tammageemi"
    },
    {
        "id": 1566,
        "word_AF": "inkafa wanoona",
        "word_ENG": "un animouse decision",
        "word_AM": "ሁሉአቀፍ ዉሳኔ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 1608,
        "word_AF": "makkooka maqaadaak",
        "word_ENG": "to delibrate",
        "word_AM": "ሆነ ተብሎ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 1650,
        "word_AF": "gexsit",
        "word_ENG": "step process",
        "word_AM": "ሂደት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": "afkana"
    },
    {
        "id": 1692,
        "word_AF": "rubak nuway deesaasa",
        "word_ENG": "demography",
        "word_AM": "ህዝብ ብዛት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 1734,
        "word_AF": "atbiqiyya",
        "word_ENG": "publishing  edition",
        "word_AM": "ህትመት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 1776,
        "word_AF": "dayli barteyniti",
        "word_ENG": "medical student",
        "word_AM": "ህክምና ተማሪዎች",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": "dayli baritto kattatah yanmara"
    },
    {
        "id": 1818,
        "word_AF": "qeltut taamitiyya",
        "word_ENG": "to-go under ground",
        "word_AM": "ህቡዕ መስራት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": "sehda a,axigekal yakke abina"
    },
    {
        "id": 1860,
        "word_AF": "nammay takko walala",
        "word_ENG": "coversations of two persons",
        "word_AM": "ሁለት ሰዎች የብቻ ጭውውት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": "naamma marih fanat yakke walala"
    },
    {
        "id": 1902,
        "word_AF": "tekkooka",
        "word_ENG": "episodes",
        "word_AM": "ሁኔታዎች",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 1944,
        "word_AF": "dayli mansoofa",
        "word_ENG": "medical equipment",
        "word_AM": "ህክምና መሳሪያዎች",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": "daylah edde yantifiqen duyye"
    },
    {
        "id": 1986,
        "word_AF": "cayli qeedaala",
        "word_ENG": "balance forces",
        "word_AM": "ሀይል ሚዛን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 2028,
        "word_AF": "elmo",
        "word_ENG": "energy",
        "word_AM": "ሀይል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 2070,
        "word_AF": "sadara",
        "word_ENG": "pulbic",
        "word_AM": "ህዝብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 2112,
        "word_AF": "tuubul asscossa",
        "word_ENG": "recommidation",
        "word_AM": "ሀሣብ ማቅረብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 2154,
        "word_AF": "ummattah ixxi gacsa",
        "word_ENG": "census of the populilation",
        "word_AM": "ህዝብ ቆጠራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 2196,
        "word_AF": "mixxaaginna",
        "word_ENG": "responsibility",
        "word_AM": "ኀላፊነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "iggimaane"
        ],
        "defination": ""
    },
    {
        "id": 2238,
        "word_AF": "gadda",
        "word_ENG": "wealth",
        "word_AM": "ሀብት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "baaca"
        ],
        "defination": ""
    },
    {
        "id": 2280,
        "word_AF": "gaddali",
        "word_ENG": "  rich",
        "word_AM": "ሀብታም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "baaca li"
        ],
        "defination": "tuleh yan numu"
    },
    {
        "id": 2322,
        "word_AF": "lammey hayto rankô qaskarita",
        "word_ENG": "soldier of 2nd class",
        "word_AM": "ሁለተኛ ደረጃ ወታደር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 2364,
        "word_AF": "ayyunta",
        "word_ENG": "society",
        "word_AM": "ህብረተሠብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 2406,
        "word_AF": "ittalluk maalloyta",
        "word_ENG": "socialist",
        "word_AM": "ህብረተሠባዊ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": "sittaluk gexsitaanama"
    },
    {
        "id": 2448,
        "word_AF": "ayyuntiino",
        "word_ENG": "socialism",
        "word_AM": "ህብረተሰባዊነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "qaskaariino"
        ],
        "defination": ""
    },
    {
        "id": 2490,
        "word_AF": "ayyunti misso",
        "word_ENG": "social study",
        "word_AM": "ህብረተሰብ ሳይንስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 2532,
        "word_AF": "daylisenti ayfaafay",
        "word_ENG": "medical service",
        "word_AM": "ህክምና አገልግሎት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 2574,
        "word_AF": "umattah uguugutu",
        "word_ENG": "popular uprising",
        "word_AM": "ህዝብ አመጽ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "ummattah tibba"
        ],
        "defination": ""
    },
    {
        "id": 2616,
        "word_AF": "cisab kutbe abeyna",
        "word_ENG": "contenting",
        "word_AM": "ሂሣብ ሰራተኛ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 2658,
        "word_AF": "nammayhayto raawah baritto",
        "word_ENG": "assist degree secondary school",
        "word_AM": "ሁለተኛ ደረጃ ት/ቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 2700,
        "word_AF": "inkiino",
        "word_ENG": "union",
        "word_AM": "ህብረት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "sissiino"
        ],
        "defination": "kulliimil sitta geyanama"
    },
    {
        "id": 2742,
        "word_AF": "gaddi raceena",
        "word_ENG": "resource",
        "word_AM": "ሀብት ገቢ ምንጭ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "baaca raaceena"
        ],
        "defination": ""
    },
    {
        "id": 2784,
        "word_AF": "doolat madqaa kee  miglisiino aqusbusiyya",
        "word_ENG": "to- restore the conistitutional & parlmentary government",
        "word_AM": "ህገ መንግሰታዊና  ም/ቤታዊ ተሀድሶ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 2826,
        "word_AF": "cakkisitan esseri",
        "word_ENG": "legiti mized  demand",
        "word_AM": "ህጋዊ ጥያቄ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 2868,
        "word_AF": "cubbi baxsa",
        "word_ENG": "deference of opinion",
        "word_AM": "ሀሳብ ልዩነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": "mabla baxsa"
    },
    {
        "id": 2910,
        "word_AF": "canxuwwi sibaaba",
        "word_ENG": "day nursery",
        "word_AM": "ህፃናት ጠባቂ /የ/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 2952,
        "word_AF": "hektaara",
        "word_ENG": "hectar",
        "word_AM": "ሔከታር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 2994,
        "word_AF": "helikobteeri",
        "word_ENG": "helicopter",
        "word_AM": "ሔሊኮፕተር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3036,
        "word_AF": "mala",
        "word_ENG": "idea",
        "word_AM": "ሃሣብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": "tukteena aboonuh takkeemi"
    },
    {
        "id": 3078,
        "word_AF": "daktara",
        "word_ENG": "hospital",
        "word_AM": "ሆሰፒታል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3120,
        "word_AF": "hormoonu",
        "word_ENG": "hormone",
        "word_AM": "ሆርምን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3162,
        "word_AF": "hoteeli",
        "word_ENG": "hotel",
        "word_AM": "ሆቴል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3204,
        "word_AF": "dolat madqah sinna",
        "word_ENG": "unconistitutionality",
        "word_AM": "ሕገመንግሰትን የሚፆረር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3246,
        "word_AF": "madqa diglo",
        "word_ENG": "breach of the law",
        "word_AM": "ሕግን መጣሰ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3288,
        "word_AF": "tekkô-madqa",
        "word_ENG": "jursprudence",
        "word_AM": "ሕገ-ፍልሰፍና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3330,
        "word_AF": "madqa -gexse",
        "word_ENG": "jurist",
        "word_AM": "ሕግ-አዋቂ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3372,
        "word_AF": "qaranguba yargiqe saaruuku",
        "word_ENG": "inter -continental ballistic missile",
        "word_AM": "ሀገር አቋራጭ ሚሳኤል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3414,
        "word_AF": "gexxa lakqo",
        "word_ENG": "legal tender",
        "word_AM": "ሕጋዊ ገንዘብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "gexe sinni lakqo"
        ],
        "defination": ""
    },
    {
        "id": 3456,
        "word_AF": "aggattaba",
        "word_ENG": "multi-national",
        "word_AM": "ህብረ ብሔር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3498,
        "word_AF": "namma kabih xagana",
        "word_ENG": "bilateral pacts",
        "word_AM": "ሁለትዮሸ ውል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3540,
        "word_AF": "fikrata",
        "word_ENG": "thought",
        "word_AM": "ሀሣብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3582,
        "word_AF": "ummata",
        "word_ENG": "people",
        "word_AM": "ሕዝብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3624,
        "word_AF": "ayti gexxoli",
        "word_ENG": "popular",
        "word_AM": "ሕዝባዊ  ተደማጭ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3666,
        "word_AF": "ummattâ manga",
        "word_ENG": "population growth",
        "word_AM": "ሕዝባዊ ብዛት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3708,
        "word_AF": "ayti gexxo",
        "word_ENG": "popularity",
        "word_AM": "ሕዝባዊነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3750,
        "word_AF": "ayyunti misso",
        "word_ENG": "sociology",
        "word_AM": "ህብረተሰብ ምንጭ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3792,
        "word_AF": "cisab mihratli",
        "word_ENG": "chartered accountant",
        "word_AM": "ሃሳብ ባለሙያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3834,
        "word_AF": "dayli fayu",
        "word_ENG": "medical opnion",
        "word_AM": "ህክምና ምክር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3876,
        "word_AF": "ummattah magga nabam ossaama",
        "word_ENG": "demographic explosion",
        "word_AM": "ህዝብ ብዛት በጣም መጨመር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3918,
        "word_AF": "gibdi bakaqa",
        "word_ENG": "violent explosion",
        "word_AM": "ሀይለኛ ፋንዶታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 3960,
        "word_AF": "dayla",
        "word_ENG": "medical treat ment",
        "word_AM": "ህክምና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4002,
        "word_AF": "lakqô ruubiyya",
        "word_ENG": "tranisfer of money",
        "word_AM": "ሀዋላ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4044,
        "word_AF": "madqah itqa",
        "word_ENG": "to break a  law",
        "word_AM": "ህግ መጣሰ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4086,
        "word_AF": "sadar meerraytu",
        "word_ENG": "public transport",
        "word_AM": "ህዝብ ማመላለሻ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4128,
        "word_AF": "sadar  daacimeyna'",
        "word_ENG": "public toilet",
        "word_AM": "ህዝብ መፀዳጃ  ቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4170,
        "word_AF": "duddale'",
        "word_ENG": "almighty",
        "word_AM": "ሀያሉ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4212,
        "word_AF": "diini sixiixiqise'",
        "word_ENG": "religious  fanatic",
        "word_AM": "ሀይማኖት አክራሪ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4254,
        "word_AF": "dayli barittoh jaamiqata",
        "word_ENG": "medicine faculty",
        "word_AM": "ህክምና ፋኩሊቲ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4296,
        "word_AF": "kalu",
        "word_ENG": "lake",
        "word_AM": "ሀይቅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4338,
        "word_AF": "madqâ mudo",
        "word_ENG": "legislation",
        "word_AM": "ህግ ማውጣት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4380,
        "word_AF": "ummattâ qiidih waynabo",
        "word_ENG": "popular jubilation",
        "word_AM": "ህዝባዊ  በዓል አከባበር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4422,
        "word_AF": "egle",
        "word_ENG": "league",
        "word_AM": "ህብረት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4464,
        "word_AF": "cisaaba",
        "word_ENG": "mathematics",
        "word_AM": "ሂሣብ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4506,
        "word_AF": "xisnêmansafa",
        "word_ENG": "building material",
        "word_AM": "ህንፃ መሳሪያ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4548,
        "word_AF": "dayla abeyna",
        "word_ENG": "doctor",
        "word_AM": "ሀኪም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4590,
        "word_AF": "dayli barittô kitooba",
        "word_ENG": "medical books",
        "word_AM": "ህክምና  መጽሃፍት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4632,
        "word_AF": "rookâ farmo",
        "word_ENG": "message of condolences",
        "word_AM": "ሀዘን መግለጫ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4674,
        "word_AF": "madqa",
        "word_ENG": "law",
        "word_AM": "ህግ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4716,
        "word_AF": "ubkah ayro",
        "word_ENG": "birth day",
        "word_AM": "ልደት ቀን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "rabi ayro"
        ],
        "defination": ""
    },
    {
        "id": 4758,
        "word_AF": "giffo-le/li",
        "word_ENG": "highness",
        "word_AM": "ልዑል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "rammali/le"
        ],
        "defination": ""
    },
    {
        "id": 4800,
        "word_AF": "meerraytoh ikoytiinih sumaqatta",
        "word_ENG": "car regestrtion decument",
        "word_AM": "ሊብሬ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4842,
        "word_AF": "milaagu",
        "word_ENG": "exchange",
        "word_AM": "ልውውጥ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "qilaagu"
        ],
        "defination": ""
    },
    {
        "id": 4884,
        "word_AF": "erga",
        "word_ENG": "delegation",
        "word_AM": "ልዑካን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4926,
        "word_AF": "sorkocô baxi taanu",
        "word_ENG": "heart failure",
        "word_AM": "ልብ  ድካም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 4968,
        "word_AF": "qaada",
        "word_ENG": "custom",
        "word_AM": "ልማድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5010,
        "word_AF": "moddaqih tan doolaa",
        "word_ENG": "sovereign state",
        "word_AM": "ሉአላዊ መንግሰት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5052,
        "word_AF": "kormiitah xayyoowe dokonu",
        "word_ENG": " aqua finalist",
        "word_AM": "ለፍፃሜ የቀረበ  ቡድን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5094,
        "word_AF": "qisok kallaytô cakki",
        "word_ENG": "royalty dues",
        "word_AM": "ለባለመብቱ  የሚከፈል ክፍያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5136,
        "word_AF": "alwâ mixigi",
        "word_ENG": "zoologist",
        "word_AM": "ሊቀ ሰነ እንሰሳት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5178,
        "word_AF": "celsis haddaale",
        "word_ENG": "novelist",
        "word_AM": "ልብ ወለድ  ደራሲ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5220,
        "word_AF": "celsis daala",
        "word_ENG": "novel",
        "word_AM": "ልብ ወለድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5262,
        "word_AF": "salu",
        "word_ENG": "custom",
        "word_AM": "ልማድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5304,
        "word_AF": "duugeyna'",
        "word_ENG": "rubber",
        "word_AM": "ላፒሰ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5346,
        "word_AF": "siyaasah axawat yan  marah qafu abaanama",
        "word_ENG": "he proclaims the amnesty for the political prisoners",
        "word_AM": "ለፓለቲካ  እሰረኞች  ምህረት እወጀ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5388,
        "word_AF": "makeelô qari",
        "word_ENG": "laboratory",
        "word_AM": "ላቦራቶሪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5430,
        "word_AF": "qeebi gulgulutiyya",
        "word_ENG": ".to mobilize  for the war",
        "word_AM": "ለጦርነት መዘጋጀት /መንቀሳቀስ /",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5472,
        "word_AF": "bicsen wagri ekraaro",
        "word_ENG": "prepare plan of peace",
        "word_AM": "ለሰላም  የተዘጋጀ  እቅድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5514,
        "word_AF": "yakki",
        "word_ENG": "possible",
        "word_AM": "ሊሰማማ  የሚችል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            "mayakki"
        ],
        "defination": ""
    },
    {
        "id": 5556,
        "word_AF": "manxaqata",
        "word_ENG": "polio",
        "word_AM": "ልጅነት ልምሽ ፖልዮ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5598,
        "word_AF": "baxsa le gabbaqu",
        "word_ENG": "special report",
        "word_AM": "ልዩ ሪፖርት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5640,
        "word_AF": "sissinaana",
        "word_ENG": "defference",
        "word_AM": "ልዩነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5682,
        "word_AF": "fulsut baakeeri",
        "word_ENG": "speculation",
        "word_AM": "ለትርፍ  ማጓጓት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5724,
        "word_AF": "yabti hadala",
        "word_ENG": "fiction",
        "word_AM": "ልብ ወለድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5766,
        "word_AF": "salacle muxxo",
        "word_ENG": "weak majority",
        "word_AM": "የላላ ብልጫ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5808,
        "word_AF": "garqô haada",
        "word_ENG": "flight theft",
        "word_AM": "ሌብነት በራሪ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5850,
        "word_AF": "amaaki",
        "word_ENG": "barter",
        "word_AM": "ለውጥ /እቃ በእቃ /",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5892,
        "word_AF": "arac ascossi",
        "word_ENG": "location",
        "word_AM": "ለቦታ ማግኘት  አቀማመጥ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5934,
        "word_AF": "qunxa koroneeli",
        "word_ENG": "lieutenant colonel",
        "word_AM": "ሌተና ኮሎኔል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 5976,
        "word_AF": "fula",
        "word_ENG": "abundance",
        "word_AM": "መትረፍረፍ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6018,
        "word_AF": "fuuqo",
        "word_ENG": "absorption",
        "word_AM": "መምጠጥ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6060,
        "word_AF": "deelimaanama",
        "word_ENG": "abstinence",
        "word_AM": "መገለል /መታቀብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6102,
        "word_AF": "baabure qawwalayla",
        "word_ENG": "car accident",
        "word_AM": "መኪና አደጋ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6144,
        "word_AF": "inkaafah itittin-geyi",
        "word_ENG": "unanimous agreement",
        "word_AM": "ሙሉ ሰምምነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6186,
        "word_AF": "kaalimi",
        "word_ENG": "accumulation",
        "word_AM": "መጠራቀም ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6228,
        "word_AF": "weeqa'",
        "word_ENG": "charge",
        "word_AM": "መጫን :ክሰ መመሥረት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6270,
        "word_AF": "yoo- gufteh asta",
        "word_ENG": "acknowledgement of receipt",
        "word_AM": "መጥሪያ ደረሰኝ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6312,
        "word_AF": "mingir",
        "word_ENG": "witness",
        "word_AM": "ምሰክር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6354,
        "word_AF": "sumaqta'",
        "word_ENG": "certificate",
        "word_AM": "ምሰክር ወረቀት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6396,
        "word_AF": "meddala",
        "word_ENG": "appropriateness",
        "word_AM": "መመጣጠን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6438,
        "word_AF": "xakbimiyaa",
        "word_ENG": "to adhere",
        "word_AM": "መጣበቅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6480,
        "word_AF": "giti qawwalayla",
        "word_ENG": "road accident",
        "word_AM": "መንገድ ላይግጭት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6522,
        "word_AF": "tut -bica elle barteena",
        "word_ENG": "adaptation",
        "word_AM": "መለማመጃ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6564,
        "word_AF": "xiinisso",
        "word_ENG": "administration",
        "word_AM": "መሰተዳደር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6606,
        "word_AF": "akeeliiya",
        "word_ENG": "to admit",
        "word_AM": "መቀበል/ማመን /",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6648,
        "word_AF": "muggaaqissiyya",
        "word_ENG": "to appoint",
        "word_AM": "መመደብ/መሰየም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6690,
        "word_AF": "raabitiyya",
        "word_ENG": " to  agree  ",
        "word_AM": "መሰማማት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6732,
        "word_AF": "diggoysiyya",
        "word_ENG": "asserted",
        "word_AM": "መረጋገጥ/ ማጥበቅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6774,
        "word_AF": "faaticisiyya",
        "word_ENG": "approval",
        "word_AM": "ማፀደቅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6816,
        "word_AF": "magneeti",
        "word_ENG": "magnet",
        "word_AM": "ማግኔት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6858,
        "word_AF": "rekissô massoyso",
        "word_ENG": "structural adjustment",
        "word_AM": "መዋቅር ማሰተካከያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6900,
        "word_AF": "kayyiqtu",
        "word_ENG": "alarm",
        "word_AM": "ማሰጠንቀቂያ ደወል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6942,
        "word_AF": "maaqidda",
        "word_ENG": "alimentation",
        "word_AM": "ምግብ አይነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 6984,
        "word_AF": "maaqo",
        "word_ENG": "food",
        "word_AM": "ምግብ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7026,
        "word_AF": "hoomata",
        "word_ENG": "allegation",
        "word_AM": "ማሰረጃ ያልቀረበበት ክሰ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7068,
        "word_AF": "caraya",
        "word_ENG": "allocation",
        "word_AM": "መደልደል /እርዳታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7110,
        "word_AF": "alefbaatisso",
        "word_ENG": "literacy",
        "word_AM": "ማንበብና መፃፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7152,
        "word_AF": "inkaafah anaya",
        "word_ENG": "unanimous vote",
        "word_AM": "ሙሉ ድምፅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7194,
        "word_AF": "apertifi",
        "word_ENG": "aperitif",
        "word_AM": "ምግብ ፈት የሚጠጣ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7236,
        "word_AF": "hillikiinu",
        "word_ENG": "anta gonism",
        "word_AM": "የማይታረቅ  ቅራኔ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7278,
        "word_AF": "maysaraaraca",
        "word_ENG": "design",
        "word_AM": "መንደፍ/ንድፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7320,
        "word_AF": "cabsu",
        "word_ENG": " amnesty",
        "word_AM": "ምህረት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7362,
        "word_AF": "qafu-gee",
        "word_ENG": "amnesty receiver",
        "word_AM": "ምህረት ያገኘ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7404,
        "word_AF": "baaxi farakka",
        "word_ENG": "area",
        "word_AM": "መጠነ ዙሪያ ሰፋት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7446,
        "word_AF": "warâ sinna",
        "word_ENG": "illitracy",
        "word_AM": "ማይምነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7488,
        "word_AF": "maysaxxaga",
        "word_ENG": "announcement",
        "word_AM": "ማሰታወቂያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7530,
        "word_AF": "aysaxxagiyya",
        "word_ENG": " to annouce",
        "word_AM": "መናገር / ማሳወቅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7572,
        "word_AF": "gabah - agra",
        "word_ENG": "applause",
        "word_AM": "ማጨብጨብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7614,
        "word_AF": "maymaaqa",
        "word_ENG": "amendment",
        "word_AM": "ማሻሻያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7656,
        "word_AF": "doolát saayih boodu",
        "word_ENG": "affectd state security",
        "word_AM": "መንግሰት  ፀጥታ  መናጋት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7698,
        "word_AF": "kalali  sirrih mayyaqa",
        "word_ENG": "affectd defence secret",
        "word_AM": "መከላከያ  ምሰጢር  ማውጣት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7740,
        "word_AF": "gabbatu",
        "word_ENG": "attempt",
        "word_AM": "ሙከራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7782,
        "word_AF": "tayyaarah obta",
        "word_ENG": "landing",
        "word_AM": "መሬት  ላይ ማረፊያ/የአይሮፕላን /",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7824,
        "word_AF": "is fan giitiyya",
        "word_ENG": "to attract",
        "word_AM": "መማረክ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7866,
        "word_AF": "koram korsiyya",
        "word_ENG": "reshuffle",
        "word_AM": "መለዋወጥ /ሹም ሸር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7908,
        "word_AF": "ossiyya",
        "word_ENG": "to increase",
        "word_AM": "መጨመር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7950,
        "word_AF": "obba",
        "word_ENG": "audio",
        "word_AM": "ማዳመጥ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 7992,
        "word_AF": "maybalaalaqah",
        "word_ENG": "article of the news paper",
        "word_AM": "መጣጥፍ  /የጽሁፍ አንቀጽ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8034,
        "word_AF": "qidiyya",
        "word_ENG": "to-murder",
        "word_AM": "መግደል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8076,
        "word_AF": "gagbo",
        "word_ENG": "assault",
        "word_AM": "ማጥቃት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8118,
        "word_AF": "catiyya",
        "word_ENG": "to attend to assist",
        "word_AM": "ማገዝ፣ መሳተፍ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8160,
        "word_AF": "arshiifi",
        "word_ENG": "archives",
        "word_AM": "መዝገብ ቤት /ሪከርድና ማህደር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8202,
        "word_AF": "arshiifisti",
        "word_ENG": "archives",
        "word_AM": "መዝገብ ቤት ሰራተኛ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8244,
        "word_AF": "mislaafannu",
        "word_ENG": "aristoc racy",
        "word_AM": "መሰፍናዊነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8286,
        "word_AF": "gob salaca",
        "word_ENG": "armistice",
        "word_AM": "መሳሪያ  መፍታት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8328,
        "word_AF": "silac madaba",
        "word_ENG": "ar mourers",
        "word_AM": "መሣሪያ ግምጃ ቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8370,
        "word_AF": "faaticisiyya-oggolu",
        "word_ENG": "approval",
        "word_AM": "ማፀደቅ ፣መቀበል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8412,
        "word_AF": "assakaata",
        "word_ENG": "appreciation",
        "word_AM": "ማድነቅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8454,
        "word_AF": "qaago hanbareeri",
        "word_ENG": "aspiration",
        "word_AM": "ምኞት ከፍተኛ ተሰፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8496,
        "word_AF": "miglisi",
        "word_ENG": "assembly",
        "word_AM": "ምክር ቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8538,
        "word_AF": "ekeká",
        "word_ENG": "warning",
        "word_AM": "ማሰጠንቀቂያ  ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8580,
        "word_AF": "warsiyya",
        "word_ENG": "to inform",
        "word_AM": "ማሰታወቅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8622,
        "word_AF": "currihmano",
        "word_ENG": "to have freedom of movement",
        "word_AM": "መንቀሳቀስ  ነፃነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8664,
        "word_AF": "murtí dagna",
        "word_ENG": "drop in production",
        "word_AM": "ምርት መቀነስ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8706,
        "word_AF": "assamaqa",
        "word_ENG": "well being",
        "word_AM": "ምቾት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8748,
        "word_AF": "katlâ xibixi",
        "word_ENG": "blockade",
        "word_AM": "ማእቀብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8790,
        "word_AF": "meqe xiinisso",
        "word_ENG": "good governance",
        "word_AM": "መልካም  አሰተዳደር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8832,
        "word_AF": "muufe",
        "word_ENG": "bakery",
        "word_AM": "መጋገሪያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8874,
        "word_AF": "milaagimaktaba",
        "word_ENG": "foreign exchange office",
        "word_AM": "ምንዛሬ  ጽ/ቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8916,
        "word_AF": "massahada",
        "word_ENG": "stability",
        "word_AM": "መረጋጋት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 8958,
        "word_AF": "radiyya",
        "word_ENG": "loot",
        "word_AM": "መዝረፍ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9000,
        "word_AF": "seewi gaso",
        "word_ENG": "concentration camp",
        "word_AM": "ምርኮኛ ማጎሪያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9042,
        "word_AF": "doorô geysiisi",
        "word_ENG": "election   campaign",
        "word_AM": "ምርጫ ዘመቻ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9084,
        "word_AF": "yoh -xic geysiisi",
        "word_ENG": "advertising campaign",
        "word_AM": "ምረጡኝ ዘመቻ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9126,
        "word_AF": "angayye waa raasal maala",
        "word_ENG": "immobilizecapital",
        "word_AM": "ማይንቀሳቀሰ /የ/ካፒታል/ሀብት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9168,
        "word_AF": "xiiriyyô karti",
        "word_ENG": "card of retreat",
        "word_AM": "ማባረሪያ ካርድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9210,
        "word_AF": "kinnaanê  karti",
        "word_ENG": "id card",
        "word_AM": "መታወቂያ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9252,
        "word_AF": "ugut",
        "word_ENG": "cause",
        "word_AM": "ምክንያት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9294,
        "word_AF": "ardi cundubu",
        "word_ENG": "the center of earth",
        "word_AM": "ምድር እምብርት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9336,
        "word_AF": "mafdaga",
        "word_ENG": "chapter",
        "word_AM": "ምፅራፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9378,
        "word_AF": "fanti baritto",
        "word_ENG": "middle school",
        "word_AM": "መለሰተኛ  ሁለተኛ  ደረጃ ትምህርት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9420,
        "word_AF": "kassiti",
        "word_ENG": "remembrance",
        "word_AM": "መታሰቢያ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9462,
        "word_AF": "hoxsiyya",
        "word_ENG": "to mistaken",
        "word_AM": "መሣሣት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9504,
        "word_AF": "gaanta",
        "word_ENG": "community",
        "word_AM": "ማህበረሰብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9546,
        "word_AF": "kallayto",
        "word_ENG": "municipality",
        "word_AM": "ማዘጋጃ ቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9588,
        "word_AF": "angaarawa",
        "word_ENG": "communication",
        "word_AM": "መገናኛ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9630,
        "word_AF": "ummattah angaarawa",
        "word_ENG": "mass communication",
        "word_AM": "መገናኛ  ብዙሃን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9672,
        "word_AF": "ayyunti fantaaxawa",
        "word_ENG": "social relation",
        "word_AM": "ማህበራዊ ግንኙነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9714,
        "word_AF": "maysaxxaga",
        "word_ENG": "statement",
        "word_AM": "መግለጫ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9756,
        "word_AF": "butta",
        "word_ENG": "company",
        "word_AM": "/የ/መቶ  ጦር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9798,
        "word_AF": "kita'b yayyaaqi",
        "word_ENG": "loaded  with publishing edition",
        "word_AM": "መጽሐፍ አሳታሚ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9840,
        "word_AF": "rardimi",
        "word_ENG": "fall",
        "word_AM": "መውደቅ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9882,
        "word_AF": "meqêmariino",
        "word_ENG": "good citizen ship",
        "word_AM": "መልካም ዜግነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9924,
        "word_AF": "mabqara",
        "word_ENG": "cloning",
        "word_AM": "ማዳቀል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 9966,
        "word_AF": "maaqiita",
        "word_ENG": "quatation",
        "word_AM": "ጥቅሰ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10008,
        "word_AF": "yay saqarri",
        "word_ENG": "book keeper",
        "word_AM": "መዝገብ  ያዥ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10050,
        "word_AF": "gaboyso",
        "word_ENG": "concentration ",
        "word_AM": "ማከማቸት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10092,
        "word_AF": "qaxi dooro",
        "word_ENG": "concept of beauty",
        "word_AM": "/የ/መልክ ምርጫ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10134,
        "word_AF": "inkih yan sittingeyi",
        "word_ENG": "consensus",
        "word_AM": "ሙሉ ሰምምነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10176,
        "word_AF": "amoggacsa",
        "word_ENG": "conclusion",
        "word_AM": "ማጠቃለያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10218,
        "word_AF": "tabsa",
        "word_ENG": "conduction",
        "word_AM": "ማሰተላለፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10260,
        "word_AF": "beyto",
        "word_ENG": "to drive",
        "word_AM": "መንዳት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10302,
        "word_AF": "assacokka",
        "word_ENG": "condemnation",
        "word_AM": "ማውገዝ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10344,
        "word_AF": "doolat korô gibbatu",
        "word_ENG": "coup attempts",
        "word_AM": "/የ/መንግስት ግልበጣ ሙከራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10386,
        "word_AF": "kobxisso",
        "word_ENG": "collection",
        "word_AM": "ማሰባሰብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10428,
        "word_AF": "doorit maro",
        "word_ENG": "electoral body",
        "word_AM": "ምረጫ ቦርድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10470,
        "word_AF": "sirri",
        "word_ENG": "secret",
        "word_AM": "ምሲጢር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10512,
        "word_AF": "agribiyya",
        "word_ENG": " to condence",
        "word_AM": "ማጦዝ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10554,
        "word_AF": "cali",
        "word_ENG": "contribution",
        "word_AM": "መዋጮ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10596,
        "word_AF": "angaaada",
        "word_ENG": "convalescence",
        "word_AM": "ማገገም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10638,
        "word_AF": "umam baris",
        "word_ENG": "corrupter",
        "word_AM": "ምግባረ ብልሹ ሰው",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10680,
        "word_AF": "umam kabana",
        "word_ENG": "corruption",
        "word_AM": "ሙሰና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10722,
        "word_AF": "umam barit li",
        "word_ENG": "corrupt",
        "word_AM": "ምግባረ ብልሹ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10764,
        "word_AF": "uyyuntiinoh ittin qokolu",
        "word_ENG": "social subscription",
        "word_AM": "ማህበረዊ አሰተዋጽኦ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10806,
        "word_AF": "nahar si caxa",
        "word_ENG": "primary court",
        "word_AM": "መጀመርያ /የ/ደረጀ ፍ/ቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10848,
        "word_AF": "deero",
        "word_ENG": "cry of alarm",
        "word_AM": "ማሰጠንቀቂያ /የ/ጩኸት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10890,
        "word_AF": "qallu",
        "word_ENG": "over flow",
        "word_AM": "መጥለቅለቅ /ምልቶ መፍሰስ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10932,
        "word_AF": "baxxiqisso",
        "word_ENG": "declaration",
        "word_AM": "መግለጫ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 10974,
        "word_AF": "kassis muggaaqisenta",
        "word_ENG": "to dedicate",
        "word_AM": "መታሰቢያነት /ለ/መሰየም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11016,
        "word_AF": "mirracsimenta",
        "word_ENG": "department",
        "word_AM": "መምሪያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11058,
        "word_AF": "fixsa",
        "word_ENG": "display",
        "word_AM": "ማጫወት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11100,
        "word_AF": "qaxxaagi",
        "word_ENG": "dismay",
        "word_AM": "ማደናገር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11142,
        "word_AF": "salaca",
        "word_ENG": "deflation",
        "word_AM": "ማሰተንፈሰ /ዝቅ ማድረግ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11184,
        "word_AF": "kibal boola",
        "word_ENG": "degeneracy",
        "word_AM": "መንፈሰ ደካማነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11226,
        "word_AF": "satqâ kalo",
        "word_ENG": "lunch",
        "word_AM": "ምሣ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11268,
        "word_AF": "farmoyta",
        "word_ENG": "delegate",
        "word_AM": "መልእክተኛ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11310,
        "word_AF": "eglah awlaytu",
        "word_ENG": "union representative",
        "word_AM": "ማህበር /የ/ተወካይ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11352,
        "word_AF": "addâfakot essero",
        "word_ENG": "demand of explanation",
        "word_AM": "ማብራሪያ /የ/ጥያቂ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11394,
        "word_AF": "cabti",
        "word_ENG": "to resign",
        "word_AM": "መተው መለቀቅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11436,
        "word_AF": "soolo",
        "word_ENG": "demonestration",
        "word_AM": "ማሳያ /ሰላማዊ  ሰልፍ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11478,
        "word_AF": "eglah",
        "word_ENG": "cooperative",
        "word_AM": "ማህበር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11520,
        "word_AF": "kalalu",
        "word_ENG": "defence",
        "word_AM": "መከላከያ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11562,
        "word_AF": "agaagulu",
        "word_ENG": "disorder",
        "word_AM": "መዝረክረክ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11604,
        "word_AF": "wadba",
        "word_ENG": "destination",
        "word_AM": "መድረሻ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11646,
        "word_AF": "cakkii kee curruyat itqa",
        "word_ENG": "destruction of right and liberties",
        "word_AM": "መብትና ነፃነት  ረገጣ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11688,
        "word_AF": "sabhalaala",
        "word_ENG": "relaxation",
        "word_AM": "መንፈስ  እርካታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11730,
        "word_AF": "casbi",
        "word_ENG": "detention",
        "word_AM": "መታሰር /እሰር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11772,
        "word_AF": "maylatu",
        "word_ENG": "embezzlement",
        "word_AM": "ሙሰና ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11814,
        "word_AF": "qangor maysarraqa",
        "word_ENG": "dictionary",
        "word_AM": "መዝገበ ቃላት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11856,
        "word_AF": "gara",
        "word_ENG": "right",
        "word_AM": "መብት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11898,
        "word_AF": "miraaca",
        "word_ENG": "leader",
        "word_AM": "መሪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11940,
        "word_AF": "miraacisa hortih walala",
        "word_ENG": "discusion of thesteered group",
        "word_AM": "መሪ ቡድን ውይይት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 11982,
        "word_AF": "qaafiyat  fayih araca",
        "word_ENG": "advice center",
        "word_AM": "ምክር መሰጫ  ማፅከል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12024,
        "word_AF": "inkih yan dudda",
        "word_ENG": "general capacities",
        "word_AM": "ሙሉ አቅም ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12066,
        "word_AF": "ixxigah duudih aysaballih kutbe",
        "word_ENG": "essay",
        "word_AM": "ምረቃ ጽሁፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12108,
        "word_AF": "agat maroh diglo",
        "word_ENG": "dissolution of the parliament",
        "word_AM": "ምክር ቤትን ብተና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12150,
        "word_AF": "agat maro aggiliyya",
        "word_ENG": "to dissolve an assembly",
        "word_AM": "ምክር  ቤትን መበተን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12192,
        "word_AF": "ximmosiyya",
        "word_ENG": "distillition ",
        "word_AM": "ማጥለል/ማጣራት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12234,
        "word_AF": "keefiyyo",
        "word_ENG": "distribution",
        "word_AM": "ማከፉፈል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12276,
        "word_AF": "wahansiti",
        "word_ENG": "entertaiment ",
        "word_AM": "መዝናናት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12318,
        "word_AF": "doolat xexxaara",
        "word_ENG": "public domain",
        "word_AM": "መንግስት ግዛት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12360,
        "word_AF": "diwâcaddabana",
        "word_ENG": "dose",
        "word_AM": "መድሃኒት  መጠን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12402,
        "word_AF": "maglab siinni baritto",
        "word_ENG": "informal education",
        "word_AM": "መደበኛ  ያልሆነ ትምህርት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12444,
        "word_AF": "gidde",
        "word_ENG": "number size",
        "word_AM": "መጠን ቁጥር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12486,
        "word_AF": "dooro",
        "word_ENG": "election",
        "word_AM": "ምርጫ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12528,
        "word_AF": "doore",
        "word_ENG": "voter",
        "word_AM": "መራጭ /ድምፅ ሰጭ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12570,
        "word_AF": "tu -kinnimi",
        "word_ENG": "element",
        "word_AM": "መሠረታዊ ነገር/በህረ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12612,
        "word_AF": "Doorim duddali",
        "word_ENG": "eligible",
        "word_AM": "መምረጥ /ለ/ብቃትያለው",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12654,
        "word_AF": "mixigi",
        "word_ENG": "elite",
        "word_AM": "ምሁር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12696,
        "word_AF": "cibiyya",
        "word_ENG": "packaging",
        "word_AM": "መጠቅለል/እቃ/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12738,
        "word_AF": "katlâ xibixi",
        "word_ENG": "ebrago",
        "word_AM": "ማፅቀብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12780,
        "word_AF": "giti ifoyta",
        "word_ENG": "public lighting",
        "word_AM": "መንገድ/የ/ማብራት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12822,
        "word_AF": "salaadâ-barittoh buxa",
        "word_ENG": "nursery school",
        "word_AM": "መዋፅለ  ህፃናት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12864,
        "word_AF": "atbiqiyya",
        "word_ENG": "to- edit",
        "word_AM": "ማሳተም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12906,
        "word_AF": "madble barittoh  buxa",
        "word_ENG": "formal education",
        "word_AM": "መደበኛ  ትምህርት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12948,
        "word_AF": "taamat hayti",
        "word_ENG": "hiring",
        "word_AM": "መቅጠር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 12990,
        "word_AF": "soola casbi",
        "word_ENG": "detention",
        "word_AM": "ማሰር/ማጎር/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13032,
        "word_AF": "aytukuma",
        "word_ENG": "encouragement",
        "word_AM": "ማበረታታት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13074,
        "word_AF": "loowimiyya",
        "word_ENG": "recruitment",
        "word_AM": "መመልመል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13116,
        "word_AF": "cabsiisiyya",
        "word_ENG": "removal",
        "word_AM": "ማሰለቀቅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13158,
        "word_AF": "fokkaaqo",
        "word_ENG": "inquiry",
        "word_AM": "ምርመራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13200,
        "word_AF": "aysaqorra",
        "word_ENG": "recording",
        "word_AM": "ምዝገባ/መቅረፅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13242,
        "word_AF": "aysaqorri",
        "word_ENG": "to register",
        "word_AM": "መመዝገብ/መቅረጽ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13284,
        "word_AF": "uma - caxxa",
        "word_ENG": "in bad state",
        "word_AM": "መጥፎ /በ/ሁኔታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13326,
        "word_AF": "barsa",
        "word_ENG": "teaching",
        "word_AM": "ማሰተማር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13368,
        "word_AF": "rakiibô - baritto",
        "word_ENG": "basic education",
        "word_AM": "መሠረታዊ ትምህርት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13410,
        "word_AF": "yaysabaki",
        "word_ENG": "inter preneur",
        "word_AM": "መሰራች",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13452,
        "word_AF": "saada",
        "word_ENG": "blooming",
        "word_AM": "ማበብ/እንቡጥ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13494,
        "word_AF": "mansoofa",
        "word_ENG": "equapment",
        "word_AM": "መገልገያ  መሣሪያ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13536,
        "word_AF": "atkiyisiyya",
        "word_ENG": "to - equap",
        "word_AM": "ማሰታጠቅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13578,
        "word_AF": "qeedaala",
        "word_ENG": "balance",
        "word_AM": "ሚዛን የጠበቀ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13620,
        "word_AF": "kalti",
        "word_ENG": "eradication",
        "word_AM": "ማሰወገድ ማጥፋት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13662,
        "word_AF": "waklisiyya",
        "word_ENG": "to escort",
        "word_AM": "ማጀብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13704,
        "word_AF": "malmaalu",
        "word_ENG": "swindle",
        "word_AM": "ማጭበርበር/ማታለል/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13746,
        "word_AF": "gabbatu",
        "word_ENG": "attempt",
        "word_AM": "ሙክራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13788,
        "word_AF": "qawwaddi",
        "word_ENG": "spirit",
        "word_AM": "መንፊሰ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13830,
        "word_AF": "aqakkaasa",
        "word_ENG": "to estimate",
        "word_AM": "መገመት /መገምገም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13872,
        "word_AF": "daabisenta",
        "word_ENG": "stablishment",
        "word_AM": "ማቋቋም /መቆርቆር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13914,
        "word_AF": "kitoobâ -rekkiseyna",
        "word_ENG": "book case",
        "word_AM": "መጽሐፍ መደርደሪያ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13956,
        "word_AF": "doolata",
        "word_ENG": "state",
        "word_AM": "መንግስት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 13998,
        "word_AF": "affacsimi",
        "word_ENG": "evaporation",
        "word_AM": "መትነን ተነነ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14040,
        "word_AF": "waalih hayiyya",
        "word_ENG": "to- avoid",
        "word_AM": "ማሰወገድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14082,
        "word_AF": "abnisiyya",
        "word_ENG": "execution of the project",
        "word_AM": "መተግበር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14124,
        "word_AF": "udurro",
        "word_ENG": "daley",
        "word_AM": "ማዘግየት /አሰተላለፊ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14166,
        "word_AF": "hirgimiyya",
        "word_ENG": "retreat",
        "word_AM": "ማፊግፊግ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14208,
        "word_AF": "xakbisso",
        "word_ENG": "link",
        "word_AM": "ማያያዝ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14250,
        "word_AF": "celsiisi",
        "word_ENG": "simulation",
        "word_AM": "ማሰመሰል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14292,
        "word_AF": "itro",
        "word_ENG": "slogan",
        "word_AM": "መፊክር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14334,
        "word_AF": "egla'",
        "word_ENG": "society",
        "word_AM": "ማህበር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14376,
        "word_AF": "nahar si rankoh qaskarita",
        "word_ENG": "solder of 1st class",
        "word_AM": "መጀመርያደረጀ  ወታደር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14418,
        "word_AF": "qiko",
        "word_ENG": "solderity",
        "word_AM": "መተባበር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14460,
        "word_AF": "fidga",
        "word_ENG": "solution",
        "word_AM": "መፍትሄ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14502,
        "word_AF": "illacabô fidga",
        "word_ENG": "final solution",
        "word_AM": "መጨረሻመፍትሄ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14544,
        "word_AF": "xaagi raceyna",
        "word_ENG": "source of information",
        "word_AM": "መረጃምንጭ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14586,
        "word_AF": "baabur soltima",
        "word_ENG": "car barking",
        "word_AM": "መኪናማቆሚያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14628,
        "word_AF": "meexo",
        "word_ENG": "sellection",
        "word_AM": "መለየት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14670,
        "word_AF": "maaqô qasbo",
        "word_ENG": "mineral salts",
        "word_AM": "ምግብጨው",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14712,
        "word_AF": "garcikalti",
        "word_ENG": "awerness",
        "word_AM": "መጠንቀቅ/ማስጠንቀቅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14754,
        "word_AF": "oytisenti ayfaafa",
        "word_ENG": "service of information",
        "word_AM": "መረጃአገልግሎት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14796,
        "word_AF": "hora",
        "word_ENG": "century",
        "word_AM": "መዕት ዓመት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14838,
        "word_AF": "rakisso",
        "word_ENG": "structure",
        "word_AM": "መዋቅር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14880,
        "word_AF": "wadu",
        "word_ENG": "testimony",
        "word_AM": "ምሰክር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14922,
        "word_AF": "liqnah caddabna",
        "word_ENG": "temprature",
        "word_AM": "ሙቀት መጠን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 14964,
        "word_AF": "qidim gabbatu",
        "word_ENG": "attempt of assassinat",
        "word_AM": "መግደል ሙከራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15006,
        "word_AF": "illacabô mafdaga",
        "word_ENG": "terminal",
        "word_AM": "መጨረሻ ጣቢያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15048,
        "word_AF": "walhawwala",
        "word_ENG": "ventilation",
        "word_AM": "መናፈሻ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15090,
        "word_AF": "asmata",
        "word_ENG": "verification",
        "word_AM": "ማጣራት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15132,
        "word_AF": "malaak gubaytu",
        "word_ENG": "vice minister",
        "word_AM": "ም/ሚኒስቴር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15174,
        "word_AF": "fida",
        "word_ENG": "victim",
        "word_AM": "መሰዋእትነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15216,
        "word_AF": "bedu",
        "word_ENG": "label",
        "word_AM": "ምልክት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15258,
        "word_AF": "maqsbaasa",
        "word_ENG": "renewal",
        "word_AM": "ማሳደሰ/እድሣት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15300,
        "word_AF": "baxxiqisso",
        "word_ENG": "reference ",
        "word_AM": "መግለጫ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15342,
        "word_AF": "qelli dooro",
        "word_ENG": "secret ballot",
        "word_AM": "ምሰጢራዊ ምርጫ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15384,
        "word_AF": "xiso gacsa",
        "word_ENG": "reconstruction",
        "word_AM": "መልሶ ግንባታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15426,
        "word_AF": "axmaqa",
        "word_ENG": "cross cheking",
        "word_AM": "ማረጋገጫ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15468,
        "word_AF": "askotta",
        "word_ENG": "collection",
        "word_AM": "ማሰባሰብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15510,
        "word_AF": "samhalala",
        "word_ENG": "recreation",
        "word_AM": "መዝናናት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15552,
        "word_AF": "angadaada",
        "word_ENG": "recovery",
        "word_AM": "ማገገም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15594,
        "word_AF": "madaddaara",
        "word_ENG": "repetition",
        "word_AM": "መመላለሰ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15636,
        "word_AF": "massoosu",
        "word_ENG": "redressing",
        "word_AM": "ማሰተካከያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15678,
        "word_AF": "faaticisiyya",
        "word_ENG": "ratification",
        "word_AM": "ማጽደቂያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15720,
        "word_AF": "boola",
        "word_ENG": "deterioration",
        "word_AM": "ማሸቆልቆል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15762,
        "word_AF": "sigmâ rasu",
        "word_ENG": "residential  zone",
        "word_AM": "መኖሪያ አካባቢ /ዞን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15804,
        "word_AF": "xaagi  oytisso",
        "word_ENG": "information",
        "word_AM": "መረጀ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15846,
        "word_AF": "berra",
        "word_ENG": "repercussion",
        "word_AM": "ማሰተጋባት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15888,
        "word_AF": "qagu",
        "word_ENG": "repetition",
        "word_AM": "መድገም ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15930,
        "word_AF": "gacsa",
        "word_ENG": "answer",
        "word_AM": "መልሰ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 15972,
        "word_AF": "canê gacsa",
        "word_ENG": "reprisals retaliation",
        "word_AM": "መበቀል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16014,
        "word_AF": "assacokka",
        "word_ENG": "to - reprimand",
        "word_AM": "መውቀስ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16056,
        "word_AF": "aydorra",
        "word_ENG": "reproduction",
        "word_AM": "መራባት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16098,
        "word_AF": "kalalu",
        "word_ENG": "resistance",
        "word_AM": "መከላከል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16140,
        "word_AF": "sirri sadu",
        "word_ENG": "secret  resistance",
        "word_AM": "ምሰጢራዊ ተቃውሞ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16182,
        "word_AF": "finqa",
        "word_ENG": "ruin",
        "word_AM": "መደምሰስ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16224,
        "word_AF": "fida akkiyya",
        "word_ENG": "to sacrifice one self",
        "word_AM": "መሰዋእት መሆን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16266,
        "word_AF": "kaaliyya",
        "word_ENG": "to accumulate",
        "word_AM": "ማጠራቀም /መጠራቀም ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16308,
        "word_AF": "deeliyya",
        "word_ENG": "to alinate some body",
        "word_AM": "ማግለል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16350,
        "word_AF": "raakiibo maliino",
        "word_ENG": "un founded",
        "word_AM": "መሰረተቢስ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16392,
        "word_AF": "xayyoowiyya",
        "word_ENG": "to approach",
        "word_AM": "መቅረብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16434,
        "word_AF": "uguugusu",
        "word_ENG": "provocation",
        "word_AM": "ማነሳሳት /ማናደድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16476,
        "word_AF": "cabu",
        "word_ENG": "psychosis",
        "word_AM": "ማንነት የሚያሳጣ/የአእምሮ በሸታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16518,
        "word_AF": "maysaxxaga",
        "word_ENG": "advertisement ",
        "word_AM": "ማሰታወቂያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16560,
        "word_AF": "marô duudu",
        "word_ENG": "quorum",
        "word_AM": "ምልአተ ጉባኤ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16602,
        "word_AF": "esserta",
        "word_ENG": "questionnaire",
        "word_AM": "መጠይቅ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16644,
        "word_AF": "marô duudiyya",
        "word_ENG": " to reach the quorum",
        "word_AM": "ምልአተ ጉባኤ መሟላት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16686,
        "word_AF": "fida",
        "word_ENG": "sacrifice",
        "word_AM": "መሰዋዕት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16728,
        "word_AF": "meqe dacayri",
        "word_ENG": "safe guard",
        "word_AM": "መከላከያ ራሰን መጠበቅ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16770,
        "word_AF": "maynub awliinu",
        "word_ENG": "custody",
        "word_AM": "ማሳደግ ኃላፊነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16812,
        "word_AF": "elle cabô maabitina",
        "word_ENG": "ultimatum",
        "word_AM": "መጨረሻ  ማሰጠንቀቂያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16854,
        "word_AF": "ayfaafayli",
        "word_ENG": "utility",
        "word_AM": "መገልገያ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16896,
        "word_AF": "a,alat mixxiga",
        "word_ENG": "mchinary responsible",
        "word_AM": "ማሸነሪ ኀላፊ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16938,
        "word_AF": "miglis ximokraasi",
        "word_ENG": "restoring of  the parliamentary democracy",
        "word_AM": "ምክርቤታዊ ዲሞክራሲ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 16980,
        "word_AF": "angadaada",
        "word_ENG": "rihablitation",
        "word_AM": "ተሀድሶ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17022,
        "word_AF": "maali mingili",
        "word_ENG": "real properties fund",
        "word_AM": "መሠረታዊ ገንዘብ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17064,
        "word_AF": "dageyna",
        "word_ENG": "drill",
        "word_AM": "መሠርሠሪያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17106,
        "word_AF": "milisiya",
        "word_ENG": "paramilitary force",
        "word_AM": "ሚሊሺያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17148,
        "word_AF": "ardi qande",
        "word_ENG": "ground force",
        "word_AM": "ምድር ይል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17190,
        "word_AF": "ardi - caleytih garbo",
        "word_ENG": "equatorial forest",
        "word_AM": "ምድር ሰቅ ጫካ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17232,
        "word_AF": "mihrat aydakaakana",
        "word_ENG": "trianing  profesional",
        "word_AM": "ሙያ ሥልጠና /የ/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17274,
        "word_AF": "masu",
        "word_ENG": "size",
        "word_AM": "መጠን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17316,
        "word_AF": "aydakaakana",
        "word_ENG": "trianing ",
        "word_AM": "ሥልጠና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17358,
        "word_AF": "baaxô",
        "word_ENG": "shape of the earth",
        "word_AM": "መሬት ቅርጽ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17400,
        "word_AF": "madabli",
        "word_ENG": "formali",
        "word_AM": "መደበኛ /በደንቡ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17442,
        "word_AF": "egla xiiyya",
        "word_ENG": "to form an association",
        "word_AM": "ማህበር ምሥረታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17484,
        "word_AF": "fokkaaqo",
        "word_ENG": "search",
        "word_AM": "ምርምር /ፍተሻ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17526,
        "word_AF": "mako",
        "word_ENG": "fraud",
        "word_AM": "ማጭበርበር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17568,
        "word_AF": "cukkuko",
        "word_ENG": "friction",
        "word_AM": "መፍጨት /ሰበቃ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17610,
        "word_AF": "diyaaya",
        "word_ENG": "fusion",
        "word_AM": "መቅለጥ/መዋሀድ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17652,
        "word_AF": "ux uddur",
        "word_ENG": "near future",
        "word_AM": "መጭው ቅርብ ጊዜ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17694,
        "word_AF": "xaahi addah niqmata",
        "word_ENG": "mineral deposi",
        "word_AM": "መአድን ሀብት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17736,
        "word_AF": "baddahiyya",
        "word_ENG": "to waste",
        "word_AM": "መባከን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17778,
        "word_AF": "galli",
        "word_ENG": "globe",
        "word_AM": "መሬት /ሉል/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17820,
        "word_AF": "gubunnuqu",
        "word_ENG": "gruming",
        "word_AM": "ማጎሮምሮም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17862,
        "word_AF": "akotta",
        "word_ENG": "grouping",
        "word_AM": "መሰባሰብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17904,
        "word_AF": "wiida",
        "word_ENG": "guide",
        "word_AM": "መንገድ መሪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17946,
        "word_AF": "maxax fukkaaqo",
        "word_ENG": "gynecology",
        "word_AM": "ማህፀን  ምርመራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 17988,
        "word_AF": "maxax fokkaqo abe",
        "word_ENG": "gynecologist",
        "word_AM": "ማህፀን መርማሪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18030,
        "word_AF": "mannoowu",
        "word_ENG": "habitition",
        "word_AM": "መኖር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18072,
        "word_AF": "cokoomat agat miglisih dooro  abta",
        "word_ENG": "government prepare general election",
        "word_AM": "መንግሥት የብሔራዊ ሸንጎ ምርጫ ያካሂዳል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18114,
        "word_AF": "reebu",
        "word_ENG": "haven",
        "word_AM": "መሸሸጊያ ማረፈያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18156,
        "word_AF": "qabaliyya",
        "word_ENG": "bleeding",
        "word_AM": "መድማት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18198,
        "word_AF": "xintônumu",
        "word_ENG": "statesman",
        "word_AM": "መሰተዳድር ሰው",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18240,
        "word_AF": "muggaaqa",
        "word_ENG": "namesake",
        "word_AM": "ሞክሼ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18282,
        "word_AF": "asakaxxiyya",
        "word_ENG": "to honor",
        "word_AM": "ማክበር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18324,
        "word_AF": "akkaloyla",
        "word_ENG": "hyptothesis",
        "word_AM": "መላ ምት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18366,
        "word_AF": "mamaxxaga",
        "word_ENG": "identification",
        "word_AM": "መታወቂያ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18408,
        "word_AF": "kinnaane",
        "word_ENG": "image",
        "word_AM": "ማንነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18450,
        "word_AF": "kinnaane weelo",
        "word_ENG": "idetity",
        "word_AM": "ምስል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18492,
        "word_AF": "gexe kalti",
        "word_ENG": "immobilization",
        "word_AM": "መበተን /እንቅሰቃሴ መግታት /",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18534,
        "word_AF": "waynabo duuqayso",
        "word_ENG": "inauguration",
        "word_AM": "ምረቃ ሥነ-ሥርዓት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18576,
        "word_AF": "matbaqa buxa",
        "word_ENG": "printing house",
        "word_AM": "ማተሚያ ቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18618,
        "word_AF": "fayya - ramma",
        "word_ENG": "disparity",
        "word_AM": "መበላለጥ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18660,
        "word_AF": "umaala",
        "word_ENG": " infection",
        "word_AM": "መመርቀዝ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18702,
        "word_AF": "bedi warsa",
        "word_ENG": "dialing code",
        "word_AM": "መለያ ካድ/ ጥሪ/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18744,
        "word_AF": "addat culo",
        "word_ENG": "infiltration",
        "word_AM": "መሰረግ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18786,
        "word_AF": "oyta",
        "word_ENG": "information",
        "word_AM": "መረጃ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18828,
        "word_AF": "warisiyya",
        "word_ENG": "to inform",
        "word_AM": "መንገር መግለጽ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18870,
        "word_AF": "mansafa",
        "word_ENG": "instrument",
        "word_AM": "መሣሪያ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18912,
        "word_AF": "asgolla",
        "word_ENG": "integration",
        "word_AM": "መዋሀድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18954,
        "word_AF": "tu-yaaxagi",
        "word_ENG": "intellectual",
        "word_AM": "ምሁር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 18996,
        "word_AF": "tu -taaxago",
        "word_ENG": "intelligetsia",
        "word_AM": "ምሁራን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19038,
        "word_AF": "ascossa",
        "word_ENG": "instruction",
        "word_AM": "ማሰተማር አሰተምህሮ/መምሪያ/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19080,
        "word_AF": "kaabiri",
        "word_ENG": " school  teacher",
        "word_AM": "መምህር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19122,
        "word_AF": "waaso",
        "word_ENG": "inter ception",
        "word_AM": "መሀል ላይ ማጨናገፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19164,
        "word_AF": "kalaatisso",
        "word_ENG": "suspension",
        "word_AM": "ማገድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19206,
        "word_AF": "messisso",
        "word_ENG": "intimidation",
        "word_AM": "ማሰፈራራት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19248,
        "word_AF": "aysaxaaxagiyya",
        "word_ENG": " to introduce",
        "word_AM": "ማሰተዋወቅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19290,
        "word_AF": "culma",
        "word_ENG": "introduction",
        "word_AM": "መግቢያ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19332,
        "word_AF": "kusaaqa",
        "word_ENG": "invesigation",
        "word_AM": "ምርመራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19374,
        "word_AF": "reedisiyya",
        "word_ENG": "ivestiture",
        "word_AM": "መሰየም :መሾም ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19416,
        "word_AF": "ardi gubih qawsih waso",
        "word_ENG": "to forbid underground",
        "word_AM": "መሬት ወሰጥ ፍንዳታ ሙከራ ማገድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19458,
        "word_AF": "leeh efeqya",
        "word_ENG": "irrigation",
        "word_AM": "መሰኖ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19500,
        "word_AF": "canxuwwi  assima",
        "word_ENG": "nursery school",
        "word_AM": "መዋፅለ ህፃናት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19542,
        "word_AF": "dubali gaso",
        "word_ENG": "zoo",
        "word_AM": "መካነ አራዊት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19584,
        "word_AF": "leeh afqiyya",
        "word_ENG": "  to irrigate",
        "word_AM": "በመሰኖ ማጠጣት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19626,
        "word_AF": "ayyuntiinô      qadaalata",
        "word_ENG": "social justice",
        "word_AM": "ማህበራዊ ፍትሕ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19668,
        "word_AF": "deeqqitiyya",
        "word_ENG": "to invite",
        "word_AM": "መጋበዝ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19710,
        "word_AF": "maalkyna",
        "word_ENG": "minister",
        "word_AM": "ሚኒሰትር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19752,
        "word_AF": "xiiriyyo",
        "word_ENG": "dismissal",
        "word_AM": "መሰረዝ/ማባረር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19794,
        "word_AF": "askotta",
        "word_ENG": "mobilzation",
        "word_AM": "ማንቀሳቀሰ /ማሰባሰብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19836,
        "word_AF": "gurrane",
        "word_ENG": "modality",
        "word_AM": "ሞዴሊት አርአያነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19878,
        "word_AF": "fanti dabaana",
        "word_ENG": "middle age",
        "word_AM": "መካከለኛ ዘመን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19920,
        "word_AF": "andorya",
        "word_ENG": "reproduction",
        "word_AM": "ማዋለድ: ማባዛት ማምረት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 19962,
        "word_AF": "magaalâ kallayto",
        "word_ENG": "municipality",
        "word_AM": "ማዘጋጃ ቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20004,
        "word_AF": "sugeeti daasa",
        "word_ENG": "musuem",
        "word_AM": "ሙዝየም: ቤተ መዘክር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20046,
        "word_AF": "gadaaba",
        "word_ENG": "musician",
        "word_AM": "ሙዚቀኛ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20088,
        "word_AF": "farmoyta",
        "word_ENG": "messenger",
        "word_AM": "መልዕክተኛ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20130,
        "word_AF": "niyah hayti",
        "word_ENG": "motivation",
        "word_AM": "መገፋፋት;ማነሳሳት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20172,
        "word_AF": "kuraabiyyo",
        "word_ENG": "division",
        "word_AM": "ማካፈል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20214,
        "word_AF": "qadada",
        "word_ENG": "amount",
        "word_AM": "መጠን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20256,
        "word_AF": "fanti  - udduru",
        "word_ENG": "middle tern",
        "word_AM": "መካከለኛ ተርም ጊዜ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20298,
        "word_AF": "cizibette manga",
        "word_ENG": "malti part",
        "word_AM": "መድበለ ፓርቲ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20340,
        "word_AF": "cagla",
        "word_ENG": "monopoly",
        "word_AM": "ሞኖፓሊ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20382,
        "word_AF": "lee racu",
        "word_ENG": "ground ",
        "word_AM": "ምንጭ ውሃ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20424,
        "word_AF": "taabukô manginta",
        "word_ENG": "birthrate",
        "word_AM": "መጠን :ውልደት:የሚወለዱት ቁጥር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20466,
        "word_AF": "kanniyi",
        "word_ENG": "music",
        "word_AM": "ሙዚቃ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20508,
        "word_AF": "safriseyna",
        "word_ENG": "navigator",
        "word_AM": "መንገድ መሪ /ባህር ላይ/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20550,
        "word_AF": "muura",
        "word_ENG": "school mark",
        "word_AM": "ማርክ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20592,
        "word_AF": "taama saami acayiyya",
        "word_ENG": "job offer",
        "word_AM": "መሰጠት የሥራ እድል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20634,
        "word_AF": "hawweeni",
        "word_ENG": "forgetness",
        "word_AM": "መርሳት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20676,
        "word_AF": "sirri - taama",
        "word_ENG": "secret operation",
        "word_AM": "ምሰጢራዊ አሠራር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20718,
        "word_AF": "dooriti",
        "word_ENG": " option",
        "word_AM": "ምርጫ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20760,
        "word_AF": "caleyta",
        "word_ENG": "orbit",
        "word_AM": "ምህዋር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20802,
        "word_AF": "maaca",
        "word_ENG": "east",
        "word_AM": "ምሰራቅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20844,
        "word_AF": "carra",
        "word_ENG": "west",
        "word_AM": "ምዕራብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20886,
        "word_AF": "mansafa",
        "word_ENG": "tool",
        "word_AM": "መሣሪያ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20928,
        "word_AF": "maasayya",
        "word_ENG": "paragraph",
        "word_AM": "ምዕራፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 20970,
        "word_AF": "gaba assagalliyya",
        "word_ENG": "to participate",
        "word_AM": "መሣተፍ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21012,
        "word_AF": "baaxô weelo",
        "word_ENG": "landscape ",
        "word_AM": "መልክዓ ምድር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21054,
        "word_AF": "mekliyya",
        "word_ENG": "to pay ",
        "word_AM": "መክፈል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21096,
        "word_AF": "kabiiri",
        "word_ENG": "teacher",
        "word_AM": "መምህር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21138,
        "word_AF": "qunxa digaala",
        "word_ENG": "penalty punishments",
        "word_AM": "መቀጫ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21180,
        "word_AF": "baabure beytoh sumaqta",
        "word_ENG": "driving licence",
        "word_AM": "መንጃ ፈቃድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21222,
        "word_AF": "boohyse'",
        "word_ENG": "drill",
        "word_AM": "መብሻ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21264,
        "word_AF": "diwâ qari",
        "word_ENG": "pharmacy",
        "word_AM": "መድሀኒት  ቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21306,
        "word_AF": "uman faala",
        "word_ENG": "pessimism",
        "word_AM": "ሟርት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21348,
        "word_AF": "qaran mirraytu",
        "word_ENG": "tak off run way",
        "word_AM": "ማኮብኮብያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21390,
        "word_AF": "kalsiti",
        "word_ENG": "speech for the defence",
        "word_AM": "መከላከያ ንግግር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21432,
        "word_AF": "tellemmoh ekraaro",
        "word_ENG": "plan of marketing",
        "word_AM": "መገበያያ ፕላን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21474,
        "word_AF": "inkih yan wakti",
        "word_ENG": "ful time",
        "word_AM": "ሙሉ ጊዜ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21516,
        "word_AF": "sidiica konooy alsa",
        "word_ENG": "full moon",
        "word_AM": "ሙሉ ጨረቃ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21558,
        "word_AF": "fanti qilsa",
        "word_ENG": "middle weight",
        "word_AM": "መካከለኛ ክብደት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21600,
        "word_AF": "malkitiyya",
        "word_ENG": " to raise  a compliant",
        "word_AM": "መከሰስ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21642,
        "word_AF": "fuli mangba",
        "word_ENG": "majority absolved",
        "word_AM": "መጨረሻ አብላጫ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21684,
        "word_AF": "amarraqa",
        "word_ENG": "end",
        "word_AM": "መጨረሻ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21726,
        "word_AF": "edde orba",
        "word_ENG": "final",
        "word_AM": "መደምደሚያ /ፍፃሜ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21768,
        "word_AF": "baqu",
        "word_ENG": "fission",
        "word_AM": "መሰነጣጠቅ /መከፋፈል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21810,
        "word_AF": "sabo",
        "word_ENG": "steam flow",
        "word_AM": "ሞገድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21852,
        "word_AF": "ayyunti taama abe",
        "word_ENG": "civil sarvent",
        "word_AM": "መንግስት ሠራተኛ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21894,
        "word_AF": "rakibisso",
        "word_ENG": "foundamental",
        "word_AM": "መሠረታዊ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21936,
        "word_AF": "ukmeyna",
        "word_ENG": "founder",
        "word_AM": "መሰራች",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 21978,
        "word_AF": "rakiibo",
        "word_ENG": "foundation",
        "word_AM": "መሠረት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22020,
        "word_AF": "meqe digiri",
        "word_ENG": "fair play",
        "word_AM": "ሚዛናዊነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22062,
        "word_AF": "baacitiyya",
        "word_ENG": " to go   bankrupt",
        "word_AM": "መክሰር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22104,
        "word_AF": "boonu",
        "word_ENG": "check",
        "word_AM": "ቼክ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22146,
        "word_AF": "xiqto",
        "word_ENG": "capacity",
        "word_AM": "ችሎታ /አቅም ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22188,
        "word_AF": "boonwa",
        "word_ENG": " pad of check",
        "word_AM": "ቼክ /የ/ጥራዝ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22230,
        "word_AF": "awlaytu",
        "word_ENG": "chancellor",
        "word_AM": "ቻንስሌር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22272,
        "word_AF": "awliinu",
        "word_ENG": "chancellery",
        "word_AM": "ቻንሲሌሪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22314,
        "word_AF": "charteri",
        "word_ENG": "charter",
        "word_AM": "ቻርተር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22356,
        "word_AF": "keemiyyậ dayla",
        "word_ENG": "chemotherapy",
        "word_AM": "ቼመትራፒ/የ/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22398,
        "word_AF": "ceya",
        "word_ENG": "crisis",
        "word_AM": "ችግር : ጠንቅ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22440,
        "word_AF": "baaqid-sinna",
        "word_ENG": "carelessnes",
        "word_AM": "ቸልተኝነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22482,
        "word_AF": "gibdi-abinaqutubusiyya",
        "word_ENG": "to mitigate a difficulty",
        "word_AM": "ችግር ማቃለል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22524,
        "word_AF": "dubba",
        "word_ENG": "qualification",
        "word_AM": "ችሎታ ብቃት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22566,
        "word_AF": "inki  gexộ tikeeti",
        "word_ENG": "one way ticket",
        "word_AM": "ነጠላ ጉዞ ትኬት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22608,
        "word_AF": "yaaba",
        "word_ENG": "speech",
        "word_AM": "ንግግር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22650,
        "word_AF": "makefta",
        "word_ENG": "district",
        "word_AM": "ንዑስ ቀበሌ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22692,
        "word_AF": "kokkobi gira",
        "word_ENG": "nuclear weapons chemical",
        "word_AM": "ንኩሌር /የኬሚካል መሥሪያ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22734,
        "word_AF": "kabxah  adaffite",
        "word_ENG": "commercial barriers",
        "word_AM": "ንግድ እንቅፋቶች",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22776,
        "word_AF": "qeexaalu",
        "word_ENG": "commercial balance",
        "word_AM": "ንግር መመጣጠን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22818,
        "word_AF": "dubeysi",
        "word_ENG": "middle-class person",
        "word_AM": "ንዑስ ከበርቴ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22860,
        "word_AF": "sessactu",
        "word_ENG": "cancer",
        "word_AM": "ነቀርሳ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22902,
        "word_AF": "kokkobȋ dudda",
        "word_ENG": "nuclear capacity",
        "word_AM": "ንኩሌር አቅም ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22944,
        "word_AF": "kabxa abeyna",
        "word_ENG": "nan",
        "word_AM": "ነጋዴ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 22986,
        "word_AF": "kabxá",
        "word_ENG": "business",
        "word_AM": "ንግድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23028,
        "word_AF": "amô baxxaqqa-le agat maro",
        "word_ENG": "independent national commission",
        "word_AM": "ነፃ ብሕራዊ ኮሚሽን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23070,
        "word_AF": "ittal wagitto",
        "word_ENG": "comparison",
        "word_AM": "ንፅፅር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23112,
        "word_AF": "waaso sinni atka",
        "word_ENG": "free kick",
        "word_AM": "ነፃ ምት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23154,
        "word_AF": "ikoytâ finqih baatili",
        "word_ENG": "crimes and offences againest the possessions",
        "word_AM": "ንብረት ማጥፋት ወንጀል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23196,
        "word_AF": "maysabaka",
        "word_ENG": "design",
        "word_AM": "ንድፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23238,
        "word_AF": "currictan qadaagah mdduru",
        "word_ENG": "free market economy",
        "word_AM": "ነፃ /የ/ገበያ ኢኮኖሚ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23280,
        "word_AF": "fadamiino",
        "word_ENG": "eloquence",
        "word_AM": "ንግግር ችሎት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23322,
        "word_AF": "lagoh ixxiga",
        "word_ENG": "ethnology",
        "word_AM": "ንፅፅራዊ የስው ዘሮች ጥናት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23364,
        "word_AF": "lago gedsé",
        "word_ENG": "ethnologist",
        "word_AM": "ንፅፅራዊ የስው ዘሮች አጥኚ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23406,
        "word_AF": "nukleer qawiti",
        "word_ENG": "nuclear reactor",
        "word_AM": "ኒኩሌር ፍንዳታ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23448,
        "word_AF": "sirag-lee",
        "word_ENG": "fuel",
        "word_AM": "ነዳጅ ዘይት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23490,
        "word_AF": "kabxâ xiinisso",
        "word_ENG": "commercial management",
        "word_AM": "ንግድ አስተዳደር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23532,
        "word_AF": "sirag-leé gadda",
        "word_ENG": "oil-field",
        "word_AM": "ነዳጅ ሀብት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23574,
        "word_AF": "ardi-sombolooloco",
        "word_ENG": "landslide",
        "word_AM": "ናዳ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23616,
        "word_AF": "sigeyna",
        "word_ENG": "inhabitant",
        "word_AM": "ነዋሪ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23658,
        "word_AF": "foyyah tan baritto",
        "word_ENG": "free education",
        "word_AM": "ነፃ ትምህርት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23700,
        "word_AF": "curriyata",
        "word_ENG": "independence",
        "word_AM": "ነፃነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23742,
        "word_AF": "baaqid sinna",
        "word_ENG": "indifference",
        "word_AM": "ንዝህላልነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23784,
        "word_AF": "baaqidmali",
        "word_ENG": "indifferent",
        "word_AM": "ንዝህላል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23826,
        "word_AF": "qunxa daylaabe",
        "word_ENG": "nurse",
        "word_AM": "ነርስ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23868,
        "word_AF": "garci",
        "word_ENG": "innocence",
        "word_AM": "ንጽህና /የህልና/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23910,
        "word_AF": "currik yan yaybalaalabe",
        "word_ENG": "independent journalist",
        "word_AM": "ነፃ ጋዜጠኛ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23952,
        "word_AF": "amoyta",
        "word_ENG": "monarch",
        "word_AM": "ንጉሥ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 23994,
        "word_AF": "naanometri",
        "word_ENG": "nanometer",
        "word_AM": "ናኖሜትር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24036,
        "word_AF": "maxhaxa",
        "word_ENG": "homesickness",
        "word_AM": "ናፍቆት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24078,
        "word_AF": "kokkobi",
        "word_ENG": "nuclear",
        "word_AM": "ኑክሌር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24120,
        "word_AF": "sirag-lee rubta baaxooxahmassoyna",
        "word_ENG": "organization of the exporter countries of  the petroleum",
        "word_AM": "ነዳጅ ላኪ አገሮች ድርጅት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24162,
        "word_AF": "siraglee",
        "word_ENG": "petroleum",
        "word_AM": "ነዳጅ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24204,
        "word_AF": "amoyta",
        "word_ENG": "king",
        "word_AM": "ንጉስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24246,
        "word_AF": "amoyti wano",
        "word_ENG": "kingdom",
        "word_AM": "ንጉሳዊ ግዛት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24288,
        "word_AF": "amoytiino",
        "word_ENG": "monarchy",
        "word_AM": "ንጉሳዊ አገዛዝ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24330,
        "word_AF": "saytunaane",
        "word_ENG": "hygienic",
        "word_AM": "ንጽህናው የተጠበቀ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24372,
        "word_AF": "sirag-lee-culenta",
        "word_ENG": "petroleum revenue",
        "word_AM": "ነዳጅ ገቢ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24414,
        "word_AF": "yabti haxaxa",
        "word_ENG": "rhetoric",
        "word_AM": "ንግግር ማሳመር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24456,
        "word_AF": "moddaqik tan egla",
        "word_ENG": "free society",
        "word_AM": "ነፃ ማህበር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24498,
        "word_AF": "manô cogda",
        "word_ENG": "life style",
        "word_AM": "ኑሮ ዘዴ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24540,
        "word_AF": "sigô-karata",
        "word_ENG": "residence tax",
        "word_AM": "ኗሪነት ቀረጥ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24582,
        "word_AF": "mala",
        "word_ENG": "theory",
        "word_AM": "ንድፈ ሀሣብ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24624,
        "word_AF": "nagus kee raqiyyata",
        "word_ENG": "the king and the subjects",
        "word_AM": "ንጉሱና ገባሮቹ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24666,
        "word_AF": "moddaqiino",
        "word_ENG": "free dome",
        "word_AM": "ነፃነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24708,
        "word_AF": "curri",
        "word_ENG": "free",
        "word_AM": "ነፃ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24750,
        "word_AF": "currik tan kobbani",
        "word_ENG": "free enterprise",
        "word_AM": "ነፃ ካምፓኒ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24792,
        "word_AF": "kabxa abeyna",
        "word_ENG": "trader",
        "word_AM": "ነጋዴ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24834,
        "word_AF": "currik tankabxa",
        "word_ENG": "free trade",
        "word_AM": "ነፃ ንግድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24876,
        "word_AF": "caxaaxuwi manginta",
        "word_ENG": "abundance of vegetables",
        "word_AM": "አትክልት መትረፍረፍ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24918,
        "word_AF": "xayyoowiyya",
        "word_ENG": "to approach",
        "word_AM": "አቀራረብ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 24960,
        "word_AF": "suge-wayti,cerra",
        "word_ENG": "absence",
        "word_AM": "አለመገኘት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25002,
        "word_AF": "kibal gano",
        "word_ENG": "betrayal of trust",
        "word_AM": "እምነት ክዳት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25044,
        "word_AF": "akkadaamiita",
        "word_ENG": "academician",
        "word_AM": "አካዳሚሺን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25086,
        "word_AF": "akkaadami",
        "word_ENG": "academy",
        "word_AM": "አካዳሚ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25128,
        "word_AF": "ittin-geyi",
        "word_ENG": "compromise",
        "word_AM": "አስታራቂ ሀሣብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25170,
        "word_AF": "wallê gabah agra",
        "word_ENG": "acclamation",
        "word_AM": "አድናቆት ጭብጨባ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25212,
        "word_AF": "muluc",
        "word_ENG": "acid",
        "word_AM": "አሲድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25254,
        "word_AF": "masada",
        "word_ENG": "steel",
        "word_AM": "አረብ ብረት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25296,
        "word_AF": "ransiisé",
        "word_ENG": "actor",
        "word_AM": "አክተር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25338,
        "word_AF": "taburyé/á",
        "word_ENG": "activist",
        "word_AM": "አንቀሳቃሽ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25380,
        "word_AF": "qusbá maacisso",
        "word_ENG": "current events",
        "word_AM": "አዲስ ክስትቶች /",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25422,
        "word_AF": "angoyya",
        "word_ENG": "movement",
        "word_AM": "እንቅስቃሴ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25464,
        "word_AF": "adoytiinu",
        "word_ENG": "membership",
        "word_AM": "አባልነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25506,
        "word_AF": "mago",
        "word_ENG": "debt",
        "word_AM": "አዳ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25548,
        "word_AF": "xintoh abba",
        "word_ENG": "administrator",
        "word_AM": "አስተዳዳሪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25590,
        "word_AF": "taama gexsé",
        "word_ENG": "executive",
        "word_AM": "አስፈፃሚ ዳይሬክተር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25632,
        "word_AF": "guubu",
        "word_ENG": "address",
        "word_AM": "አድራሻ /ቦታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25674,
        "word_AF": "tayyaarâ booxa",
        "word_ENG": "airport",
        "word_AM": "አየር ማረፍያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25716,
        "word_AF": "tayyaara merra",
        "word_ENG": "air born",
        "word_AM": "አየር ወለድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25758,
        "word_AF": "kinna",
        "word_ENG": "affirmative",
        "word_AM": "እውነታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25800,
        "word_AF": "hadaf",
        "word_ENG": "agenda",
        "word_AM": "አጀንዳ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25842,
        "word_AF": "osak osa qawwalayla",
        "word_ENG": "escalation of risk",
        "word_AM": "አደጋ ማባባስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25884,
        "word_AF": "buqrek decarsitto",
        "word_ENG": "agro-pastoral",
        "word_AM": "አግሮ ፖስቶራል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25926,
        "word_AF": "cato",
        "word_ENG": "assistance",
        "word_AM": "እርዳት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 25968,
        "word_AF": "sissik cato",
        "word_ENG": "urgent assistance",
        "word_AM": "አስቸኳይ እርዳት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26010,
        "word_AF": "gocoyu",
        "word_ENG": "alcorol",
        "word_AM": "አልኮል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26052,
        "word_AF": "kamritiyya",
        "word_ENG": "alcolism",
        "word_AM": "አልኮልነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26094,
        "word_AF": "aljebra",
        "word_ENG": "algebra",
        "word_AM": "አልጄብራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26136,
        "word_AF": "elle-raaqa",
        "word_ENG": "alternative",
        "word_AM": "አማራጭ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26178,
        "word_AF": "alemunyem",
        "word_ENG": "aluminum",
        "word_AM": "አለሙንየም ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26220,
        "word_AF": "faykabtoli",
        "word_ENG": "amateur",
        "word_AM": "አማተር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26262,
        "word_AF": "safaarata",
        "word_ENG": "embassy",
        "word_AM": "ኢምባሲ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26304,
        "word_AF": "safiiri",
        "word_ENG": "ambassador",
        "word_AM": "አምባሳደር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26346,
        "word_AF": "wassaaka",
        "word_ENG": "ambulance",
        "word_AM": "አምቡላንስ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26388,
        "word_AF": "magô salaca",
        "word_ENG": "amortization",
        "word_AM": "እዳ ቅነሣ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26430,
        "word_AF": "maddur makeelisé",
        "word_ENG": "economy analyst",
        "word_AM": "ኢኮኖሚ ተንታኝ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26472,
        "word_AF": "daburseyna",
        "word_ENG": "driving force",
        "word_AM": "አንቀሳቃሽ ኃይል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26514,
        "word_AF": "liggidal",
        "word_ENG": "annual",
        "word_AM": "አመታዊ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26556,
        "word_AF": "liggidi mandabba",
        "word_ENG": "anniversary",
        "word_AM": "አመት በዓል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26598,
        "word_AF": "antarkitiki",
        "word_ENG": "antarctic",
        "word_AM": "አንትርኪቲክ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26640,
        "word_AF": "anteena",
        "word_ENG": "antenna",
        "word_AM": "አንቴና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26682,
        "word_AF": "marreysiti",
        "word_ENG": "affiliation",
        "word_AM": "አካልነት /የጎሣ/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26724,
        "word_AF": "ubukya",
        "word_ENG": "tribal affiliation",
        "word_AM": "አባልነት /የጎሣ /",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26766,
        "word_AF": "baddi-amiiri",
        "word_ENG": "admiral",
        "word_AM": "አድሚራል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26808,
        "word_AF": "gagbe",
        "word_ENG": "attacker",
        "word_AM": "አጥቂ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26850,
        "word_AF": "asli",
        "word_ENG": "authentic",
        "word_AM": "እውነተኛ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26892,
        "word_AF": "asliinu",
        "word_ENG": "authencity",
        "word_AM": "እውነተኝነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26934,
        "word_AF": "ottomaatik",
        "word_ENG": "automatic",
        "word_AM": "አወቶማቲክ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 26976,
        "word_AF": "meklah addah xinto",
        "word_ENG": "managerial autonomy",
        "word_AM": "አስተዳደር ነፃነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27018,
        "word_AF": "nummah",
        "word_ENG": "de facto authority",
        "word_AM": "እውነተኛ ሥልጣን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27060,
        "word_AF": "xayyoosiyya",
        "word_ENG": "to-approach",
        "word_AM": "አቃራረብ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27102,
        "word_AF": "arkelooji",
        "word_ENG": "archaeology",
        "word_AM": "አርኪዮሎጂ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27144,
        "word_AF": "arkeeloojist",
        "word_ENG": "archaeologist",
        "word_AM": "አርኪዮሎጅስት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27186,
        "word_AF": "qaran qande",
        "word_ENG": "air force",
        "word_AM": "አየር ኃይል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27228,
        "word_AF": "fannaanâ",
        "word_ENG": "artist",
        "word_AM": "አርስት ; ሳአሊ; የጥበብ ስው",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27270,
        "word_AF": "qokolu",
        "word_ENG": "assistance",
        "word_AM": "እገዛ : እርዳታ ስብስባ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27312,
        "word_AF": "taamisiise",
        "word_ENG": "operator",
        "word_AM": "ኦፕሬትር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27354,
        "word_AF": "istiraateejî silaaca",
        "word_ENG": "strategic armaments",
        "word_AM": "እስቲራቴጅክ ጦር መሳሪያ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27396,
        "word_AF": "maddur xoqoysi",
        "word_ENG": "economic advantage",
        "word_AM": "ኢኮኖሚ ጥቅም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27438,
        "word_AF": "afrikah eglah sarrimaane",
        "word_ENG": "the future of africa union",
        "word_AM": "አፍሪካ ህብረት የወደፊት ዕጣ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27480,
        "word_AF": "haadise",
        "word_ENG": "air man",
        "word_AM": "አየር ሀይል ወታደር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27522,
        "word_AF": "qaran meerraytih madaddaara",
        "word_ENG": "aviation",
        "word_AM": "አየር መመላለሻ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27564,
        "word_AF": "haadeena",
        "word_ENG": "plane",
        "word_AM": "አይሮፕላን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27606,
        "word_AF": "axawa",
        "word_ENG": "band",
        "word_AM": "እስር /ጥቅል /ገጽ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27648,
        "word_AF": "kas muda",
        "word_ENG": "baron some drug",
        "word_AM": "አዳንዛዥ ዕጽ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27690,
        "word_AF": "kitooba dacrise",
        "word_ENG": "librarian",
        "word_AM": "አቃቢ መጽሀፍት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27732,
        "word_AF": "lamma intili",
        "word_ENG": "binocular",
        "word_AM": "አቅራብ መነፀር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27774,
        "word_AF": "caggiinu",
        "word_ENG": "polygamy",
        "word_AM": "አንድ ሚስት በላይ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27816,
        "word_AF": "boxooxocu",
        "word_ENG": "aperitif",
        "word_AM": "አፕሬቲቭ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27858,
        "word_AF": "qaran maysataka",
        "word_ENG": "air bombardment",
        "word_AM": "አየር ደብደባ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27900,
        "word_AF": "yarcidi",
        "word_ENG": "butcher",
        "word_AM": "አራጅ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27942,
        "word_AF": "barittoô saami",
        "word_ENG": "scholarship",
        "word_AM": "እስኮላርሽፕ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 27984,
        "word_AF": "faxté",
        "word_ENG": "candidate",
        "word_AM": "እጩ ተዳዳሪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28026,
        "word_AF": "hadafah aban taama",
        "word_ENG": "non profit making purpose",
        "word_AM": "አላማ /የሚስራ  ሥራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28068,
        "word_AF": "caglâ caala",
        "word_ENG": "characteristic",
        "word_AM": "አይነተኛ ጠባይ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28110,
        "word_AF": "koros sheeki",
        "word_ENG": "cardinal",
        "word_AM": "አብይ ቄስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28152,
        "word_AF": "arkitiik maroyta",
        "word_ENG": "arctic circle",
        "word_AM": "አርክቲክ ክብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28194,
        "word_AF": "celeemânnu",
        "word_ENG": "championship",
        "word_AM": "አሽናፊነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28236,
        "word_AF": "qaffayda",
        "word_ENG": "celebration",
        "word_AM": "አከባበር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28278,
        "word_AF": "gabaak",
        "word_ENG": "cash",
        "word_AM": "እጅ በእጅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28320,
        "word_AF": "saami",
        "word_ENG": "chance",
        "word_AM": "እድል/ድንገተኛ እድል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28362,
        "word_AF": "celemi",
        "word_ENG": "champion",
        "word_AM": "አሽናፊ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28404,
        "word_AF": "qasa ankâ baad maro",
        "word_ENG": "international comiittee of red cross",
        "word_AM": "አለም አቀፍ ቀይ መስቀል ኮሚቴ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28446,
        "word_AF": "amriseyna",
        "word_ENG": "order giver",
        "word_AM": "አዛዥ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28488,
        "word_AF": "yasgaarawi",
        "word_ENG": "communicator",
        "word_AM": "አገናኝ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28530,
        "word_AF": "qafar ummatta",
        "word_ENG": "afar community",
        "word_AM": "/የ/አፋር  ህዝብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28572,
        "word_AF": "inki baaxoh mariinu",
        "word_ENG": "belonging to one regin",
        "word_AM": "/የ/አንድ ሀገር ልጅነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28614,
        "word_AF": "maknay maqaane",
        "word_ENG": "convenience",
        "word_AM": "አመቺነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28656,
        "word_AF": "xintoh afâ saqala",
        "word_ENG": "administrative department head",
        "word_AM": "አስተዳደር አገልግሎት  ኃላፊ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28698,
        "word_AF": "baaxohabba",
        "word_ENG": "leader of state",
        "word_AM": "አገር መሪ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28740,
        "word_AF": "qalaama",
        "word_ENG": "target",
        "word_AM": "ኢላማ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28782,
        "word_AF": "rosqa",
        "word_ENG": "climate",
        "word_AM": "አየር ንብረት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28824,
        "word_AF": "walwalitiyya",
        "word_ENG": "air conditioning",
        "word_AM": "አየር ማጦዝ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28866,
        "word_AF": "xabcâ buufe",
        "word_ENG": "air conditioner",
        "word_AM": "አየር ማጤዣ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28908,
        "word_AF": "yaysaali",
        "word_ENG": "clown",
        "word_AM": "አስቂኝ ተዋናይ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28950,
        "word_AF": "fanti bica",
        "word_ENG": "compromise",
        "word_AM": "አስታራቂ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 28992,
        "word_AF": "digga le weelo",
        "word_ENG": "conform",
        "word_AM": "አስማሚ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29034,
        "word_AF": "kibaala",
        "word_ENG": "confidence",
        "word_AM": "እምነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29076,
        "word_AF": "ceele sinni kibaala",
        "word_ENG": "implicit trust",
        "word_AM": "አጉል እምነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29118,
        "word_AF": "gabbaaqu",
        "word_ENG": "imitated",
        "word_AM": "አስመስሎ መሥራት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29160,
        "word_AF": "gabatagle",
        "word_ENG": "contribution",
        "word_AM": "አስተዋፅኦ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29202,
        "word_AF": "duddale qika",
        "word_ENG": "actual cooperation",
        "word_AM": "አስፈላጊ ትብብር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29244,
        "word_AF": "baad ittin qokolu",
        "word_ENG": "international cooperation",
        "word_AM": "አለም አቀፍ ትብብር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29286,
        "word_AF": "koobaahisé",
        "word_ENG": "coordinator",
        "word_AM": "አስተባባሪ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29328,
        "word_AF": "koobaahisso",
        "word_ENG": "coordination",
        "word_AM": "አስተባባሪነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29370,
        "word_AF": "buqreh egla",
        "word_ENG": "agricultural cooperation",
        "word_AM": "እርሻ ማህበር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29412,
        "word_AF": "massoysiyya",
        "word_ENG": "correction",
        "word_AM": "እርማት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29454,
        "word_AF": "tabseyna",
        "word_ENG": "correspondent",
        "word_AM": "አስተላላፊ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29496,
        "word_AF": "baad kaaqunta",
        "word_ENG": "world cup",
        "word_AM": "አለም ዋንጫ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29538,
        "word_AF": "ux udduru",
        "word_ENG": "short term",
        "word_AM": "አጭር ጊዜ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29580,
        "word_AF": "i-meeli",
        "word_ENG": "e-mail",
        "word_AM": "ኢሜይል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29622,
        "word_AF": "waagale magoyta",
        "word_ENG": "bad debt",
        "word_AM": "አጠራጣሪ እዳ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29664,
        "word_AF": "magoytali",
        "word_ENG": "creditor",
        "word_AM": "አበዳሪ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29706,
        "word_AF": "ux uddurih abuudu",
        "word_ENG": "short term credit",
        "word_AM": "አጭር ጊዜ ብድር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29748,
        "word_AF": "maddur gadangaddi",
        "word_ENG": "economic crisis",
        "word_AM": "ኢኮኖሚ ችግር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29790,
        "word_AF": "maddur dadala",
        "word_ENG": "economic growth",
        "word_AM": "ኢኮኖሚ እድገት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29832,
        "word_AF": "iimaana",
        "word_ENG": "faith",
        "word_AM": "እምነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29874,
        "word_AF": "maddur mermertu",
        "word_ENG": "economic cycle",
        "word_AM": "ኢኮኖሚ ዑደት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29916,
        "word_AF": "katara",
        "word_ENG": "danger",
        "word_AM": "አደጋ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 29958,
        "word_AF": "tabanti carsa",
        "word_ENG": "decathlon",
        "word_AM": "አሥር አይነት ጨዎታ መሳተፍ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30000,
        "word_AF": "tabna liggida",
        "word_ENG": "decade",
        "word_AM": "አስር ዓመት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30042,
        "word_AF": "fanteenâ salaca",
        "word_ENG": "decentralization",
        "word_AM": "ኢ-ማዕከላዊነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30084,
        "word_AF": "yifdigeh",
        "word_ENG": "discharged",
        "word_AM": "አራጋፊ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30126,
        "word_AF": "giragexoh ekeka",
        "word_ENG": "fire alarm",
        "word_AM": "እሳት ቃጠሎ መግለጫ  ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30168,
        "word_AF": "seehadayti garwak baad madqa",
        "word_ENG": "universal statement of human right",
        "word_AM": "አለም አቀፍ የስው ልጆች መብት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30210,
        "word_AF": "habuubu",
        "word_ENG": "take off",
        "word_AM": "ኤሮፕላን መነሳት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30252,
        "word_AF": "maddur salaca",
        "word_ENG": "economic deficit",
        "word_AM": "ኢኮኖሚ ክስረት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30294,
        "word_AF": "massa-massa",
        "word_ENG": "equal to equal",
        "word_AM": "እኩል ለእኩል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30336,
        "word_AF": "yabtihaxaxa",
        "word_ENG": "demagogy",
        "word_AM": "አፈ ጮሌነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30378,
        "word_AF": "dadala",
        "word_ENG": "growth",
        "word_AM": "እድገት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30420,
        "word_AF": "suissik xaagu",
        "word_ENG": "news item",
        "word_AM": "አስቸኳይ ዜና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30462,
        "word_AF": "h.i.v. raatisso",
        "word_ENG": "search of h.i.v.",
        "word_AM": "ኤች. አይ . ቪ/የ/ክትትል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30504,
        "word_AF": "maddur rikecabti",
        "word_ENG": "economic disadvantage",
        "word_AM": "ኢኮኖሚ ጉዳት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30546,
        "word_AF": "gabah badsa",
        "word_ENG": "dis information",
        "word_AM": "አውቆ ማደናገር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30588,
        "word_AF": "inkiqaxih xagnidiglo",
        "word_ENG": "unilateral denunciation of the pact",
        "word_AM": "አንድ /በ/ወገን የሚፈርስ  ቃል ኪዳን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30630,
        "word_AF": "xacac wayti",
        "word_ENG": "destabilization",
        "word_AM": "አለመረጋጋት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30672,
        "word_AF": "kadara",
        "word_ENG": "fate",
        "word_AM": "እድል: እጣ የአላህ  ፍርጃ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30714,
        "word_AF": "casbime",
        "word_ENG": "prisoner",
        "word_AM": "እስረኛ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30756,
        "word_AF": "finqise",
        "word_ENG": "devastating",
        "word_AM": "አጥፈ /አውዳሚ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30798,
        "word_AF": "dadala",
        "word_ENG": "development",
        "word_AM": "እድገት : ልማት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30840,
        "word_AF": "dikkâ taturli",
        "word_ENG": "dictator",
        "word_AM": "አምባገነን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30882,
        "word_AF": "dikkâ tatriinu",
        "word_ENG": "dictator ship",
        "word_AM": "አምባጋነንነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30924,
        "word_AF": "mohood gexsiisi",
        "word_ENG": "direction",
        "word_AM": "አቅጣጫ  /ማስተዳደር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 30966,
        "word_AF": "ascossi",
        "word_ENG": "directive",
        "word_AM": "አቅጣጫ መጠቆም ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31008,
        "word_AF": "kookaxawa",
        "word_ENG": "disharmonic",
        "word_AM": "አለመስማት /መጨቃጨቅ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31050,
        "word_AF": "akaalafa",
        "word_ENG": "disagreement",
        "word_AM": "አለማግባባት/የሃሣብ  ልዩነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31092,
        "word_AF": "inkiimitorbe wayti",
        "word_ENG": "discord",
        "word_AM": "አለማስማማት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31134,
        "word_AF": "mahdaba",
        "word_ENG": "doctrine",
        "word_AM": "እምነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31176,
        "word_AF": "marduufu",
        "word_ENG": "double",
        "word_AM": "እጥፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31218,
        "word_AF": "kullum admoh cakki",
        "word_ENG": "rights of peach",
        "word_AM": "አሣ የማስገር መብት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31260,
        "word_AF": "kas muda",
        "word_ENG": "drug",
        "word_AM": "እጽ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31302,
        "word_AF": "baad badih caddo",
        "word_ENG": "international waters",
        "word_AM": "አለም አቀፍ ውሃ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31344,
        "word_AF": "ekkograafi",
        "word_ENG": "ultra sound",
        "word_AM": "አልትራሳውንድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31386,
        "word_AF": "kooran bicse",
        "word_ENG": "electrician",
        "word_AM": "ኤሌክትሪክ ስራተኛ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31428,
        "word_AF": "madduru",
        "word_ENG": "economy ",
        "word_AM": "ኢኮኖሚ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31470,
        "word_AF": "massalaalaqa",
        "word_ENG": "screen",
        "word_AM": "እስክሪን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31512,
        "word_AF": "yatbiqi",
        "word_ENG": "publisher editor",
        "word_AM": "አሳታሚ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31554,
        "word_AF": "missoowu",
        "word_ENG": "equality",
        "word_AM": "እኩልነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31596,
        "word_AF": "geytô-missowu",
        "word_ENG": "equality of access",
        "word_AM": "እኩል እድል ማገኘት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31638,
        "word_AF": "kooran xakbe",
        "word_ENG": "electrician of maintenance",
        "word_AM": "ኤሌክትረክ ጠጋኝ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31680,
        "word_AF": "koorana",
        "word_ENG": "electronics",
        "word_AM": "ኤሌክትሮኒክ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31722,
        "word_AF": "yab yaaxigi",
        "word_ENG": "eloquent speaker",
        "word_AM": "አንደበተ ርቱእ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31764,
        "word_AF": "uguugutu",
        "word_ENG": "revolt",
        "word_AM": "አመጽ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31806,
        "word_AF": "ugguguta",
        "word_ENG": "rioters",
        "word_AM": "አመጸኞች",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31848,
        "word_AF": "dula",
        "word_ENG": "emigration",
        "word_AM": "አገር ለቆ መሄድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31890,
        "word_AF": "ammiri",
        "word_ENG": "emir",
        "word_AM": "አሚር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31932,
        "word_AF": "illalta",
        "word_ENG": "emperor",
        "word_AM": "አፄ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 31974,
        "word_AF": "illalti wano",
        "word_ENG": "empire",
        "word_AM": "አፄ /የ/ግዛት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32016,
        "word_AF": "tamsiise",
        "word_ENG": "employer",
        "word_AM": "አስሪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32058,
        "word_AF": "barseyna",
        "word_ENG": "teacher",
        "word_AM": "አስተማሪ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32100,
        "word_AF": "ittaliino",
        "word_ENG": "group",
        "word_AM": "አብሮነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32142,
        "word_AF": "yaydakaakani",
        "word_ENG": "trainer",
        "word_AM": "አስልጣኝ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32184,
        "word_AF": "siba",
        "word_ENG": "envelope",
        "word_AM": "ኤንቨሎፕ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32226,
        "word_AF": "deraafi",
        "word_ENG": "environment",
        "word_AM": "አካባቢ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32268,
        "word_AF": "kuraabiyyo",
        "word_ENG": "equation",
        "word_AM": "እኩል አድርጎ ማመዛዘን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32310,
        "word_AF": "axasa",
        "word_ENG": "escort",
        "word_AM": "አጃቢ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32352,
        "word_AF": "saaxah gexa samada",
        "word_ENG": "sorts in process of disappearance",
        "word_AM": "እየጠፋ የሚገኝ ዘር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32394,
        "word_AF": "xalay farakka",
        "word_ENG": "spacing birth time",
        "word_AM": "አራርቆ መውለድ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32436,
        "word_AF": "africah egla",
        "word_ENG": "african union",
        "word_AM": "አፍሪካ ህብረት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32478,
        "word_AF": "inkiino",
        "word_ENG": "unity",
        "word_AM": "አንድነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32520,
        "word_AF": "gallinaana",
        "word_ENG": "universal",
        "word_AM": "አለም አቀፍ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32562,
        "word_AF": "sissika",
        "word_ENG": "urgency",
        "word_AM": "አስቸኳይነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32604,
        "word_AF": "haysitto-migda",
        "word_ENG": "usage",
        "word_AM": "አጠቃቀም አገባብ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32646,
        "word_AF": "gide=mellebi",
        "word_ENG": "value",
        "word_AM": "እሴት ዋጋ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32688,
        "word_AF": "caxaaxuwa",
        "word_ENG": "vegetation",
        "word_AM": "አትክልት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32730,
        "word_AF": "inxixi",
        "word_ENG": "green",
        "word_AM": "አረንጓዴ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32772,
        "word_AF": "tÛ-mabla",
        "word_ENG": "vission",
        "word_AM": "አመለካከት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32814,
        "word_AF": "amotani casbi",
        "word_ENG": "sentence to life",
        "word_AM": "እድሜ ልክ እስራት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32856,
        "word_AF": "koona karmak amô casbi",
        "word_ENG": "criminal reclusion of five years at least",
        "word_AM": "አስራ አምስት  ዓመት አስራት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32898,
        "word_AF": "tabna karmi casbi",
        "word_ENG": "criminal reclusion of ten in most",
        "word_AM": "አስር ዓመት በላይ እስራት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32940,
        "word_AF": "taban keekoona karmah casbi",
        "word_ENG": "criminal reclusion of fifteen years in most",
        "word_AM": "አስራ አምስት  ዓመት አስራት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 32982,
        "word_AF": "amqá",
        "word_ENG": "conciliation",
        "word_AM": "እርቅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33024,
        "word_AF": "amaxxaga",
        "word_ENG": "ricognition",
        "word_AM": "እውቅና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33066,
        "word_AF": "affara amoli",
        "word_ENG": "rectangle",
        "word_AM": "አራት ቀጥታ ጎኖችና ማዕዘኖች ያለው ቅርፅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33108,
        "word_AF": "marot huliyya",
        "word_ENG": "surrender",
        "word_AM": "እጅ መስጠት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33150,
        "word_AF": "yani caxxa",
        "word_ENG": "reality",
        "word_AM": "እውነታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33192,
        "word_AF": "cuumi",
        "word_ENG": "beams",
        "word_AM": "አውታር : ጮራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33234,
        "word_AF": "caalitiyya",
        "word_ENG": "rebellion",
        "word_AM": "አመጽ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33276,
        "word_AF": "caaleena",
        "word_ENG": "rebel",
        "word_AM": "አመጸኛ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33318,
        "word_AF": "qibni hirgoh araca",
        "word_ENG": "reception",
        "word_AM": "እንግዳ መቀበያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33360,
        "word_AF": "qibni hirgé",
        "word_ENG": "desk clerk",
        "word_AM": "እንግዳ ተቀባይ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33402,
        "word_AF": "maddur ullullutiyya",
        "word_ENG": "economic recession",
        "word_AM": "ኢኮኖሚ ማሽቆልቆል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33444,
        "word_AF": "qaran maysataka",
        "word_ENG": "bombarding",
        "word_AM": "አየር ጥቃት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33486,
        "word_AF": "affara adda",
        "word_ENG": "quadruple",
        "word_AM": "አራት እጥፍ አደገ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33528,
        "word_AF": "maddur rasu",
        "word_ENG": "economic zone",
        "word_AM": "ኢኪኖሚያዊ ዞን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33570,
        "word_AF": "magô gacsa",
        "word_ENG": "refund",
        "word_AM": "እንደገና ገንዘብ መስጠት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33612,
        "word_AF": "oftoyu",
        "word_ENG": "rest",
        "word_AM": "እረድት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33654,
        "word_AF": "arac xibixi",
        "word_ENG": "booking",
        "word_AM": "አስቀድም ቦታ መያዝ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33696,
        "word_AF": "guddaqta",
        "word_ENG": "residence tax",
        "word_AM": "አድራሻ /መኖሪያ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33738,
        "word_AF": "uguugumo",
        "word_ENG": "revolution",
        "word_AM": "አብዮት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33780,
        "word_AF": "uguugumoyta",
        "word_ENG": "revolutionary",
        "word_AM": "አብዮተኛ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33822,
        "word_AF": "saaci",
        "word_ENG": "sand",
        "word_AM": "አሽዋ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33864,
        "word_AF": "wadootu",
        "word_ENG": "rescue",
        "word_AM": "አዳነ አተረፈ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33906,
        "word_AF": "girâ bargusá",
        "word_ENG": "sappers fix",
        "word_AM": "እሳት ማጥፈያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33948,
        "word_AF": "satta",
        "word_ENG": "satisfaction",
        "word_AM": "እርካት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 33990,
        "word_AF": "dallam sinni abba",
        "word_ENG": "tyrant",
        "word_AM": "አምባገነን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34032,
        "word_AF": "maddur raceena",
        "word_ENG": "economic resource",
        "word_AM": "ኢኮኖሚ ምንጭ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34074,
        "word_AF": "maymuuqu",
        "word_ENG": "restoration",
        "word_AM": "እድሳት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34116,
        "word_AF": "magoytâ qeedaala",
        "word_ENG": "debit balance",
        "word_AM": "እዳ ሚዛን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34158,
        "word_AF": "wadi mawqeyna",
        "word_ENG": "emergency exit",
        "word_AM": "አደጋ ግዜ መውጫ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34200,
        "word_AF": "uguugutu",
        "word_ENG": "uprising",
        "word_AM": "አመፅ መነሳሳት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34242,
        "word_AF": "diggale xaagi raceyná",
        "word_ENG": "sure sources",
        "word_AM": "አስተማማኝ  የወሬ ምንጭ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34284,
        "word_AF": "qokol abitto",
        "word_ENG": "subscribe",
        "word_AM": "አስተዋፅኦ  ማድረግ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34326,
        "word_AF": "isbooru",
        "word_ENG": "sports",
        "word_AM": "እስፖርት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34368,
        "word_AF": "yasgoorowi",
        "word_ENG": "operator",
        "word_AM": "ኦፕሬትር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34410,
        "word_AF": "inkinnisso",
        "word_ENG": "standardization",
        "word_AM": "አንድ ወጥነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34452,
        "word_AF": "dudda sinni curriyata",
        "word_ENG": "relative freedom ",
        "word_AM": "አንፃራዊ ነፃነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34494,
        "word_AF": "umamxala",
        "word_ENG": "serious consequences",
        "word_AM": "አስከፊ ውጤት የሚያስከትል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34536,
        "word_AF": "ayfaafaya",
        "word_ENG": "service",
        "word_AM": "አገልግሎት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34578,
        "word_AF": "sissik ayfaafaya",
        "word_ENG": "urgent service",
        "word_AM": "አስቸኳይነት አገልግሎት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34620,
        "word_AF": "hawâ deesaasih ayfaafaya",
        "word_ENG": "service of weather fore cast",
        "word_AM": "አየር ትንቢያ አገልግሎት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34662,
        "word_AF": "buqreh exxah madduru",
        "word_ENG": "agricalture sector ",
        "word_AM": "እርሻ  ክፋለ ኢኮኖሚ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34704,
        "word_AF": "industirih exxah madduru",
        "word_ENG": "industrial sector",
        "word_AM": "አንድስትሪ ክፋለ ኢኮኖሚ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34746,
        "word_AF": "ayfaafay exxah madduru",
        "word_ENG": "service sector",
        "word_AM": "አገልግሎት ክፍለ ኢኮኖሚ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34788,
        "word_AF": "xinto maysaasa korsa",
        "word_ENG": "re form administrative",
        "word_AM": "አስተዳደር ማሻሻል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34830,
        "word_AF": "qagiegla",
        "word_ENG": "reintegration",
        "word_AM": "እንደገና መዋሀድ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34872,
        "word_AF": "qusbuk saada",
        "word_ENG": "revival",
        "word_AM": "እንደገና ህይወት መዝራት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34914,
        "word_AF": "baadfanta axawa",
        "word_ENG": "international relation",
        "word_AM": "አለም አቀፋዊ ግንኙነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34956,
        "word_AF": "caalit kee xakak sinna",
        "word_ENG": "violence and instability",
        "word_AM": "አመፅና አለመረጋጋት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 34998,
        "word_AF": "Eedis vayresi",
        "word_ENG": "HIV",
        "word_AM": "ኤች .አይ.ቪ. ቫይረስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35040,
        "word_AF": "caalitiyya",
        "word_ENG": "violence and instability",
        "word_AM": "አመፅ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35082,
        "word_AF": "limixxige gufne",
        "word_ENG": "official visit",
        "word_AM": "ኦፈሴላዊ ጉብኝት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35124,
        "word_AF": "boyna",
        "word_ENG": "volcano",
        "word_AM": "እሳት ጎሞራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35166,
        "word_AF": "qansada",
        "word_ENG": "trauma",
        "word_AM": "አእምሮ የሚያዛባ ገጠመኝ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35208,
        "word_AF": "qaran meerraytu",
        "word_ENG": "air transport",
        "word_AM": "አየር ማጓጓዥ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35250,
        "word_AF": "misinkica hawwug qido",
        "word_ENG": "cranial trauma",
        "word_AM": "አእምሮን የሚያውክ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35292,
        "word_AF": "duquuruse",
        "word_ENG": "deceiver",
        "word_AM": "አታላይ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35334,
        "word_AF": "admo",
        "word_ENG": "hunting",
        "word_AM": "አደን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35376,
        "word_AF": "hoolisso",
        "word_ENG": "tragedy",
        "word_AM": "አሳዛኝ ሙከራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35418,
        "word_AF": "galli maalih xiso",
        "word_ENG": "international monetary fund",
        "word_AM": "አለም አቀም የገንዘብ ድርጅት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35460,
        "word_AF": "qaran qande",
        "word_ENG": "air force",
        "word_AM": "አየር ኃይል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35502,
        "word_AF": "dirkisa caalata",
        "word_ENG": "case of absolute necessity",
        "word_AM": "አስገዳጅ ሁኔት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35544,
        "word_AF": "arkeyolooji fokkaaqo",
        "word_ENG": "archaeological search",
        "word_AM": "አርኪዩሎጂ ፍተሻ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35586,
        "word_AF": "keefé",
        "word_ENG": "supplier",
        "word_AM": "አከፋፋይ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35628,
        "word_AF": "makeyna",
        "word_ENG": "fraudulent",
        "word_AM": "አጭበርባሪ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35670,
        "word_AF": "inkittiino kee demokrasih arcissoh qarsa",
        "word_ENG": "front for the restitution of unity and democracy",
        "word_AM": "አንድነት የድሞክራሲ ግንባር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35712,
        "word_AF": "ximmoysa gaaza",
        "word_ENG": "tear gas",
        "word_AM": "አስለቃሽ ጭስ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35754,
        "word_AF": "xiinisso",
        "word_ENG": "management",
        "word_AM": "አስተዳደር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35796,
        "word_AF": "meklé",
        "word_ENG": "manager",
        "word_AM": "አስተዳዳሪ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35838,
        "word_AF": "wandad",
        "word_ENG": "gestation",
        "word_AM": "እርግዝና ጊዜ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35880,
        "word_AF": "xinto",
        "word_ENG": "governance",
        "word_AM": "አገዛዝ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35922,
        "word_AF": "umanná",
        "word_ENG": "critical",
        "word_AM": "አሳሳቢ /አስጊ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 35964,
        "word_AF": "gabâ bombi",
        "word_ENG": "pomegranate",
        "word_AM": "እጅ ቦምብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36006,
        "word_AF": "dabqi",
        "word_ENG": "foyer",
        "word_AM": "አዳራሽ /መኖሪያ  ቤት /",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36048,
        "word_AF": "erka",
        "word_ENG": "handicap",
        "word_AM": "አካለስንኩልነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36090,
        "word_AF": "erektu",
        "word_ENG": "handicapped person",
        "word_AM": "አካለስንኩል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36132,
        "word_AF": "gibdi gano",
        "word_ENG": "high treason",
        "word_AM": "አገር መክዳት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36174,
        "word_AF": "qibnaytiinô daasa",
        "word_ENG": "guest house",
        "word_AM": "እንግዳ ማረፈያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36216,
        "word_AF": "arac waqla",
        "word_ENG": "a local time",
        "word_AM": "አካባቢ ስዓት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36258,
        "word_AF": "foddaytu",
        "word_ENG": "peer",
        "word_AM": "አቻ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36300,
        "word_AF": "ardik qaran meggaraqqa",
        "word_ENG": "horizon",
        "word_AM": "አድማስ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36342,
        "word_AF": "gabgabbi",
        "word_ENG": "horizontal",
        "word_AM": "አግዳሚ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36384,
        "word_AF": "qella",
        "word_ENG": "offside",
        "word_AM": "ኦፍ ሳይድ/ከጨዋታ ወጭ /",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36426,
        "word_AF": "madqa raamoyse",
        "word_ENG": "plaintiff",
        "word_AM": "አቃቤ ሕግ/ሕግ አስፈፃሚ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36468,
        "word_AF": "inkih taysi",
        "word_ENG": "ideal",
        "word_AM": "አርአያነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36510,
        "word_AF": "tÛ mabul li",
        "word_ENG": "ideologist",
        "word_AM": "አይዲዮሎጂስት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36552,
        "word_AF": "hawwasoosu",
        "word_ENG": "imagination",
        "word_AM": "አይነ ሕልና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36594,
        "word_AF": "absis",
        "word_ENG": "imports",
        "word_AM": "አስመጪ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36636,
        "word_AF": "bicewaynaana",
        "word_ENG": "incovenience",
        "word_AM": "አለመጣጣም : አለመቻቻል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36678,
        "word_AF": "oggolisiyya",
        "word_ENG": "to inculcate",
        "word_AM": "አስረዳ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36720,
        "word_AF": "yascassi",
        "word_ENG": "indicators",
        "word_AM": "አመልካች ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36762,
        "word_AF": "fidok tabta biyooká",
        "word_ENG": "sexually transmissible infections",
        "word_AM": "አባላዘር በሽታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36804,
        "word_AF": "kuuriinô baarisiyya",
        "word_ENG": "industrialization",
        "word_AM": "ኢንዱስትሪማስፋፋት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36846,
        "word_AF": "sanaaqatta",
        "word_ENG": "industry",
        "word_AM": "ኢንዱስትሪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36888,
        "word_AF": "qelela",
        "word_ENG": "infirmity",
        "word_AM": "አካል ጎዶሎነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36930,
        "word_AF": "qarangubitte fanal",
        "word_ENG": "intecontinental",
        "word_AM": "አህጉራት መካከል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 36972,
        "word_AF": "baadinan",
        "word_ENG": "international",
        "word_AM": "አለም አቀፋዊ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37014,
        "word_AF": "interneet",
        "word_ENG": "internet",
        "word_AM": "እንተርኔት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37056,
        "word_AF": "afgacsé",
        "word_ENG": "interpreter",
        "word_AM": "አስተርጓሚ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37098,
        "word_AF": "uguugusu",
        "word_ENG": "intifada",
        "word_AM": "ኢንቲፋዳ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37140,
        "word_AF": "loowô gacsa",
        "word_ENG": "to make inventory",
        "word_AM": "ኢንቨንተሪ ማድረግ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37182,
        "word_AF": "liggidi ellecaboh lowô gacsa",
        "word_ENG": "inventory of the end of year",
        "word_AM": "አመትመጨረሻ ኢንቨንተሪ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37224,
        "word_AF": "daalisso",
        "word_ENG": "investment",
        "word_AM": "ኢንቨስትመንት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37266,
        "word_AF": "baaxoh inkittiino",
        "word_ENG": "territorial integrity",
        "word_AM": "አገር አንድነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37308,
        "word_AF": "xayyoysa",
        "word_ENG": "journalist presenter",
        "word_AM": "አቅራቢ ጋዜጠኛ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37350,
        "word_AF": "ayro,labbat leelah ayro",
        "word_ENG": "world day of the volunteers",
        "word_AM": "አለም አቀፍ የፈቃደኞች ቀን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37392,
        "word_AF": "naddoowe rooci calaalise",
        "word_ENG": "kamikaze",
        "word_AM": "አጥፍቶ ማጥፋት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37434,
        "word_AF": "HIV eedis elle taba gititte",
        "word_ENG": "modes of HIV's transmission",
        "word_AM": "ኤች. አይ. ቪ. /ኤድስ/መተላለፊያ መንገዶች ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37476,
        "word_AF": "baad assomma",
        "word_ENG": "misery of the world ",
        "word_AM": "ዓለም አቀፍ ርሃብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37518,
        "word_AF": "muunata",
        "word_ENG": "model",
        "word_AM": "ዓይነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37560,
        "word_AF": "angoyya",
        "word_ENG": "movement",
        "word_AM": "እንቅስቃሴ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37602,
        "word_AF": "fanaafana",
        "word_ENG": "average",
        "word_AM": "አማካኝ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37644,
        "word_AF": "fanti-maaca",
        "word_ENG": "midde east",
        "word_AM": "አማካኝ ምሥራቅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37686,
        "word_AF": "baada",
        "word_ENG": "world",
        "word_AM": "አለም ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37728,
        "word_AF": "baaddoyso",
        "word_ENG": "globalization",
        "word_AM": "አለም አቀፋዊነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37770,
        "word_AF": "marammité",
        "word_ENG": "mutineer",
        "word_AM": "እምቢተኛ ስው",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37812,
        "word_AF": "marammitiinu",
        "word_ENG": "mutiny",
        "word_AM": "አመፅ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37854,
        "word_AF": "agat doolata",
        "word_ENG": "nation",
        "word_AM": "አገር መንግስት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37896,
        "word_AF": "baxsa sinni doolata",
        "word_ENG": "unitary state",
        "word_AM": "አሀዳዊ መንግስት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37938,
        "word_AF": "safrissô baritto",
        "word_ENG": "navigation",
        "word_AM": "አቅጣጫ የመለየት ትምህርት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 37980,
        "word_AF": "qusba küamol-ayyo",
        "word_ENG": "neo-colonialism",
        "word_AM": "እጅ አዙር ቅኝ አገዛዝ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38022,
        "word_AF": "ullulluttâ muddur caddo",
        "word_ENG": "level of life standard which falls",
        "word_AM": "እያሽቆለቆለ የሚሄድ የኑሮ ደረጀ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38064,
        "word_AF": "dacarsitiinu",
        "word_ENG": "nomadism",
        "word_AM": "አርቢነት : ዘላንነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38106,
        "word_AF": "qeedaale waya",
        "word_ENG": "imbalanced",
        "word_AM": "አለመመጣጠን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38148,
        "word_AF": "ux kassiteyna",
        "word_ENG": "notes",
        "word_AM": "አጭር ማስታወሻ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38190,
        "word_AF": "qusba maysaq arrah waqla",
        "word_ENG": "new record time",
        "word_AM": "አዳዲስ ክብረወስን ጊዜ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38232,
        "word_AF": "baad qusba dadalwa",
        "word_ENG": "new international developments",
        "word_AM": "አዳዲስ አለም አቀፍ እድገቶች ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38274,
        "word_AF": "qusba amri",
        "word_ENG": "new order",
        "word_AM": "አዲስ መመሪያ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38316,
        "word_AF": "uxxuysen xaagu",
        "word_ENG": "news in brief",
        "word_AM": "አጫጭር ዜናዎች",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38358,
        "word_AF": "adoobi cogda",
        "word_ENG": "nutrition",
        "word_AM": "አመጋገብ ዘዴ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38400,
        "word_AF": "opeera",
        "word_ENG": "opera",
        "word_AM": "አፔራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38442,
        "word_AF": "atlantik baddiida,kaxxa-bada",
        "word_ENG": "the atlantic ocean",
        "word_AM": "አትላንቲክ ውቅያኖስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38484,
        "word_AF": "qaffayda",
        "word_ENG": "occasion",
        "word_AM": "እድል: በዓል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38526,
        "word_AF": "agxé",
        "word_ENG": "activity",
        "word_AM": "እንቅስቃሴ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38568,
        "word_AF": "adafa",
        "word_ENG": "obstacle",
        "word_AM": "እንቅፋት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38610,
        "word_AF": "abnisso",
        "word_ENG": "operation",
        "word_AM": "አፈፃፀም ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38652,
        "word_AF": "wale saami",
        "word_ENG": "opportunity",
        "word_AM": "እድል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38694,
        "word_AF": "oggole waya",
        "word_ENG": "to set",
        "word_AM": "አለመቀበል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38736,
        "word_AF": "orkestra",
        "word_ENG": "orchestra",
        "word_AM": "ኦርኬስትራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38778,
        "word_AF": "ajenda",
        "word_ENG": "agenda",
        "word_AM": "አጀንዳ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38820,
        "word_AF": "afkana",
        "word_ENG": "world  order",
        "word_AM": "አለም አቀፋዊ ሥርዓት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38862,
        "word_AF": "elayto",
        "word_ENG": "organ",
        "word_AM": "አካል : ብልት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38904,
        "word_AF": "massoysé",
        "word_ENG": "organizer",
        "word_AM": "አደራጅ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38946,
        "word_AF": "xagara",
        "word_ENG": "body",
        "word_AM": "አካል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 38988,
        "word_AF": "baadinan taama",
        "word_ENG": "international operations",
        "word_AM": "ዓለም አቀፋዊ አስራር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39030,
        "word_AF": "mayfakana",
        "word_ENG": "orientation",
        "word_AM": "አቅጣጫ ማስሪዝ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39072,
        "word_AF": "agoogarat rada",
        "word_ENG": "parachutist",
        "word_AM": "አየር ወለድ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39114,
        "word_AF": "madqâ loynah exxa",
        "word_ENG": "public prosecutor's department",
        "word_AM": "አቃቤ ሕግ መምሪያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39156,
        "word_AF": "saytunaana",
        "word_ENG": "perfect",
        "word_AM": "እንከን የለሽ : ፍጽም ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39198,
        "word_AF": "dacarsitto",
        "word_ENG": "pastoralism",
        "word_AM": "አርብቶ አዳሪነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39240,
        "word_AF": "saqala",
        "word_ENG": "boss",
        "word_AM": "አለቃ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39282,
        "word_AF": "saqoolinna",
        "word_ENG": "patronage",
        "word_AM": "እልቅና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39324,
        "word_AF": "tamsiisá",
        "word_ENG": "employers",
        "word_AM": "አሠሪዎች",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39366,
        "word_AF": "inâ baaxo",
        "word_ENG": "homeland",
        "word_AM": "አገር ቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39408,
        "word_AF": "agat kacnule",
        "word_ENG": "patriotic",
        "word_AM": "አገር ወደድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39450,
        "word_AF": "agat kacnu",
        "word_ENG": "patriotism",
        "word_AM": "አገር ፍቅር /አርብኝነት/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39492,
        "word_AF": "kullum qido",
        "word_ENG": "peach",
        "word_AM": "አሣ ማስገር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39534,
        "word_AF": "kullum qari",
        "word_ENG": "fishery",
        "word_AM": "አሣ መሽጫ ቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39576,
        "word_AF": "kullum qide",
        "word_ENG": "fisherman",
        "word_AM": "አሣ አስጋሪ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39618,
        "word_AF": "baaxo",
        "word_ENG": "country",
        "word_AM": "አገር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39660,
        "word_AF": "qaraafâ digaala",
        "word_ENG": "penalty",
        "word_AM": "አነስተኛ ቅጣት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39702,
        "word_AF": "oqi guubu",
        "word_ENG": "nursery",
        "word_AM": "አፀደ ህፃናት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39744,
        "word_AF": "oqseyna",
        "word_ENG": "nursery man",
        "word_AM": "አፀደ ህፃናት ሠራተኛ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39786,
        "word_AF": "baaxo xaylo",
        "word_ENG": "native people",
        "word_AM": "አገር ተወላጅ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39828,
        "word_AF": "kutbe garqa",
        "word_ENG": "plagiarism",
        "word_AM": "አስመስሎ መቅዳት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39870,
        "word_AF": "liggidi robtih kaalo",
        "word_ENG": "annual pluviometer",
        "word_AM": "አመታዊ ዝናብ መለኪያ ሜትር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39912,
        "word_AF": "kutbê garqé",
        "word_ENG": "plagiarist",
        "word_AM": "አስመስሎ ቀጂ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39954,
        "word_AF": "haadisé",
        "word_ENG": "pilot",
        "word_AM": "አይሮፕላን አብራሪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 39996,
        "word_AF": "qaran gita",
        "word_ENG": "air track",
        "word_AM": "አየር መንገድ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40038,
        "word_AF": "dadal ekraaro",
        "word_ENG": "plan of development",
        "word_AM": "እድገት ፕላን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40080,
        "word_AF": "baddi raasa",
        "word_ENG": "continental shelf",
        "word_AM": "አህጉራዊ ገበቶ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40122,
        "word_AF": "tayyaara quuké",
        "word_ENG": "aircraft-carrier",
        "word_AM": "አውሮፕላን የሚጭን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40164,
        "word_AF": "soltima;mahdaba",
        "word_ENG": "position",
        "word_AM": "አቋም ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40206,
        "word_AF": "girabargusé",
        "word_ENG": "fireman",
        "word_AM": "እሳት አጥፈ /ቃጠሎ/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40248,
        "word_AF": "uluuluka  fixixissa poliisi",
        "word_ENG": "police-anti-revolt",
        "word_AM": "አድማ በታኝ ፓሊስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40290,
        "word_AF": "affara",
        "word_ENG": "cardinal",
        "word_AM": "አራት አቅጣጫዎች ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40332,
        "word_AF": "itta giddissa tumabullitte",
        "word_ENG": "serface suspend points of viwe diametrically opposite",
        "word_AM": "እርስ በርስ የሚጋጩ አመለካከቶች ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40374,
        "word_AF": "tuk irô bagu wanxexxeelit tan digaala",
        "word_ENG": "serface suspend",
        "word_AM": "አንድ ነገር /የ/ወጪዊ ክፍል እንጥልጥል ላይ የቀረ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40416,
        "word_AF": "siida",
        "word_ENG": "ADIS",
        "word_AM": "ኤድስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40458,
        "word_AF": "iroh rubtane",
        "word_ENG": "exports",
        "word_AM": "ኤክስፓርት ወደ ወጭ የሚላክ እቃ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40500,
        "word_AF": "maysalaalaqa",
        "word_ENG": "exhibition",
        "word_AM": "ኤግዚቢሺን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40542,
        "word_AF": "gabâ gaaxi maysalaalaqa",
        "word_ENG": "craft exhibition",
        "word_AM": "እጅሙያ ኤግዚቢሽን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40584,
        "word_AF": "maxca",
        "word_ENG": "expression",
        "word_AM": "አባባል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40626,
        "word_AF": "sahliseh",
        "word_ENG": "facilitated",
        "word_AM": "አቃለለ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40668,
        "word_AF": "exxa",
        "word_ENG": "faction",
        "word_AM": "አንጃ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40710,
        "word_AF": "celceelisi",
        "word_ENG": "forgery",
        "word_AM": "አስመስሎ መሥራት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40752,
        "word_AF": "assakata le raat cabto",
        "word_ENG": "to-impress ,some thing",
        "word_AM": "አድናቆት ማትረፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40794,
        "word_AF": "weelô loowo",
        "word_ENG": "figures",
        "word_AM": "አሀዝ ቅርጽ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40836,
        "word_AF": "waqaggâ filmi",
        "word_ENG": "horror film",
        "word_AM": "አስፈረ ፈልም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40878,
        "word_AF": "oggole wayti",
        "word_ENG": "objection",
        "word_AM": "አለመቀበል /ተቃውም ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40920,
        "word_AF": "naqbi bakaqá",
        "word_ENG": "out break of violences ",
        "word_AM": "አመጽ /የ/መፈንዳት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 40962,
        "word_AF": "kiriiriqisê",
        "word_ENG": "fundamentalist",
        "word_AM": "አክራሪ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41004,
        "word_AF": "catô maalu",
        "word_ENG": "fund",
        "word_AM": "እርዳት ገንዘብ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41046,
        "word_AF": "qaxoyta",
        "word_ENG": "favoritism",
        "word_AM": "አድሎ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41088,
        "word_AF": "saq kee cooxu",
        "word_ENG": "fauna and flora",
        "word_AM": "እንሰሳትና እፅዋት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41130,
        "word_AF": "makô-celsiise",
        "word_ENG": "forger",
        "word_AM": "አስመስሎ ስሪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41172,
        "word_AF": "duquurusenti celsiisih abto",
        "word_ENG": "forgery and custom of the false",
        "word_AM": "አስመስሎ የሚታለል ተግባር  ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41214,
        "word_AF": "waynabo",
        "word_ENG": "festivities celebration",
        "word_AM": "አከባበር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41256,
        "word_AF": "loowo",
        "word_ENG": "statistics",
        "word_AM": "እስታቲስቲክስ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41298,
        "word_AF": "uxxikutbe",
        "word_ENG": "stenographe",
        "word_AM": "አጭር ጽህፈት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41340,
        "word_AF": "istudiyo",
        "word_ENG": "studio",
        "word_AM": "እስትድዮ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41382,
        "word_AF": "duyye mansafa",
        "word_ENG": "material",
        "word_AM": "እቃ ቁሣቁስ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41424,
        "word_AF": "ina akkiyya",
        "word_ENG": "maternity",
        "word_AM": "እናትነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41466,
        "word_AF": "kibalwaya",
        "word_ENG": "distrust",
        "word_AM": "እምነት ማጣት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41508,
        "word_AF": "naggaarinna",
        "word_ENG": "carpentary",
        "word_AM": "እንጨት ሥራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41550,
        "word_AF": "naggaara",
        "word_ENG": "wood work",
        "word_AM": "አናጢ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41592,
        "word_AF": "elektiroonikfarmo",
        "word_ENG": "electronic message",
        "word_AM": "ኤሌክትሮኒክ መልእክት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41634,
        "word_AF": "gidâ waasô cogda",
        "word_ENG": "contraceptive method",
        "word_AM": "እርግዝና መከላከያ ዘዴ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41676,
        "word_AF": "taamâ maknaya",
        "word_ENG": "methodology",
        "word_AM": "አስራር ዘዴዎች /ጥበብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41718,
        "word_AF": "amô kaqaylo",
        "word_ENG": "brain washing",
        "word_AM": "ከአእምሮ ማሽፈት/ሀሣብ ማስለወጥ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41760,
        "word_AF": "inkih yan caalata",
        "word_ENG": "general situations",
        "word_AM": "አጠቃላይ ሁኔት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41802,
        "word_AF": "caxaaxuwa",
        "word_ENG": "vegetables",
        "word_AM": "አትክልት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41844,
        "word_AF": "mangaba",
        "word_ENG": "majority",
        "word_AM": "አብላጫ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41886,
        "word_AF": "muxxi  mangaba",
        "word_ENG": "substantial  majority ",
        "word_AM": "አስፈላጊ ድምፅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41928,
        "word_AF": "saami umaane",
        "word_ENG": "unlucky",
        "word_AM": "እድለቢስነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 41970,
        "word_AF": "baadinan katla xibixih  ugsiyya",
        "word_ENG": "lifting of internation",
        "word_AM": "አለም አቀፍ ማዕቀብ ማንሳት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42012,
        "word_AF": "mablaay misinki caa kee diini curriyata",
        "word_ENG": "embargo",
        "word_AM": "አመለካከት /የህልናና የእምነት ነፃነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42054,
        "word_AF": "inkittinaane",
        "word_ENG": "freedom  of thought  consciousness religion ",
        "word_AM": "አገር አነድነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42096,
        "word_AF": "makayena duyye",
        "word_ENG": "hire",
        "word_AM": "እቃ ወይም መኪና  መከራየት መግዛት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42138,
        "word_AF": "maysaada",
        "word_ENG": "dismissal",
        "word_AM": "እገዳ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42180,
        "word_AF": "axawfidga",
        "word_ENG": "prison release ",
        "word_AM": "እስር መፍታት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42222,
        "word_AF": "cusso",
        "word_ENG": "filling ",
        "word_AM": "ስሜት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42264,
        "word_AF": "cuso",
        "word_ENG": " To menting",
        "word_AM": "መድገም/በቃል መደጋገም /",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42306,
        "word_AF": "mudarraqa",
        "word_ENG": "armored",
        "word_AM": "ከባድ መሳሪያ /ብረት ለበስ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42348,
        "word_AF": "diirat",
        "word_ENG": "compass ",
        "word_AM": "ኮምፓስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42390,
        "word_AF": "kobbanî saqala",
        "word_ENG": "executive  of a company",
        "word_AM": "ካምፓኒ ሥራአስኪያጅ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42432,
        "word_AF": "lakqo yabbaxi",
        "word_ENG": "cashier",
        "word_AM": "ካሼር/ገንዘብ ያዥ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42474,
        "word_AF": "midra",
        "word_ENG": "Box",
        "word_AM": "ካዝና /ሳጥን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42516,
        "word_AF": "kaameera",
        "word_ENG": "comera",
        "word_AM": "ካሜራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42558,
        "word_AF": "raasal maala",
        "word_ENG": "capital ",
        "word_AM": "ካፒታል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42600,
        "word_AF": "baaxô karta",
        "word_ENG": "map",
        "word_AM": "ካርታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42642,
        "word_AF": "murabbaqa",
        "word_ENG": "square ",
        "word_AM": "ካሬ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42684,
        "word_AF": "maabâ qaglata",
        "word_ENG": "audio  cassette  tape",
        "word_AM": "ካሴት/የቴፕ /",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42726,
        "word_AF": "maro",
        "word_ENG": "en circle  ",
        "word_AM": "ክብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42768,
        "word_AF": "maggalâ kabxah fanteyna",
        "word_ENG": "shopping center  of city",
        "word_AM": "ከተማው /የ/የገበያ ማዕከል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42810,
        "word_AF": "gaaboyna",
        "word_ENG": "conference  ",
        "word_AM": "ኮንፈረንስ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42852,
        "word_AF": "konoyli",
        "word_ENG": "colonel",
        "word_AM": "ኮሎኔል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42894,
        "word_AF": "cissi sinna",
        "word_ENG": "coma",
        "word_AM": "ኮማ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42936,
        "word_AF": "furgata",
        "word_ENG": "comedy",
        "word_AM": "ኮሜዲ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 42978,
        "word_AF": "furgató",
        "word_ENG": "comedian",
        "word_AM": "ከሜዲያን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43020,
        "word_AF": "geera le cutukta",
        "word_ENG": "comet",
        "word_AM": "ኮከብ /ጅራታም/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43062,
        "word_AF": "maro",
        "word_ENG": "committe",
        "word_AM": "ኮሚቴ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43104,
        "word_AF": "foyyak qimbesiyya",
        "word_ENG": "beginning  from zero",
        "word_AM": "ከዜሮ መጀመር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43146,
        "word_AF": "awliseyna",
        "word_ENG": "commissar ",
        "word_AM": "ኮሚሽነር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43188,
        "word_AF": "makkaabâ maro",
        "word_ENG": "commission ",
        "word_AM": "ኮሚሽን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43230,
        "word_AF": "shuuqiyya",
        "word_ENG": "communism",
        "word_AM": "ኮሚኒዝም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43272,
        "word_AF": "shuuqiita",
        "word_ENG": "communist ",
        "word_AM": "ኮሚኒሰት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43314,
        "word_AF": "edde raaqa",
        "word_ENG": "compensation ",
        "word_AM": "ካሣ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43356,
        "word_AF": "kiimiyâ xisne",
        "word_ENG": "chemical  composition ",
        "word_AM": "/የ/ኬሚስት ማቀላቀል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43398,
        "word_AF": "kiimiya",
        "word_ENG": "chemistry ",
        "word_AM": "ኬሚስትሪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43440,
        "word_AF": "koleera",
        "word_ENG": "cholera",
        "word_AM": "ኮሌራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43482,
        "word_AF": "megaalâ sigeyna",
        "word_ENG": "city-dweller",
        "word_AM": "ከተማ /የ/ነዋሪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43524,
        "word_AF": "footima",
        "word_ENG": "class room ",
        "word_AM": "ክፍል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43566,
        "word_AF": "konfederaal",
        "word_ENG": "confederal",
        "word_AM": "ኮንፌዴራል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43608,
        "word_AF": "konfederaasi",
        "word_ENG": "confederacy",
        "word_AM": "ኮንፌዴራሲ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43650,
        "word_AF": "korsa",
        "word_ENG": "copy",
        "word_AM": "ኮፒ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43692,
        "word_AF": "gonaytu",
        "word_ENG": "corner kicks",
        "word_AM": "ኮርነር ምት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43734,
        "word_AF": "taamâ kaaliyya",
        "word_ENG": "to hold more than  of office ",
        "word_AM": "ከአንድ ሥራ በላይ መያዝ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43776,
        "word_AF": "xaawa",
        "word_ENG": "debate ",
        "word_AM": "ክርክር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43818,
        "word_AF": "angodda",
        "word_ENG": "denial ",
        "word_AM": "ክህደት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43860,
        "word_AF": "baadisiyya",
        "word_ENG": "deportaion",
        "word_AM": "ካገር ማባረር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43902,
        "word_AF": "kartuunu",
        "word_ENG": "cartoon ",
        "word_AM": "ካርቱን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43944,
        "word_AF": "caddi",
        "word_ENG": "dignity",
        "word_AM": "ክብር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 43986,
        "word_AF": "fayyata barittô sumaqta",
        "word_ENG": " diploma  of general  university  studies ",
        "word_AM": "ከፍተኛ  ትም/ት/የ/ዲፕሎማ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44028,
        "word_AF": "faxe digaalak bari",
        "word_ENG": "exempt  from punishment  and the determent",
        "word_AM": "ከማንኛውም ቅጣት ነፃ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44070,
        "word_AF": "kurta",
        "word_ENG": "division ",
        "word_AM": "ከፈል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44112,
        "word_AF": "komittê-dooro",
        "word_ENG": "to elect  acommittee",
        "word_AM": "ኮሚቴ መምረጥ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44154,
        "word_AF": "kooraana",
        "word_ENG": "electricity ",
        "word_AM": "ኮሬንት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44196,
        "word_AF": "lacti aydorra",
        "word_ENG": "animal husbandary",
        "word_AM": "ከብት ርቢ /እርባታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44238,
        "word_AF": "lac yaydarri",
        "word_ENG": "breeder",
        "word_AM": "ከብት አርቢ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44280,
        "word_AF": "rakaakaya",
        "word_ENG": "region ",
        "word_AM": "ክልል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44322,
        "word_AF": "malkitii",
        "word_ENG": "complaint ",
        "word_AM": "ክስ ቅሬታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44364,
        "word_AF": "maysô-maysarraqa",
        "word_ENG": "record",
        "word_AM": "ክብረ ወስን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44406,
        "word_AF": "malkitlil wadir malkitiyya",
        "word_ENG": "recrimination",
        "word_AM": "ከሳሹን መልሶ መክስስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44448,
        "word_AF": "rakaakayisso",
        "word_ENG": "regionlization",
        "word_AM": "ክልላዊነት ማካለል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44490,
        "word_AF": "malkit ugsa",
        "word_ENG": "judicial  discharge ",
        "word_AM": "ክስ ማንሳት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44532,
        "word_AF": "sekkaacu",
        "word_ENG": "revision ",
        "word_AM": "ክለሳ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44574,
        "word_AF": "sekkaacuu kee gittoysiisi",
        "word_ENG": "revision  correction ",
        "word_AM": "ክለሳና እርማት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44616,
        "word_AF": "taamak xiiriyyo",
        "word_ENG": "expelled from post",
        "word_AM": "ከሥራ ማባረር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44658,
        "word_AF": "maroh yan gita",
        "word_ENG": "circular  road",
        "word_AM": "ክብ መንገድ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44700,
        "word_AF": "barittô-footima",
        "word_ENG": "class room ",
        "word_AM": "ክፍል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44742,
        "word_AF": "iroh aban kaqo",
        "word_ENG": "high jump",
        "word_AM": "ከፍታ ዝላይ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44784,
        "word_AF": "xawwaata",
        "word_ENG": "section ",
        "word_AM": "ክፍል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44826,
        "word_AF": "qaadifana",
        "word_ENG": "semi-savanna",
        "word_AM": "ከፈል ስንባሌጥ መሬት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44868,
        "word_AF": "maqar le-daylih ayfaafaya",
        "word_ENG": "service  of extensive care",
        "word_AM": "ከፍተኛ ህክምና አገልግሎት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44910,
        "word_AF": "mü-assasa",
        "word_ENG": "corporation ",
        "word_AM": "ኮርፕሬሽን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44952,
        "word_AF": "mekla akkiiya tellemmo fayyata maro",
        "word_ENG": "pay or sale",
        "word_AM": "ክፍያ ወይም ሽያጭ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 44994,
        "word_AF": "fayya ta maro",
        "word_ENG": "summit",
        "word_AM": "ከፍ ያለ ጉባኤ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45036,
        "word_AF": "fayya-le miraacinnih gubat",
        "word_ENG": "under the height  paronage of subscribe ",
        "word_AM": "ከፍተኛ አመራር ሥር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45078,
        "word_AF": "qandaya",
        "word_ENG": "sovereign",
        "word_AM": "ከሁሉ በላይ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45120,
        "word_AF": "kattaatu",
        "word_ENG": "follow-up",
        "word_AM": "ክትትል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45162,
        "word_AF": "kattat kee agaarada",
        "word_ENG": "follow-up and  evaluation ",
        "word_AM": "ክትትልና ግምገማ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45204,
        "word_AF": "koqsô-booxa",
        "word_ENG": "stadium ",
        "word_AM": "ኳስ ሜዳ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45246,
        "word_AF": "magaala",
        "word_ENG": "urban",
        "word_AM": "ከተማ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45288,
        "word_AF": "aftabu",
        "word_ENG": "vaccination",
        "word_AM": "ክትባት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45330,
        "word_AF": "magaaliyyo",
        "word_ENG": "urbanization",
        "word_AM": "ከተማነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45372,
        "word_AF": "magaalah ekrooro",
        "word_ENG": "town planning ",
        "word_AM": "ከተማ ፕላን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45414,
        "word_AF": "caddok taturte sissikaane",
        "word_ENG": "exceeding the speed timit",
        "word_AM": "ከሚገባው በላይ መፍጠን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45456,
        "word_AF": "caddo  tatre abbootana",
        "word_ENG": "excess of power",
        "word_AM": "ከልክ ያለፈ ሰልጣን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45498,
        "word_AF": "konnabnali",
        "word_ENG": "excellence",
        "word_AM": "ክቡር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45540,
        "word_AF": "kobbani",
        "word_ENG": "company",
        "word_AM": "ካምፓኒ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45582,
        "word_AF": "daffeyteemik mekliyya",
        "word_ENG": "to pay deppose ",
        "word_AM": "ከተቀማጭ ክፍያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45624,
        "word_AF": "kudeyna doleyna",
        "word_ENG": "fugitive",
        "word_AM": "ኮብላይ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45666,
        "word_AF": "galaksi",
        "word_ENG": "galaxy",
        "word_AM": "ከዋክብት ልዮችን /ጋላክ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45708,
        "word_AF": "ummuunô sibaaba",
        "word_ENG": "republican gruard ",
        "word_AM": "ክብር ዘብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45750,
        "word_AF": "karre",
        "word_ENG": "gravel",
        "word_AM": "ኮረት /ጠጠር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45792,
        "word_AF": "arac cukuumata",
        "word_ENG": "local  government ",
        "word_AM": "ክልላዊ መስተዳድር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45834,
        "word_AF": "fayya'ya awliseyna",
        "word_ENG": "high commissioner ",
        "word_AM": "ከ/ኮሚሽነር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45876,
        "word_AF": "badak amô kaxxa fayya",
        "word_ENG": "high  altitude",
        "word_AM": "ከፍተኛ የባህር ወለል ከፍታ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45918,
        "word_AF": "bisoh itte teknolooji",
        "word_ENG": "high technology ",
        "word_AM": "ከፍተኛ ቴክኖሎጂ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 45960,
        "word_AF": "fayya",
        "word_ENG": "height",
        "word_AM": "ከፍታ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46002,
        "word_AF": "raasalmaal kudsa",
        "word_ENG": "drain of capital ",
        "word_AM": "ካፒታል ማሽሽ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46044,
        "word_AF": "migaaqa",
        "word_ENG": "honor",
        "word_AM": "ክብር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46086,
        "word_AF": "karat mali",
        "word_ENG": "tax free",
        "word_AM": "ከግብር ነፃ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46128,
        "word_AF": "kaxxu le",
        "word_ENG": "important ",
        "word_AM": "ከፍተኛ /ብርቱ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46170,
        "word_AF": "kombanil haan karata",
        "word_ENG": "company tax",
        "word_AM": "ኮምፓኒ ግብር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46212,
        "word_AF": "barlamaan maxagaani",
        "word_ENG": "partiamentary immunity",
        "word_AM": "ክብሩ የተጠበቀ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46254,
        "word_AF": "raata",
        "word_ENG": "accusation",
        "word_AM": "ክስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46296,
        "word_AF": "xaagi raatisso",
        "word_ENG": "data processing ",
        "word_AM": "ኮምፒዩተር ሲስተም ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46338,
        "word_AF": "wohukgexak",
        "word_ENG": "Ipso facto",
        "word_AM": "ከዛ በመነሳት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46380,
        "word_AF": "kalaata",
        "word_ENG": "taboo forbidden ",
        "word_AM": "ክልክል: የተከለከለ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46422,
        "word_AF": "dibboysiyya",
        "word_ENG": "to isolate",
        "word_AM": "ከሌሎች መነጠል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46464,
        "word_AF": "ardi gubih lee",
        "word_ENG": "ground  water",
        "word_AM": "ኮርስ ምድር ውሃ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46506,
        "word_AF": "dooroh udduruk sidiica alsi raaqa wak",
        "word_ENG": "there are three months to go before  the date set for the election ",
        "word_AM": "ከምርጫ ጊዜ ሦስት ወር ሲቀር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46548,
        "word_AF": "barriita",
        "word_ENG": "offshore ",
        "word_AM": "ከመሬት ወደ ባህር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46590,
        "word_AF": "kompiyuuter",
        "word_ENG": "computer",
        "word_AM": "ኮምፒዩተር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46632,
        "word_AF": "mekla",
        "word_ENG": "payment ",
        "word_AM": "ክፍያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46674,
        "word_AF": "xabana",
        "word_ENG": "part",
        "word_AM": "ክፍል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46716,
        "word_AF": "ceyceyisso",
        "word_ENG": "pursuit ",
        "word_AM": "ክትትል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46758,
        "word_AF": "finqa",
        "word_ENG": "loss",
        "word_AM": "ኪሣራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46800,
        "word_AF": "ansaala",
        "word_ENG": "phenomenon ",
        "word_AM": "ክስተት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46842,
        "word_AF": "wakaak wak yimixxige udduru",
        "word_ENG": "periodical",
        "word_AM": "ከግዜ ወደ ግዜ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46884,
        "word_AF": "waytoli",
        "word_ENG": "plaintiff ",
        "word_AM": "ከሣሽ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46926,
        "word_AF": "weeqá",
        "word_ENG": "complaint ",
        "word_AM": "ክስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 46968,
        "word_AF": "qilsa",
        "word_ENG": "weight ",
        "word_AM": "ክብደት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47010,
        "word_AF": "caggoliino",
        "word_ENG": "polygamy",
        "word_AM": "ከአንድ ሚስት በላይ ማግባት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47052,
        "word_AF": "matrisi",
        "word_ENG": "postscript",
        "word_AM": "ከደብደቤ እግርጌ የሚጨመር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47094,
        "word_AF": "kaxxa qilsa",
        "word_ENG": " heavy weight ",
        "word_AM": "ከባደ ሚዛን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47136,
        "word_AF": "giffole caacay gutqoh dabba",
        "word_ENG": "zone of high pressure ",
        "word_AM": "ከፍተኛ የአየር ግፈት ያለውን ዞን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47178,
        "word_AF": "mü-assasa kaxxa makayyo",
        "word_ENG": "limited  company",
        "word_AM": "ኮርፐሬሽን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47220,
        "word_AF": "baaca",
        "word_ENG": "bankruptcy ",
        "word_AM": "ክስረት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47262,
        "word_AF": "qaffayda waynabo",
        "word_ENG": "festival ",
        "word_AM": "ክብረ በዓል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47304,
        "word_AF": "isi assakaata isit maqaane",
        "word_ENG": "pride",
        "word_AM": "ኩራት ክብር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47346,
        "word_AF": "daffeynâ maro",
        "word_ENG": "round  table",
        "word_AM": "ክብ ጠረጴዛ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47388,
        "word_AF": "karatmaliino",
        "word_ENG": "tax exemption ",
        "word_AM": "ከቀረጥ ነፃ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47430,
        "word_AF": "magaala",
        "word_ENG": "city",
        "word_AM": "ከተማ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47472,
        "word_AF": "konnabâgufne",
        "word_ENG": "courtesy  visit ",
        "word_AM": "ክብር /የ/ጉብኝት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47514,
        "word_AF": "qumda",
        "word_ENG": "mayor ",
        "word_AM": "ከተማ ሹም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47556,
        "word_AF": "kira",
        "word_ENG": "rent ",
        "word_AM": "ኪራይ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47598,
        "word_AF": "xaawa",
        "word_ENG": "dispute ",
        "word_AM": "ክርክር /አለማግባባት /",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47640,
        "word_AF": "aboolita",
        "word_ENG": "longitude ",
        "word_AM": "ኬንትሮስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47682,
        "word_AF": "caleyta",
        "word_ENG": "latitude ",
        "word_AM": "ኬክሮስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47724,
        "word_AF": "kartâ-kawsa",
        "word_ENG": "map reading ",
        "word_AM": "ካርታ ንባብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47766,
        "word_AF": "diini hawse wayti",
        "word_ENG": "secularism",
        "word_AM": "ከሀይማኖት ነፃ የሆነ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47808,
        "word_AF": "walala",
        "word_ENG": "discussion ",
        "word_AM": "ውይይት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47850,
        "word_AF": "keero",
        "word_ENG": "crime ",
        "word_AM": "ወንጀል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47892,
        "word_AF": "irô caagiida",
        "word_ENG": "foreign  affairs ",
        "word_AM": "ውጭ ጉዳይ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47934,
        "word_AF": "wakaalata",
        "word_ENG": "agency ",
        "word_AM": "ወኪል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 47976,
        "word_AF": "warara",
        "word_ENG": "aggression",
        "word_AM": "ወራሪ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48018,
        "word_AF": "qandê gali",
        "word_ENG": "military  wing",
        "word_AM": "ወታደራዊ ክንፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48060,
        "word_AF": "Aamantisso",
        "word_ENG": "insurance ",
        "word_AM": "ዋስትና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48102,
        "word_AF": "Aamanti-gee",
        "word_ENG": "insured ",
        "word_AM": "ዋስትና ያለው ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48144,
        "word_AF": "qandê saayat boodu",
        "word_ENG": "affect  military  security",
        "word_AM": "ወታደራዊ ደህንነት መንካት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48186,
        "word_AF": "umeyna",
        "word_ENG": "author of crime",
        "word_AM": "ወንጀለኛ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48228,
        "word_AF": "asgolla",
        "word_ENG": "assimilaion",
        "word_AM": "ውህድ/የማንነት ውህደት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48270,
        "word_AF": "foocâ fan",
        "word_ENG": "foreword",
        "word_AM": "ወደፈት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48312,
        "word_AF": "melleb fayya",
        "word_ENG": "price  increase ",
        "word_AM": "ዋጋ ንረት /የ/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48354,
        "word_AF": "qedebi",
        "word_ENG": "battle ",
        "word_AM": "ውጊያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48396,
        "word_AF": "alsal namma adda",
        "word_ENG": "bimonthly",
        "word_AM": "ወር ሁለት /በ/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48438,
        "word_AF": "melleb ramma",
        "word_ENG": "fall in price ",
        "word_AM": "ዋጋ ቅነሳ /የ/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48480,
        "word_AF": "fanak xallaya",
        "word_ENG": "abortion ",
        "word_AM": "ውርጃ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48522,
        "word_AF": "inaytâ magaala",
        "word_ENG": "capital  city",
        "word_AM": "ዋና ከተማ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48564,
        "word_AF": "caabi",
        "word_ENG": "pledge",
        "word_AM": "ዋስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48606,
        "word_AF": "korsi",
        "word_ENG": "chair ",
        "word_AM": "ወንበር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48648,
        "word_AF": "mawqó",
        "word_ENG": "costs",
        "word_AM": "ወጪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48690,
        "word_AF": "qalala",
        "word_ENG": "competition ",
        "word_AM": "ውድድር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48732,
        "word_AF": "cisaabiseynittê saqala",
        "word_ENG": "chief  accounts",
        "word_AM": "ዋና ሂሣብ ሹም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48774,
        "word_AF": "bagut",
        "word_ENG": "enclosed ",
        "word_AM": "ውስጥ የታቀፈ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48816,
        "word_AF": "daqaara",
        "word_ENG": "district ",
        "word_AM": "ወረዳ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48858,
        "word_AF": "kalâ kalqillah madqá",
        "word_ENG": "penal code",
        "word_AM": "ወንጀለኛ መቅጫ ህግ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48900,
        "word_AF": "amaaki sandugu",
        "word_ENG": "account  of credit ",
        "word_AM": "ወደ ሂሣብ ገቢ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48942,
        "word_AF": "abuud  sandugu",
        "word_ENG": "debit",
        "word_AM": "ወጭ ሂሣብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 48984,
        "word_AF": "leê naafo",
        "word_ENG": "condensation",
        "word_AM": "ውሃ ማጠዞ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49026,
        "word_AF": "a wakih caalata",
        "word_ENG": "current  conditions ",
        "word_AM": "ወቅታዊ ሁኔታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49068,
        "word_AF": "baditi",
        "word_ENG": "confusion ",
        "word_AM": "ውዥንብር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49110,
        "word_AF": "umagabali",
        "word_ENG": "culprit",
        "word_AM": "ወንጀለኛ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49152,
        "word_AF": "kaaqunta",
        "word_ENG": "cup",
        "word_AM": "ዋንጫ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49194,
        "word_AF": "waado",
        "word_ENG": "foreign exchange ",
        "word_AM": "ውጪ ምንዛሪ መጠን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49236,
        "word_AF": "maceela",
        "word_ENG": "crime ",
        "word_AM": "ወንጀል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49278,
        "word_AF": "baatil kee taturu",
        "word_ENG": "crime  and offences",
        "word_AM": "ወንጀልና ጥቃት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49320,
        "word_AF": "mawqo",
        "word_ENG": "out put",
        "word_AM": "ወጪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49362,
        "word_AF": "wano",
        "word_ENG": "decision ",
        "word_AM": "ውሳኔ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49404,
        "word_AF": "kibal dagna",
        "word_ENG": "defect of assurance ",
        "word_AM": "ዋስትና ጉድለት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49446,
        "word_AF": "margaqa",
        "word_ENG": "resolution ",
        "word_AM": "ውሳኔ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49488,
        "word_AF": "urriinô matluukannu",
        "word_ENG": "juvenile  delinquency",
        "word_AM": "ወጣትነት /የ/ድሩዬነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49530,
        "word_AF": "xalu",
        "word_ENG": "out come",
        "word_AM": "ውጤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49572,
        "word_AF": "lakqô mawqo",
        "word_ENG": "depenses",
        "word_AM": "ወጪ /የገንዘብ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49614,
        "word_AF": "gidê nawwa",
        "word_ENG": "deprecation",
        "word_AM": "ዋጋ ቅነሳ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49656,
        "word_AF": "melleb kubqi",
        "word_ENG": "un controlled  increase in prices ",
        "word_AM": "ወጋ ንረት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49698,
        "word_AF": "diglo",
        "word_ENG": "destruction ",
        "word_AM": "ውድመት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49740,
        "word_AF": "walala",
        "word_ENG": "dialogue  ",
        "word_AM": "ውይይት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49782,
        "word_AF": "tu edde taade taamagexsé",
        "word_ENG": "general  manager ",
        "word_AM": "ዋና ሥራ አስኪያጅ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49824,
        "word_AF": "balaalu",
        "word_ENG": "faliure",
        "word_AM": "ውድቅት /ጉድለት/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49866,
        "word_AF": "tuk iiso",
        "word_ENG": " the main thing",
        "word_AM": "ዋና ነገር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49908,
        "word_AF": "salala",
        "word_ENG": "head quarter ",
        "word_AM": "ዋና መምሪያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49950,
        "word_AF": "inkinnoowu",
        "word_ENG": "unification",
        "word_AM": "ውህደት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 49992,
        "word_AF": "margaqâ",
        "word_ENG": "verdict",
        "word_AM": "ውሳኔ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50034,
        "word_AF": "fiirissó-saqala",
        "word_ENG": "chief  editor ",
        "word_AM": "ዋና ኦዲተር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50076,
        "word_AF": "manbbalow qagu",
        "word_ENG": "resumption of negotiation ",
        "word_AM": "ውይይት እንደገና መጀመር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50118,
        "word_AF": "awliinu",
        "word_ENG": "representative ",
        "word_AM": "ውክልና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50160,
        "word_AF": "awliini dudda",
        "word_ENG": "representative  ability",
        "word_AM": "ውክልና ብቃት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50202,
        "word_AF": "weeqaytu",
        "word_ENG": "river",
        "word_AM": "ወንዝ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50244,
        "word_AF": "owolu",
        "word_ENG": "season ",
        "word_AM": "ወቅቶች ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50286,
        "word_AF": "leê gadda",
        "word_ENG": "hydraulic  renewal ",
        "word_AM": "ውሃ ሀብት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50328,
        "word_AF": "xali aqusbusiyya",
        "word_ENG": "result renewal",
        "word_AM": "ውጤት ተሃድሶ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50370,
        "word_AF": "taturtem gacissa madqa",
        "word_ENG": "retroactivity of  a law",
        "word_AM": "ወደ ኃላ ተመልሶ የሚስራ ህግ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50412,
        "word_AF": "bakarbohoyu",
        "word_ENG": "spectre of the thirst",
        "word_AM": "ውሃ ጥም ሥጋት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50454,
        "word_AF": "toobokô sitta qidiyya",
        "word_ENG": "fratricide",
        "word_AM": "ወንድማማች መገዳደል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50496,
        "word_AF": "caabinnu",
        "word_ENG": "guarantee ",
        "word_AM": "ዋስትና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50538,
        "word_AF": "daamaara",
        "word_ENG": "tar",
        "word_AM": "አስፋልት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50580,
        "word_AF": "ebbeltu",
        "word_ENG": "gratitude",
        "word_AM": "ውለታ /ምስጋና/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50622,
        "word_AF": "nagartinaane",
        "word_ENG": "heredity",
        "word_AM": "ውርስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50664,
        "word_AF": "fayda",
        "word_ENG": "interest ",
        "word_AM": "ወለደ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50706,
        "word_AF": "xibixi",
        "word_ENG": "invasion ",
        "word_AM": "ወረራ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50748,
        "word_AF": "qandê fanatraddo",
        "word_ENG": "military  intervention ",
        "word_AM": "ወታደራዊ ጣልቃ ገብነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50790,
        "word_AF": "iroh investimenti",
        "word_ENG": "foreign  investments ",
        "word_AM": "ውጭ ኢንቨስትመንት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50832,
        "word_AF": "gabul-le numu",
        "word_ENG": "obese man (woman)",
        "word_AM": "ወፍራም ስው",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50874,
        "word_AF": "badiida",
        "word_ENG": "ocean ",
        "word_AM": "ውቅያኖስ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50916,
        "word_AF": "qeebi tmsa",
        "word_ENG": "operations of fight",
        "word_AM": "ውጊያ ሂደት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 50958,
        "word_AF": "kayniiqê biyaaka",
        "word_ENG": "malaria",
        "word_AM": "ወባ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51000,
        "word_AF": "ascassenta",
        "word_ENG": "penel",
        "word_AM": "ውይይት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51042,
        "word_AF": "xagana",
        "word_ENG": "pact",
        "word_AM": "ውል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51084,
        "word_AF": "hawi",
        "word_ENG": "partisan",
        "word_AM": "ወገናዊ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51126,
        "word_AF": "lee fuuqe",
        "word_ENG": "permeable",
        "word_AM": "ውሃ የሚመጥ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51168,
        "word_AF": "furda",
        "word_ENG": "port",
        "word_AM": "ወደብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51210,
        "word_AF": "kaxxa badih onqoro",
        "word_ENG": "oceanic boottom",
        "word_AM": "ውቅያኖስ ወለል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51252,
        "word_AF": "qaskariinô ayfaafaya",
        "word_ENG": "military service ",
        "word_AM": "ወታደራዊ አገልግሎት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51294,
        "word_AF": "madaba",
        "word_ENG": "seat",
        "word_AM": "ወንበር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51336,
        "word_AF": "fooxima",
        "word_ENG": "whistle",
        "word_AM": "ዋሽንት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51378,
        "word_AF": "qande",
        "word_ENG": "military  solution ",
        "word_AM": "ወታደራዊ መፍትሄ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51420,
        "word_AF": "qaskariita",
        "word_ENG": "soldier  ",
        "word_AM": "ወታደር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51462,
        "word_AF": "web saayit",
        "word_ENG": "web site",
        "word_AM": "ዌብ ሳይት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51504,
        "word_AF": "tu edde cabta kutbe abeyna",
        "word_ENG": "general  secretary ",
        "word_AM": "ዋና ፀሐፊ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51546,
        "word_AF": "addâ saaya",
        "word_ENG": "internal  security ",
        "word_AM": "ውስጥ ፀጥታ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51588,
        "word_AF": "ummattâ margaqa",
        "word_ENG": "referendum",
        "word_AM": "ውሳኔ ህዝብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51630,
        "word_AF": "nagra",
        "word_ENG": "succession",
        "word_AM": "ውርስ: ተከታታይ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51672,
        "word_AF": "mawuq",
        "word_ENG": "to calculate  spending ",
        "word_AM": "ወጪን ማስብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51714,
        "word_AF": "fuli gide",
        "word_ENG": "rate of interest ",
        "word_AM": "ወለድ መጠን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51756,
        "word_AF": "lee gexsoh maknaya",
        "word_ENG": "system  of drainage ",
        "word_AM": "ውሃ መውረጃ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51798,
        "word_AF": "kikkaaqi",
        "word_ENG": "stress",
        "word_AM": "ውጥረት : ድካም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51840,
        "word_AF": "assiti",
        "word_ENG": "treaty",
        "word_AM": "ውል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51882,
        "word_AF": "umeenti gacsih ittingeyi",
        "word_ENG": "treaty of extradition",
        "word_AM": "ወንጀለኛን የመለ ዋወጥ ውል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51924,
        "word_AF": "digaalâ madqa",
        "word_ENG": "penal law",
        "word_AM": "ወንጀለኛ መቅጫ ህግ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 51966,
        "word_AF": "wadirgacak taamitta madqa",
        "word_ENG": "retrospectiverly applicable  law",
        "word_AM": "ወደኋላ ተመልሶ የሚስራ ህግ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52008,
        "word_AF": "awliini dudda",
        "word_ENG": "mandate ",
        "word_AM": "ውክልና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52050,
        "word_AF": "canti warsha",
        "word_ENG": "dairy ",
        "word_AM": "ወተት ማምረቻ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52092,
        "word_AF": "gifti",
        "word_ENG": "madam",
        "word_AM": "ወ/ሮ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52134,
        "word_AF": "bookaliita",
        "word_ENG": "miss",
        "word_AM": "ወ/ሪት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52176,
        "word_AF": "alsi majallata",
        "word_ENG": "monthly  magazine ",
        "word_AM": "ወርሃዊ መጽሄት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52218,
        "word_AF": "exxaaxi mango abto",
        "word_ENG": "multi - lateral action",
        "word_AM": "ዘርፈ ብዘ ድርጊቶች",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52260,
        "word_AF": "xaagi wakaalata",
        "word_ENG": "news agency ",
        "word_AM": "ዜና ወኪል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52302,
        "word_AF": "gulgulu",
        "word_ENG": "alert",
        "word_AM": "ዝግጁነት : መጠንቀቅ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52344,
        "word_AF": "fuli  ayro-le liggida",
        "word_ENG": "leap year",
        "word_AM": "ዘመነ ዮሐንስ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52386,
        "word_AF": "afkana",
        "word_ENG": "atitude",
        "word_AM": "ዝንባሌ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52428,
        "word_AF": "abiloowo",
        "word_ENG": "family  tree",
        "word_AM": "ዘር ሀረግ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52470,
        "word_AF": "cundubu",
        "word_ENG": "axis ",
        "word_AM": "ዘንግ /አክስስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52512,
        "word_AF": "rado",
        "word_ENG": "burglary",
        "word_AM": "ዘረፋ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52554,
        "word_AF": "geysiisi",
        "word_ENG": "campaign ",
        "word_AM": "ዘመቻ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52596,
        "word_AF": "baaxô baxa",
        "word_ENG": "citizen ",
        "word_AM": "ዜጋ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52638,
        "word_AF": "mariino",
        "word_ENG": "citizenship ",
        "word_AM": "ዜግነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52680,
        "word_AF": "kassowna",
        "word_ENG": "party(dance)",
        "word_AM": "/የ/ዝግጅት ምሽት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52722,
        "word_AF": "xaagu",
        "word_ENG": "journalist ",
        "word_AM": "ዜና አስተላለፈ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52764,
        "word_AF": "kari",
        "word_ENG": "crown ",
        "word_AM": "ዘውድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52806,
        "word_AF": "samad -baysi-baatili",
        "word_ENG": "crime against  humanity",
        "word_AM": "ዘር ማጥፋት ወንጀል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52848,
        "word_AF": "samad",
        "word_ENG": "race",
        "word_AM": "ዘር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52890,
        "word_AF": "bisi baxaabaxsali",
        "word_ENG": "racist ",
        "word_AM": "ዘረኛ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52932,
        "word_AF": "lagô gexsesiinu",
        "word_ENG": "racism",
        "word_AM": "ዘረኝነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 52974,
        "word_AF": "rasu",
        "word_ENG": "zone",
        "word_AM": "ዞን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53016,
        "word_AF": "afeyta",
        "word_ENG": "dialect",
        "word_AM": "ዘዮ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53058,
        "word_AF": "hebeeka",
        "word_ENG": "reputation ",
        "word_AM": "ዝና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53100,
        "word_AF": "mermersu",
        "word_ENG": "rotation ",
        "word_AM": "ዙር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53142,
        "word_AF": "kaalayta gacaagacsa",
        "word_ENG": "rhythm ",
        "word_AM": "ዜማ አወራረድ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53184,
        "word_AF": "taaqe bukko",
        "word_ENG": "usurper",
        "word_AM": "ዙፋን ነጠቃ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53226,
        "word_AF": "waddi, udurruteh",
        "word_ENG": " late comer",
        "word_AM": "ዘግይቶ የመጣ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53268,
        "word_AF": "hoomata",
        "word_ENG": "defamation",
        "word_AM": "ዝናን የሚያጎድፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53310,
        "word_AF": "wadirroowe",
        "word_ENG": "delayed ",
        "word_AM": "ዘገየ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53352,
        "word_AF": "lagoo kee bisi baxaabaxsa",
        "word_ENG": "racial  discrimination ",
        "word_AM": "ዘርና ቀለም ክፍፍል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53394,
        "word_AF": "afaafah tan goranto",
        "word_ENG": "complete  search",
        "word_AM": "ውስብስብ ጥናት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53436,
        "word_AF": "adda fakotle aqayyaare",
        "word_ENG": "detailed  exam",
        "word_AM": "ዝርዝር ፈተና ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53478,
        "word_AF": "wargu",
        "word_ENG": "epoch",
        "word_AM": "ዘመን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53520,
        "word_AF": "samad-baysa",
        "word_ENG": "genocide",
        "word_AM": "ዘር ማጥፋት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53562,
        "word_AF": "abi-loowo",
        "word_ENG": "genealogy ",
        "word_AM": "ዘር ቆጠራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53604,
        "word_AF": "carbik habbaale-waan umaane",
        "word_ENG": "horrible  experience  of the war",
        "word_AM": "ዘግናኝ የጦርነት /ትውስታዎች/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53646,
        "word_AF": "baxaaxicisso kalaata",
        "word_ENG": "suspension  of broadcasting",
        "word_AM": "ዜና ማገድ/የሬዲዮ  ፕሮግራም ማገድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53688,
        "word_AF": "macallaltu",
        "word_ENG": "interim ",
        "word_AM": "ጊዜያዊ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53730,
        "word_AF": "amoytiinu",
        "word_ENG": "monarchy",
        "word_AM": "ዘውዳዊ አገዛዝ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53772,
        "word_AF": "qusbah",
        "word_ENG": "modern",
        "word_AM": "ዘመናዊ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53814,
        "word_AF": "qasaane",
        "word_ENG": "modernity",
        "word_AM": "ዘመናዊነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53856,
        "word_AF": "agattu",
        "word_ENG": "national ",
        "word_AM": "ዜጋ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53898,
        "word_AF": "agattiinaane",
        "word_ENG": "nationality",
        "word_AM": "ዜግነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53940,
        "word_AF": "rabi warisso",
        "word_ENG": "necrology",
        "word_AM": "ዜና እረፍት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 53982,
        "word_AF": "samad baysa",
        "word_ENG": "ethnic  cleaning ",
        "word_AM": "ዘር ማጥፋት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54024,
        "word_AF": "xaagitte",
        "word_ENG": "news",
        "word_AM": "ዜና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54066,
        "word_AF": "itta waaxaagu",
        "word_ENG": "contradictory news",
        "word_AM": "ዜና /የሚጋጭ /",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54108,
        "word_AF": "amoyani",
        "word_ENG": "eternity",
        "word_AM": "ዘለቄታዊ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54150,
        "word_AF": "rado",
        "word_ENG": "plunder",
        "word_AM": "ዝርፍያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54192,
        "word_AF": "caxa daabisi",
        "word_ENG": "plant",
        "word_AM": "ተከለ : ዛፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54234,
        "word_AF": "robti kaaliyya",
        "word_ENG": "pluviometer ",
        "word_AM": "ዝናብ መለኪያ ሜትር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54276,
        "word_AF": "qeegu",
        "word_ENG": "tendency",
        "word_AM": "ዝንባሌ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54318,
        "word_AF": "taaqe",
        "word_ENG": "throne",
        "word_AM": "ዙፋን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54360,
        "word_AF": "istiqaara",
        "word_ENG": "metaphor",
        "word_AM": "ዘይቤያዊ አነጋገር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54402,
        "word_AF": "cogda",
        "word_ENG": "method ",
        "word_AM": "ዘዴ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54444,
        "word_AF": "rammale qunxah",
        "word_ENG": "minor",
        "word_AM": "ዝቅተኛ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54486,
        "word_AF": "xaagi baxcisso",
        "word_ENG": "broadcasting",
        "word_AM": "ዜና ስርጭት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54528,
        "word_AF": "xaagi baxcisiyya",
        "word_ENG": "broadcast ",
        "word_AM": "ዜና ማስራጨት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54570,
        "word_AF": "hebeeka-le-miraaca",
        "word_ENG": "charismatic leader",
        "word_AM": "ዝነኛ መሪ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54612,
        "word_AF": "taturu",
        "word_ENG": "abuse ",
        "word_AM": "ያለ አግባብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54654,
        "word_AF": "badak-barriita",
        "word_ENG": "amphibian",
        "word_AM": "የብስና ውሃ ውስጥ የሚኖር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54696,
        "word_AF": "isih barte",
        "word_ENG": "self -taught ",
        "word_AM": "ያለአስተማሪ የተማሪ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54738,
        "word_AF": "siyaasa maliino",
        "word_ENG": "a political ",
        "word_AM": "ያለ ፓለቲካ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54780,
        "word_AF": "timixxige maysaxxaga",
        "word_ENG": "official  statement ",
        "word_AM": "ይፋ መግለጫ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54822,
        "word_AF": "qagufaxtâ caxa",
        "word_ENG": "court of appeal",
        "word_AM": "የይግባኝ ፍ/ቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54864,
        "word_AF": "beenim maydabba",
        "word_ENG": "denationalization",
        "word_AM": "የወስዳትን መመለስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54906,
        "word_AF": "yangalen baritto",
        "word_ENG": "laic school",
        "word_AM": "ያልተለየ ት/ት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54948,
        "word_AF": "YUNISEF",
        "word_ENG": "unicef",
        "word_AM": "ዩኒሴፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 54990,
        "word_AF": "de fakotoh cukuumata",
        "word_ENG": "government  de facto",
        "word_AM": "ያለ መንግስት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55032,
        "word_AF": "asta le horta",
        "word_ENG": "target group",
        "word_AM": "የተነጣጠረበት ቡድን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55074,
        "word_AF": "raage qeebi",
        "word_ENG": "prolonged war",
        "word_AM": "የተራዘመ ጦርነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55116,
        "word_AF": "wagri guubu",
        "word_ENG": "heaven  of peace",
        "word_AM": "የስላም ማረፈያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55158,
        "word_AF": "reedon duddô raawa",
        "word_ENG": "hierarchy ",
        "word_AM": "የባለሥልጣናት ደረጀ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55200,
        "word_AF": "ayidiyooloji",
        "word_ENG": "idology",
        "word_AM": "የፓለቲካ ዘይቤ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55242,
        "word_AF": "yooma-xiqtá iyye",
        "word_ENG": "he has taken his case to the appeal  court",
        "word_AM": "ይግባኝ ብሏል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55284,
        "word_AF": "ellecabô bacaara",
        "word_ENG": "last sixteen",
        "word_AM": "የመጨረሻ ተፎካካሪ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55326,
        "word_AF": "furgata",
        "word_ENG": "humor",
        "word_AM": "የጨዋታ ለዛ /የውይይት  ለዛ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55368,
        "word_AF": "qiyya baabur saaqoota",
        "word_ENG": " train schedule ",
        "word_AM": "የባቡር የጊዜ ስሌዳ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55410,
        "word_AF": "mago",
        "word_ENG": "outstanding  payment ",
        "word_AM": "ያልተከፈለ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55452,
        "word_AF": "xexxár qiso",
        "word_ENG": "land tax",
        "word_AM": "የመሬት ግብር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55494,
        "word_AF": "qikô karata",
        "word_ENG": "general  tax of solidarity ",
        "word_AM": "የድጋፍ ቀረጥ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55536,
        "word_AF": "qasbil haan karata",
        "word_ENG": "taxes on salaries ",
        "word_AM": "የደመወዝ ታክስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55578,
        "word_AF": "assakaata",
        "word_ENG": "impressive ",
        "word_AM": "የሚድነቅ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55620,
        "word_AF": "kuurinan",
        "word_ENG": "industrial",
        "word_AM": "የኢንዱስትሪ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55662,
        "word_AF": "melleb fayya",
        "word_ENG": " inflation",
        "word_AM": "የዋጋ ግሽበት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55704,
        "word_AF": "dadal kusaaqih muhandisi",
        "word_ENG": "engineer  of studies  of development ",
        "word_AM": "የልማት ጥናት መሀንዲስ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55746,
        "word_AF": "cakkumu",
        "word_ENG": "unusual ",
        "word_AM": "ያለተለመደ : ልዩ የሆነ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55788,
        "word_AF": "naharsi caddoh hawwasaysé",
        "word_ENG": "inspector  of the first  degree ",
        "word_AM": "የመጀመሪያ ደረጀ ተቆጣጣሪ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55830,
        "word_AF": "pooliskusaaqa",
        "word_ENG": "interrogation of the police  ",
        "word_AM": "የፓሊስ ምርመራ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55872,
        "word_AF": "kooni xagana",
        "word_ENG": "intimacy",
        "word_AM": "የጠለቀ ወዳጅነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55914,
        "word_AF": "curriyat satta",
        "word_ENG": "enjyment of a freedom",
        "word_AM": "የነፃነት ደስታ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55956,
        "word_AF": "liggidi qqemboh ayro",
        "word_ENG": "the first  day of the year",
        "word_AM": "የዓመቱ የመጀመሪያ ቀን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 55998,
        "word_AF": "gita mali nuway gurra",
        "word_ENG": "irregular way of life",
        "word_AM": "የልተለመደ የኑሮ ሁኔታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56040,
        "word_AF": "ayro loowo",
        "word_ENG": "solar month",
        "word_AM": "የፀሐይ አቆጣጠር ወር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56082,
        "word_AF": "rabootu",
        "word_ENG": "mortality ",
        "word_AM": "የሚሞቱ ስዎች : ሟችነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56124,
        "word_AF": "urri rabootu",
        "word_ENG": "infant mortality ",
        "word_AM": "የሕፃናት ምት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56166,
        "word_AF": "sabó",
        "word_ENG": "mon soon",
        "word_AM": "የሚነሱ ነፈሰ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56208,
        "word_AF": "anfaddag mali",
        "word_ENG": "mystery ",
        "word_AM": "የተስወረ ጉዳይ /ምስጢር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56250,
        "word_AF": "miiz saro",
        "word_ENG": "table  cloth ",
        "word_AM": "የጠረጴዛ ልብስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56292,
        "word_AF": "ubkaytu",
        "word_ENG": "native ",
        "word_AM": "የአገር ተወላጅ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56334,
        "word_AF": "galli maro",
        "word_ENG": "unitad nations",
        "word_AM": "የተባበሩት መንግስታት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56376,
        "word_AF": "nuway raawa",
        "word_ENG": "level  of life",
        "word_AM": "የኑሮ ደረጀ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56418,
        "word_AF": "maro muggaaqisso",
        "word_ENG": "appointment  of a committee ",
        "word_AM": "የኮሚቴ ሹመት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56460,
        "word_AF": "qaadi",
        "word_ENG": "normal ",
        "word_AM": "የተለመደ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56502,
        "word_AF": "kassoynâ xaagu",
        "word_ENG": "evenning news",
        "word_AM": "የምሽት ዜና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56544,
        "word_AF": "warenti abto",
        "word_ENG": "literary work",
        "word_AM": "የሥነ ጽሑፍ ሥራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56586,
        "word_AF": "xaagi oytisé",
        "word_ENG": "intelligence  officer",
        "word_AM": "የመረጃ መኮንን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56628,
        "word_AF": "timixxigé",
        "word_ENG": "official ",
        "word_AM": "የይፋ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56670,
        "word_AF": "gabâ bombi",
        "word_ENG": "grenade",
        "word_AM": "የእጅ ቦምብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56712,
        "word_AF": "sadar tü mabulu",
        "word_ENG": "public  opinion ",
        "word_AM": "የህዝብ እይታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56754,
        "word_AF": "intî meray bicise",
        "word_ENG": "optician",
        "word_AM": "የዓይን መነጽር ሻጭ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56796,
        "word_AF": "amrisenta",
        "word_ENG": "prescription ",
        "word_AM": "የሀክም ትዕዛዝ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56838,
        "word_AF": "kilbatti atlantikxagnih massoyna",
        "word_ENG": "nato",
        "word_AM": "የሰሜን አትላንቲክ አገሮች ሕብረት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56880,
        "word_AF": "magaadâ yaakumik ciggiili",
        "word_ENG": "order of merit",
        "word_AM": "ይገበዋል ቀደም ተከተል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56922,
        "word_AF": "makkoh amrisenta",
        "word_ENG": "orders ",
        "word_AM": "የሥራ ትዕዛዝ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 56964,
        "word_AF": "islaam maroh massoyna",
        "word_ENG": "organization  of the islamic  conference ",
        "word_AM": "የሙስሊም አገሮች  ሕብረት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57006,
        "word_AF": "ummattâ handaga",
        "word_ENG": " palace  of the people ",
        "word_AM": "የሕዝብ አዳራሽ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57048,
        "word_AF": "ummuunoh abbootanih handaga",
        "word_ENG": "presidential  palace  ",
        "word_AM": "የፕሬዚዳንት ቤተ መንግስት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57090,
        "word_AF": "kaaxa kalitteh baaxooxa",
        "word_ENG": "countries  of great  lakes ",
        "word_AM": "የታላላቅ ሐይቆች አካባቢ አገሮች ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57132,
        "word_AF": "xaahi dabaana",
        "word_ENG": "paleolithic",
        "word_AM": "የድንጋይ ዘመን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57174,
        "word_AF": "rasi inkittiino dacrisa xagana",
        "word_ENG": "territorial integrity  pact guaranteeing",
        "word_AM": "የግዛት አንድነት የሚያረጋግጥ  ቃል ኪዳን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57216,
        "word_AF": "banki damaanatih sumaq bicisiyya",
        "word_ENG": " to open a credit latter ",
        "word_AM": "የክሬዲት ዋስትና መከፈት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57258,
        "word_AF": "caacay afkana",
        "word_ENG": "wind direction ",
        "word_AM": "የንፋስ አቅጣጫ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57300,
        "word_AF": "malâ giqi",
        "word_ENG": "paradox",
        "word_AM": "የሚጋጨ/ሀሣብ /",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57342,
        "word_AF": "faaluju",
        "word_ENG": "paraliysis",
        "word_AM": "የስውነት መስለል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57384,
        "word_AF": "sattah araca",
        "word_ENG": "park of leisure activities ",
        "word_AM": "የመዝናኛ እንቅስቃሴ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57426,
        "word_AF": "barlemaan adoyta",
        "word_ENG": "parliamentarian",
        "word_AM": "የፓርላማ አባል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57468,
        "word_AF": "qadaagâ maglaba",
        "word_ENG": "market share",
        "word_AM": "የገበያ ድርሻ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57510,
        "word_AF": "biyaktabisi",
        "word_ENG": "pathogenic",
        "word_AM": "የበሽታ መንስኤ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57552,
        "word_AF": "dadalte baaxooxa",
        "word_ENG": "developed  countries ",
        "word_AM": "ያደጉ አገሮች",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57594,
        "word_AF": "barsiyyi migda",
        "word_ENG": "pedagogy",
        "word_AM": "የማስተማር ዘዴ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57636,
        "word_AF": "urri daylaabé",
        "word_ENG": "pediatrician",
        "word_AM": "የሕፃናት ሐኪም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57678,
        "word_AF": "urri dayla",
        "word_ENG": "peadiatrics",
        "word_AM": "የሕፃናት ሕክምና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57720,
        "word_AF": "melkle digaala",
        "word_ENG": "finable punishments",
        "word_AM": "የሚያስቀጣ ድርጊት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57762,
        "word_AF": "baatildigaala",
        "word_ENG": "criminal  of punishments",
        "word_AM": "የወንጀል ቅጣት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57804,
        "word_AF": "faxxiimewaanumu",
        "word_ENG": "personal non-grate",
        "word_AM": "የማይፈለግ ስው",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57846,
        "word_AF": "maddur ikraarisso",
        "word_ENG": "economic  planning ",
        "word_AM": "የኢኮኖሚ ፕላን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57888,
        "word_AF": "qalta",
        "word_ENG": "tray",
        "word_AM": "የደጋ አገር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57930,
        "word_AF": "kinnik-hinna dooriti",
        "word_ENG": "plebiscite",
        "word_AM": "የሕዝብ ውሳኔ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 57972,
        "word_AF": "bolomberi",
        "word_ENG": "plumbing ",
        "word_AM": "የቧንቧ ጥገና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58014,
        "word_AF": "gubloh adlaake",
        "word_ENG": "pneumonia",
        "word_AM": "የሳንባ ምች",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58056,
        "word_AF": "nef naafis",
        "word_ENG": "portrait ",
        "word_AM": "የስው ስዕል ስዓሊ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58098,
        "word_AF": "naharsi xaahih daabisso",
        "word_ENG": "laying of first stone ",
        "word_AM": "የመሠረተ ድንጋይ መጣል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58140,
        "word_AF": "takku duddaama",
        "word_ENG": "possibility ",
        "word_AM": "የሚቻል አማራጭ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58182,
        "word_AF": "daadaya",
        "word_ENG": "pole",
        "word_AM": "የዋልታ የሞደር ምስሶ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58224,
        "word_AF": "timixxigi",
        "word_ENG": "recognized ",
        "word_AM": "የታወቀ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58266,
        "word_AF": "magoh askotta",
        "word_ENG": " covering  of oustandings",
        "word_AM": "ያልተስበስበ እዳ መስብስብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58308,
        "word_AF": "garqô duyye",
        "word_ENG": "possession  of stolen  goods ",
        "word_AM": "የተስረቁ እቃዎች",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58350,
        "word_AF": "jaamiqata",
        "word_ENG": "university ",
        "word_AM": "ዩኒቨርሰቲ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58392,
        "word_AF": "jaamiqat barteyna",
        "word_ENG": "university  student ",
        "word_AM": "የዩኒቨርሲቲ ተማሪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58434,
        "word_AF": "gaaboowe culenta",
        "word_ENG": "collected  income",
        "word_AM": "የተስበስበ ገቢ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58476,
        "word_AF": "falmah esseri",
        "word_ENG": "demands",
        "word_AM": "ይገባኛል ጥያቄ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58518,
        "word_AF": "sissinaane",
        "word_ENG": "variety ",
        "word_AM": "የተለያየ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58560,
        "word_AF": "assimaa",
        "word_ENG": "stay sejourn",
        "word_AM": "ያሳለፈው ጊዜ (መስንበት)",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58602,
        "word_AF": "baxsa le qangooru",
        "word_ENG": " term  terminology ",
        "word_AM": "የተለያዩ ቃላት/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58644,
        "word_AF": "missô haxaxa",
        "word_ENG": "to make  concision",
        "word_AM": "የተወሰነ መተው ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58686,
        "word_AF": "yimixxige raaqiyya",
        "word_ENG": " extraordinaire",
        "word_AM": "ያልተለመደ /ልዩ /",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58728,
        "word_AF": "suge wayteemi",
        "word_ENG": "volume ",
        "word_AM": "ይዘት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58770,
        "word_AF": "addattino",
        "word_ENG": "status  quo",
        "word_AM": "ያለው ሁኔታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58812,
        "word_AF": "yanicaxxa",
        "word_ENG": "supposition",
        "word_AM": "የይሆናል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58854,
        "word_AF": "takkay-takka",
        "word_ENG": "pass",
        "word_AM": "ይለፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58896,
        "word_AF": "tatur-xic",
        "word_ENG": "subscriber ",
        "word_AM": "ደንበኛ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58938,
        "word_AF": "maqmiili",
        "word_ENG": "subscription ",
        "word_AM": "ደንበኝነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 58980,
        "word_AF": "maqmiilannu",
        "word_ENG": "act",
        "word_AM": "ድርጊት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59022,
        "word_AF": "abto",
        "word_ENG": "stone age",
        "word_AM": "ድንጋይ ዘመን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59064,
        "word_AF": "dubaala",
        "word_ENG": "wild animals ",
        "word_AM": "ዱር አራዊት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59106,
        "word_AF": "tekko mango liggida",
        "word_ENG": "eventful year",
        "word_AM": "ድርጊት የበዛበት ዓመት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59148,
        "word_AF": "afumu",
        "word_ENG": "ambush",
        "word_AM": "ደፈጣ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59190,
        "word_AF": "amô-wagit",
        "word_ENG": "auspices",
        "word_AM": "ከበላይ መቆጣጠር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59232,
        "word_AF": "assamaq sinna",
        "word_ENG": "austerity",
        "word_AM": "ድሎት   የለሽ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59274,
        "word_AF": "anaya",
        "word_ENG": "sound ",
        "word_AM": "ድምጽ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59316,
        "word_AF": "bakalooriya",
        "word_ENG": "diploma ",
        "word_AM": "ዲፕሎማ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59358,
        "word_AF": "gexay gacim warkata",
        "word_ENG": "round  trip  ticket ",
        "word_AM": "ደርሶ መልስ ቲኬት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59400,
        "word_AF": "atcat mudumu",
        "word_ENG": "involuntary wounds",
        "word_AM": "ድንገተኛ ቁስለት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59442,
        "word_AF": "abud qeedaala",
        "word_ENG": "balance  credit ",
        "word_AM": "ዱቤ ሚዛን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59484,
        "word_AF": "abbud boonu",
        "word_ENG": "credit card",
        "word_AM": "ዱቤ ካርድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59526,
        "word_AF": "rufto",
        "word_ENG": "happiness",
        "word_AM": "ደስታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59568,
        "word_AF": "nagaayah asta",
        "word_ENG": "police  record ",
        "word_AM": "ደህንነት /የዘፈን /",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59610,
        "word_AF": "inshá",
        "word_ENG": "composition ",
        "word_AM": "ድርሰት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59652,
        "word_AF": "gaddi bicsa",
        "word_ENG": "composition  of song",
        "word_AM": "የዘፈን ድርሰት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59694,
        "word_AF": "madruuru",
        "word_ENG": "customer ",
        "word_AM": "ደንበኛ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59736,
        "word_AF": "madruurwa",
        "word_ENG": "clientele",
        "word_AM": "ደንበኞች ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59778,
        "word_AF": "farmô warkata",
        "word_ENG": "mail",
        "word_AM": "ደብዳቤ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59820,
        "word_AF": "wano",
        "word_ENG": "failing ",
        "word_AM": "ድንጋጌ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59862,
        "word_AF": "boola",
        "word_ENG": "registration  of copy right",
        "word_AM": "ድክመት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59904,
        "word_AF": "orbisê akkih maysaqarra",
        "word_ENG": "democracy ",
        "word_AM": "ደራሲ መብት ምዝገባ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59946,
        "word_AF": "demokraasi",
        "word_ENG": "author ",
        "word_AM": "ዴሞክራሲ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 59988,
        "word_AF": "kitab yaktubi",
        "word_ENG": "emergency ",
        "word_AM": "ደራሲ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60030,
        "word_AF": "cubi-waynu",
        "word_ENG": "event",
        "word_AM": "ድንገተኛ /የሚያስቸኩል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60072,
        "word_AF": "tekko",
        "word_ENG": "diplomatic historicrent",
        "word_AM": "ድርጊት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60114,
        "word_AF": "diblomaasii kee aydaadi tekko",
        "word_ENG": "event",
        "word_AM": "ዲፕሎማሲና የታሪክ ድርጊቶች",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60156,
        "word_AF": "abto",
        "word_ENG": "doctorate",
        "word_AM": "ድርጊት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60198,
        "word_AF": "daktoora",
        "word_ENG": "doctor ",
        "word_AM": "ዶክትሬት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60240,
        "word_AF": "duoktooru",
        "word_ENG": "drama",
        "word_AM": "ዶክተር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60282,
        "word_AF": "ransá",
        "word_ENG": "victory",
        "word_AM": "ድራማ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60324,
        "word_AF": "mayso",
        "word_ENG": "vulnerable ",
        "word_AM": "ድል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60366,
        "word_AF": "qaku le tattaba",
        "word_ENG": "democratic  revival",
        "word_AM": "ደካማ ጎን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60408,
        "word_AF": "deokraasi  saaddoowu",
        "word_ENG": "breaching of diplomatic relation ",
        "word_AM": "ዲሞክራሲያዊ ተሃድሶ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60450,
        "word_AF": "diblomaasi fantaaxawih garuuqu",
        "word_ENG": "salary ",
        "word_AM": "ዲፕሎማሲያዊ ግንኙነት ማቋረጥ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60492,
        "word_AF": "qasbi",
        "word_ENG": "copy right ",
        "word_AM": "ደመወዝ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60534,
        "word_AF": "yaskooboobi  gara",
        "word_ENG": "diploma ",
        "word_AM": "ደራሲ /የ/መብት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60576,
        "word_AF": "baritto sumaaqa",
        "word_ENG": "diplomat",
        "word_AM": "ዲፕሎማ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60618,
        "word_AF": "diplomaasiita",
        "word_ENG": "diplomacy",
        "word_AM": "ዲፕሎማት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60660,
        "word_AF": "diplomaasi",
        "word_ENG": "north-south inequlibrium",
        "word_AM": "ዲፕሎማሲ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60702,
        "word_AF": "gabbi qaxaa kee kilbatti sitta qeedaale wayti",
        "word_ENG": "diplomatic sources ",
        "word_AM": "ደቡብና ሰሜን አለመመጣጠን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60744,
        "word_AF": "diplomaasih raceyna",
        "word_ENG": "subscription ",
        "word_AM": "ዲፕሎማሲያዊ ምንጭች",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60786,
        "word_AF": "madruurannu",
        "word_ENG": "sponsor ",
        "word_AM": "ደንበኝነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60828,
        "word_AF": "maali qiko  timixxige caddo",
        "word_ENG": "standard ",
        "word_AM": "ደጋፈ /በገንዘብ ደረጀ የተወሰነ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60870,
        "word_AF": "kaalayta maqaaneh mettebi",
        "word_ENG": "technician  sound ",
        "word_AM": "ድምፅ ቴክኒሽያን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60912,
        "word_AF": "diblomaasi qalla",
        "word_ENG": "diplomatic relation ",
        "word_AM": "ዲፕሎማሲያዊ ግነኙነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60954,
        "word_AF": "edde-xintá",
        "word_ENG": "rule ",
        "word_AM": "ደንብ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 60996,
        "word_AF": "xongolo",
        "word_ENG": "voice ",
        "word_AM": "ድምፅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61038,
        "word_AF": "hittat",
        "word_ENG": "totality ",
        "word_AM": "ድምር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61080,
        "word_AF": "afumut mude",
        "word_ENG": "sniper",
        "word_AM": "ደፈጣ ተዋጊ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61122,
        "word_AF": "doolat caraya",
        "word_ENG": "subsidy",
        "word_AM": "ድጎማ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61164,
        "word_AF": "siirata",
        "word_ENG": "system ",
        "word_AM": "ድንብ ህግ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61206,
        "word_AF": "farmô warakat ruubiyya",
        "word_ENG": "to send a mail",
        "word_AM": "ደብዳቤ መላክ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61248,
        "word_AF": "qokol hortitte",
        "word_ENG": "groups of support ",
        "word_AM": "ደጋፈ ቡድኖች",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61290,
        "word_AF": "maadi",
        "word_ENG": "war of border",
        "word_AM": "ድንበር ላይ ግጭት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61332,
        "word_AF": "ranko",
        "word_ENG": "rank",
        "word_AM": "ደረጃ/መደብ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61374,
        "word_AF": "maaqatta maaqattah",
        "word_ENG": "step by step",
        "word_AM": "ደረጃ በደረጃ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61416,
        "word_AF": "maggo qaynata",
        "word_ENG": "heterogeneous",
        "word_AM": "ድብልቅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61458,
        "word_AF": "cunxo",
        "word_ENG": "horror",
        "word_AM": "ድንጋጤ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61500,
        "word_AF": "gadiirata",
        "word_ENG": "island",
        "word_AM": "ደሴት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61542,
        "word_AF": "massoynaani",
        "word_ENG": "institutions",
        "word_AM": "ድርጅቶች : ተቋሞች ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61584,
        "word_AF": "massoyssino",
        "word_ENG": "institutionalisation",
        "word_AM": "ድርጅታዊነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61626,
        "word_AF": "gar-kureyna",
        "word_ENG": "judge",
        "word_AM": "ዳኛ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61668,
        "word_AF": "gar-kuro",
        "word_ENG": "judgment ",
        "word_AM": "ዳኝነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61710,
        "word_AF": "satta",
        "word_ENG": "enjoyment",
        "word_AM": "ደስታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61752,
        "word_AF": "dagiigata",
        "word_ENG": "minute ",
        "word_AM": "ደቂቃ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61794,
        "word_AF": "cubewayni raba",
        "word_ENG": "sudden  death",
        "word_AM": "ድንገተኛ ሞት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61836,
        "word_AF": "gabâ-dagiina le baaxooxa",
        "word_ENG": "poor nations",
        "word_AM": "ደሀ አገሮች ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61878,
        "word_AF": "mablo",
        "word_ENG": "negotiation ",
        "word_AM": "ድርድር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61920,
        "word_AF": "massoyna",
        "word_ENG": "organization ",
        "word_AM": "ድርጅት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 61962,
        "word_AF": "warah afeytisiyyih cubbusso",
        "word_ENG": "phonetics",
        "word_AM": "ድምፅ ልሳን ጥናት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62004,
        "word_AF": "abtoh ekaraaro",
        "word_ENG": "action  plan",
        "word_AM": "ድርጊት ፕላን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62046,
        "word_AF": "farmo ruubiyya",
        "word_ENG": "to post",
        "word_AM": "ደብዳቤ መላክ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62088,
        "word_AF": "boola",
        "word_ENG": "weakness",
        "word_AM": "ድክምት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62130,
        "word_AF": "unkaqiinoh alfaydisiyya",
        "word_ENG": "congratulations ",
        "word_AM": "ደስታ መግለጫ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62172,
        "word_AF": "gabbi",
        "word_ENG": "south",
        "word_AM": "ደቡብ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62214,
        "word_AF": "xongolo macoo",
        "word_ENG": "vote",
        "word_AM": "ድምፅ መስጠት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62256,
        "word_AF": "farmoh ayyufta",
        "word_ENG": "latter ",
        "word_AM": "ደብዳቤ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62298,
        "word_AF": "cudud wano",
        "word_ENG": "limit  of border  zone",
        "word_AM": "ድንበር ወስን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62340,
        "word_AF": "bedu",
        "word_ENG": "emblem",
        "word_AM": "ድርጅት  አርማ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62382,
        "word_AF": "karraarisso",
        "word_ENG": "microphone ",
        "word_AM": "ድምፅ ማጉሊያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62424,
        "word_AF": "madqah exxa",
        "word_ENG": "legislative ",
        "word_AM": "ድንጋጌ /ህግ አውጪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62466,
        "word_AF": "demokraasi daabisaanam baaxoh wagari xalta",
        "word_ENG": "the restoration  of democracy  will guarantee  peace for the county",
        "word_AM": "ዴሞክራሲን ማስፈን  ለሀገር ስላም ያስገኛል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62508,
        "word_AF": "qadaaga",
        "word_ENG": "market",
        "word_AM": "ገበያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62550,
        "word_AF": "rihimi",
        "word_ENG": "marriage",
        "word_AM": "ጋብቻ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62592,
        "word_AF": "safar wakaaata",
        "word_ENG": "travel agency ",
        "word_AM": "ገዞ ወኪል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62634,
        "word_AF": "qadaagâ makeelisé",
        "word_ENG": "market analysis ",
        "word_AM": "ገበያ ተንታኝ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62676,
        "word_AF": "boodu",
        "word_ENG": "infringement ",
        "word_AM": "ግጭት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62718,
        "word_AF": "sahadayytí migaaqat tabu",
        "word_ENG": "affect  the dignity of the person",
        "word_AM": "ግለስብ ክብር መንካት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62760,
        "word_AF": "gifto",
        "word_ENG": "august",
        "word_AM": "ግርማ ሞገስ ያለው",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62802,
        "word_AF": "korsí gabbatu",
        "word_ENG": "coup d'etat attempt ",
        "word_AM": "ግልበጣ ሙከራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62844,
        "word_AF": "malakmisiinu",
        "word_ENG": "arbitration ",
        "word_AM": "ገላጋይነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62886,
        "word_AF": "malakmisé",
        "word_ENG": "arbitrator",
        "word_AM": "ገላጋይ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62928,
        "word_AF": "digifi",
        "word_ENG": "murder ",
        "word_AM": "ግድያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 62970,
        "word_AF": "soola casbi",
        "word_ENG": "house  arrest",
        "word_AM": "ግዞት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63012,
        "word_AF": "waqin gita",
        "word_ENG": "avenue ",
        "word_AM": "ጎዳና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63054,
        "word_AF": "dubeyna",
        "word_ENG": "baker",
        "word_AM": "ጋጋሪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63096,
        "word_AF": "fidnin gita",
        "word_ENG": "boulevard ",
        "word_AM": "ጎዳና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63138,
        "word_AF": "awaya",
        "word_ENG": "fog",
        "word_AM": "ጉም /ጭጋግ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63180,
        "word_AF": "yessegellen raasal maala",
        "word_ENG": "social  capital ",
        "word_AM": "ጋራ ካፒታል/የ/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63222,
        "word_AF": "maqal ittingeyi",
        "word_ENG": "cartel",
        "word_AM": "ጋራ/ የ/ሥራ ህብረት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63264,
        "word_AF": "guri caylitteh ittingeyi",
        "word_ENG": "cartel of the left",
        "word_AM": "ግራ ሀይሎች ስምምነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63306,
        "word_AF": "caagid yagdubi",
        "word_ENG": "executive  officer ",
        "word_AM": "ጉዳይ አስፈፃሚ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63348,
        "word_AF": "culô yoofenta",
        "word_ENG": "ware house warrant ",
        "word_AM": "ገቢ ደረስኝ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63390,
        "word_AF": "xaagi mayyaaqa",
        "word_ENG": "press release ",
        "word_AM": "ጋዜጣዊ መግለጫ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63432,
        "word_AF": "gargara",
        "word_ENG": "accomplice",
        "word_AM": "ግብረ-አበር /የወንጀል /",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63474,
        "word_AF": "cemidi dudda",
        "word_ENG": "comprehensibility",
        "word_AM": "ግንዛቤ ችሎታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63516,
        "word_AF": "tut radimi",
        "word_ENG": "understanding ",
        "word_AM": "ግንዛቤ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63558,
        "word_AF": "liki bukne",
        "word_ENG": "mass graves",
        "word_AM": "የጋራ መቃብር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63600,
        "word_AF": "kalqata",
        "word_ENG": "castle ",
        "word_AM": "ግንብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63642,
        "word_AF": "waklisso",
        "word_ENG": "collaboration ",
        "word_AM": "ግብረአበርነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63684,
        "word_AF": "yangalen guddaqta",
        "word_ENG": "collectivity",
        "word_AM": "ጋራ /የ/ስፈር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63726,
        "word_AF": "caglô kiliniiki",
        "word_ENG": "private  hospital ",
        "word_AM": "ግል/የ  / ክሊኒክ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63768,
        "word_AF": "culô cisaaba",
        "word_ENG": "credit  account ",
        "word_AM": "ገቢ ሂሳብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63810,
        "word_AF": "koboxu",
        "word_ENG": "conference ",
        "word_AM": "ጉባኤ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63852,
        "word_AF": "ittin waya",
        "word_ENG": "conflict ",
        "word_AM": "ግጭት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63894,
        "word_AF": "qarsâ boodu",
        "word_ENG": "confortation",
        "word_AM": "ግጥሚያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63936,
        "word_AF": "qiso mekele",
        "word_ENG": "tax payer",
        "word_AM": "ግብር ከፋይ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 63978,
        "word_AF": "gibdaabina",
        "word_ENG": "disadvantege",
        "word_AM": "ጉዳት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64020,
        "word_AF": "fanti eleecaboyta",
        "word_ENG": "semi final ",
        "word_AM": "ግማሽ /የ/ፍፃሜ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64062,
        "word_AF": "numtin-amo xexxaara",
        "word_ENG": "private domains ",
        "word_AM": "ግል ግዛት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64104,
        "word_AF": "lakqô mellebih tawwa",
        "word_ENG": "devaluation",
        "word_AM": "ገንዘብ /የ  /ዋጋ ቅነሳ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64146,
        "word_AF": "lakqo",
        "word_ENG": "money",
        "word_AM": "ገንዘብ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64188,
        "word_AF": "dirki",
        "word_ENG": "obligation  ",
        "word_AM": "ግዴታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64230,
        "word_AF": "baxxaqisso",
        "word_ENG": "express  ",
        "word_AM": "ገለፃ /ዘገባ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64272,
        "word_AF": "boodu",
        "word_ENG": "confrontation",
        "word_AM": "ግጭት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64314,
        "word_AF": "yangalen madqa",
        "word_ENG": "common law",
        "word_AM": "ጋራ ደንብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64356,
        "word_AF": "innih exce",
        "word_ENG": "dogmatic",
        "word_AM": "ግትር /ቀኖነዊ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64398,
        "word_AF": "xexxaara",
        "word_ENG": "domain",
        "word_AM": "ግዛት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64440,
        "word_AF": "safarsumaqta",
        "word_ENG": "document  of journey ",
        "word_AM": "ጉዞ ዶክመንት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64482,
        "word_AF": "karada",
        "word_ENG": "customs officer ",
        "word_AM": "ጉምሩክ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64524,
        "word_AF": "uddur amarraqa",
        "word_ENG": "expiry date",
        "word_AM": "ጊዜ ማብቂያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64566,
        "word_AF": "karraara",
        "word_ENG": "echo",
        "word_AM": "ገደል ማሚቶ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64608,
        "word_AF": "kaslê-baritto",
        "word_ENG": "education  of adults ",
        "word_AM": "ጎልማሶች ት/ት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64650,
        "word_AF": "maybalaalaqâ qunturta",
        "word_ENG": "to choke press",
        "word_AM": "ጋዜጣ ነፃነት ማፈን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64692,
        "word_AF": "qisô-elle raddi",
        "word_ENG": "to be lieble of taxation",
        "word_AM": "ግብር የሚጣልባቸው ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64734,
        "word_AF": "taddiira",
        "word_ENG": "time table ",
        "word_AM": "ጊዜ ስሌዳ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64776,
        "word_AF": "riigmilaagih mellebi",
        "word_ENG": "stock exchange  value ",
        "word_AM": "ገበያ ምንዛሬ ዋጋ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64818,
        "word_AF": "fiirissô maktaba",
        "word_ENG": "editorial  staff",
        "word_AM": "ጋዜጣ አዘጋጆች",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64860,
        "word_AF": "agday le abootu",
        "word_ENG": "dominating role ",
        "word_AM": "ጋዥ ሚና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64902,
        "word_AF": "qeela",
        "word_ENG": "drilling  hole",
        "word_AM": "ጉድጓድ መቆፈር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64944,
        "word_AF": "axayso",
        "word_ENG": "aquaintance",
        "word_AM": "ግንኙነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 64986,
        "word_AF": "qarsa",
        "word_ENG": "forehead(front )",
        "word_AM": "ግንባር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65028,
        "word_AF": "garaaja",
        "word_ENG": "garage ",
        "word_AM": "ጋራጅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65070,
        "word_AF": "garaajli",
        "word_ENG": "garage  owner ",
        "word_AM": "ጋራጅ ባለቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65112,
        "word_AF": "arkeyna sibaabaytu",
        "word_ENG": "goal keeper",
        "word_AM": "ግብ ጠባቂ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65154,
        "word_AF": "baaddoyso",
        "word_ENG": "globalization",
        "word_AM": "ግሎባላይዜሽን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65196,
        "word_AF": "gaaza",
        "word_ENG": "gas",
        "word_AM": "ጋዝ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65238,
        "word_AF": "akkala",
        "word_ENG": "estimation ",
        "word_AM": "ግምት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65280,
        "word_AF": "caglitfayxi",
        "word_ENG": "individualism",
        "word_AM": "ግላዊነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65322,
        "word_AF": "numtinamo",
        "word_ENG": "individual ",
        "word_AM": "ግለስብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65364,
        "word_AF": "ololi",
        "word_ENG": "bursar",
        "word_AM": "ገንዘብ ያዥ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65406,
        "word_AF": "weeqa",
        "word_ENG": "flood ",
        "word_AM": "ጎርፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65448,
        "word_AF": "kokkobi girah  gabbatih waaso",
        "word_ENG": " suspension total of nuclear  experiences",
        "word_AM": "ንክሌር ሙከራ ማገድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65490,
        "word_AF": "maybalaalaqa",
        "word_ENG": "newspaper ",
        "word_AM": "ጋዜጣ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65532,
        "word_AF": "maybalaalaqiino",
        "word_ENG": "journalism ",
        "word_AM": "ጋዜጤኛነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65574,
        "word_AF": "yaybalaaqi",
        "word_ENG": "journalist ",
        "word_AM": "ጋዜጠኛ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65616,
        "word_AF": "deeqo",
        "word_ENG": "invitation ",
        "word_AM": "ግብዣ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65658,
        "word_AF": "malakmisannu",
        "word_ENG": "neutrality",
        "word_AM": "ገለልተኝነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65700,
        "word_AF": "malakmisannu",
        "word_ENG": "neural ",
        "word_AM": "ገለልተኛ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65742,
        "word_AF": "umaaneli",
        "word_ENG": "harmful ",
        "word_AM": "ጎጂ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65784,
        "word_AF": "dirki",
        "word_ENG": "obligation ",
        "word_AM": "ግዴታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65826,
        "word_AF": "caarrâ-sinna",
        "word_ENG": "carelessness",
        "word_AM": "ግድ የለሽነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65868,
        "word_AF": "meleekiyyâ saaqata",
        "word_ENG": "pendulum o'clock ",
        "word_AM": "ግድግዳ ስዓት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65910,
        "word_AF": "meqe mara",
        "word_ENG": "moral person ",
        "word_AM": "ግብረ ገብ ሰዎች ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65952,
        "word_AF": "bako",
        "word_ENG": "massacre",
        "word_AM": "ጅምላ ግድያ /ፍጅት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 65994,
        "word_AF": "barri dula",
        "word_ENG": "rural exodus",
        "word_AM": "ገጠር ስዴት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66036,
        "word_AF": "yangalen meerraytu",
        "word_ENG": "public  transport",
        "word_AM": "ጋራ ማመላለሻ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66078,
        "word_AF": "qidi",
        "word_ENG": "transparency ",
        "word_AM": "ግልፅነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66120,
        "word_AF": "arcisiyya",
        "word_ENG": "shot in purposes  ",
        "word_AM": "ግብ መምታት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66162,
        "word_AF": "buqre abeyna",
        "word_ENG": "farmer",
        "word_AM": "ገበሬ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66204,
        "word_AF": "gufne",
        "word_ENG": "vist ",
        "word_AM": "ጉብኝት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66246,
        "word_AF": "boolo",
        "word_ENG": "cliff ",
        "word_AM": "ገደል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66288,
        "word_AF": "qalli fantaaxawa",
        "word_ENG": "relationship",
        "word_AM": "ግንኙነት ትስስር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66330,
        "word_AF": "qadaagah addittino",
        "word_ENG": " contents of market",
        "word_AM": "ገበያ ይዘት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66372,
        "word_AF": "rakaakáy wano",
        "word_ENG": "territory ",
        "word_AM": "ግዛት ክልል /አገር ክልል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66414,
        "word_AF": "culenti karata",
        "word_ENG": "income tax",
        "word_AM": "ገበያ /የ/የቀረጥ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66456,
        "word_AF": "qaddoowiyya",
        "word_ENG": "transparency ",
        "word_AM": "ግልጽነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66498,
        "word_AF": "angaaraw male",
        "word_ENG": "without relation ",
        "word_AM": "ግንኙነት አልባ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66540,
        "word_AF": "culenta",
        "word_ENG": "incomes",
        "word_AM": "ገበዎች",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66582,
        "word_AF": "hunun xaagu",
        "word_ENG": "express ",
        "word_AM": "ገለፃ /ዘገባ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66624,
        "word_AF": "boodu",
        "word_ENG": "conflict ",
        "word_AM": "ግጭት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66666,
        "word_AF": "ikoytâ kobooni",
        "word_ENG": "private  company sector ",
        "word_AM": "ግል ካምፓኒ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66708,
        "word_AF": "numtinamoh exxah madduru",
        "word_ENG": "private  sector ",
        "word_AM": "ግል ክፍለ ኢኮኖሚ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66750,
        "word_AF": "qidim",
        "word_ENG": "murder ",
        "word_AM": "ግድያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66792,
        "word_AF": "kedo miliisiya",
        "word_ENG": "militia of clan",
        "word_AM": "ጎሳ ሚሊሺያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66834,
        "word_AF": "koo,qideyyo mataaka",
        "word_ENG": "threaten with death",
        "word_AM": "ግድያ ዛቻ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66876,
        "word_AF": "qadaaga",
        "word_ENG": "market",
        "word_AM": "ገበያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66918,
        "word_AF": "masu",
        "word_ENG": "mass",
        "word_AM": "ግዙፍነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 66960,
        "word_AF": "raddiisimi",
        "word_ENG": "match",
        "word_AM": "ግጥሚያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67002,
        "word_AF": "garbô madqa",
        "word_ENG": "law of the jungle ",
        "word_AM": "ጉልበት ህግ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67044,
        "word_AF": "qandeh ayblalaalaqah hittâ luk aban aqakkana",
        "word_ENG": "combined",
        "word_AM": "ጋራ/የ/ ልምምድ /የጦር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67086,
        "word_AF": "guri gali",
        "word_ENG": "left side",
        "word_AM": "ግራ ክንፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67128,
        "word_AF": "xaahi xiseyna",
        "word_ENG": "mason",
        "word_AM": "ግንብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67170,
        "word_AF": "xaak xisne",
        "word_ENG": "masonry",
        "word_AM": "ግንባት ከድንጋይ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67212,
        "word_AF": "cayli tama",
        "word_ENG": "labour ",
        "word_AM": "ጉልበት ሥራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67254,
        "word_AF": "qaasir umo",
        "word_ENG": "misfortune",
        "word_AM": "ገደቢስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67296,
        "word_AF": "finqi abto",
        "word_ENG": "act of vandalism",
        "word_AM": "ጥፋት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67338,
        "word_AF": "dambié",
        "word_ENG": "repair  man",
        "word_AM": "ጠጋኝ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67380,
        "word_AF": "dooda",
        "word_ENG": "conglomeration",
        "word_AM": "ጥርቃሚ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67422,
        "word_AF": "esser oggpôliyya",
        "word_ENG": "to approve  a demand ",
        "word_AM": "ጥያቄ መቀበል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67464,
        "word_AF": "dumaaho",
        "word_ENG": "antiquity",
        "word_AM": "ጥንታዊ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67506,
        "word_AF": "seeco",
        "word_ENG": "call",
        "word_AM": "ጥሪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67548,
        "word_AF": "koosit silaaca",
        "word_ENG": "armament",
        "word_AM": "ጦር መሳሪያ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67590,
        "word_AF": "haddaada",
        "word_ENG": "art",
        "word_AM": "ጥበብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67632,
        "word_AF": "baqtiinu",
        "word_ENG": "artist ",
        "word_AM": "ጥበበኛ: ባለ እጅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67674,
        "word_AF": "abakaato",
        "word_ENG": "lawyer ",
        "word_AM": "ጠበቃ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67716,
        "word_AF": "amoladiy fayda",
        "word_ENG": "gross  profit ",
        "word_AM": "ጥቅል ትርፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67758,
        "word_AF": "naharsi malaakih horta",
        "word_ENG": "prime ministers staff",
        "word_AM": "ጠቅላይ  ሚ/ር /የ/ቢሮ ሠራተኞች ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67800,
        "word_AF": "cawal ayfaafayih riigi",
        "word_ENG": "national box of pension",
        "word_AM": "ጡረታ /የ/ተቀማጭ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67842,
        "word_AF": "qado lakqo",
        "word_ENG": "liquid  capital ",
        "word_AM": "ጥሬ ገንዘብ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67884,
        "word_AF": "kusaaqaay xaaguu kee murti fanteena",
        "word_ENG": "center  of search information and production ",
        "word_AM": "ጥናት /የ/የመረጃና የምርት ማዕከል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67926,
        "word_AF": "qaafiyat fanteena",
        "word_ENG": "health center ",
        "word_AM": "ጤና ማዕከል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 67968,
        "word_AF": "maaqiita",
        "word_ENG": "cereal",
        "word_AM": "ጥራጥሬ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68010,
        "word_AF": "sibaabaytu",
        "word_ENG": "quotation",
        "word_AM": "ጥቅስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68052,
        "word_AF": "sangera",
        "word_ENG": "caretaker",
        "word_AM": "ጠባቂ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68094,
        "word_AF": "seeco",
        "word_ENG": "summons",
        "word_AM": "ጥሪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68136,
        "word_AF": "dagaraqa sungerra",
        "word_ENG": "superm cort",
        "word_AM": "ጠቅላይ  ፍ/ድ/ቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68178,
        "word_AF": "essero",
        "word_ENG": "demand ",
        "word_AM": "ጥያቄ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68220,
        "word_AF": "dabbô qikiti",
        "word_ENG": "applicant  of asylum ",
        "word_AM": "ጥገኝነት/ስፈር/የ/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68262,
        "word_AF": "moddin daylisé",
        "word_ENG": "dentist",
        "word_AM": "ጥርስ ሃኪም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68304,
        "word_AF": "moddin daylih araca",
        "word_ENG": "dentistry",
        "word_AM": "ጥርስ ሃኪም ቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68346,
        "word_AF": "wataba",
        "word_ENG": "repair ",
        "word_AM": "ጥገና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68388,
        "word_AF": "rugustiino",
        "word_ENG": "dependence ",
        "word_AM": "ጥገኝነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68430,
        "word_AF": "ixxaage",
        "word_ENG": "disaster ",
        "word_AM": "ጥፋት መቅሰፍት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68472,
        "word_AF": "qebti addah ceelewayto",
        "word_ENG": "wara crime  ",
        "word_AM": "ጦር ወንጀል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68514,
        "word_AF": "qaafiyata",
        "word_ENG": "healthiness",
        "word_AM": "ጤንነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68556,
        "word_AF": "qaafiyat ayfaafaya",
        "word_ENG": "health  service ",
        "word_AM": "ጤና አገልግሎት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68598,
        "word_AF": "awlaytu",
        "word_ENG": "guardian",
        "word_AM": "ጠባቂ; ሞግዚት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68640,
        "word_AF": "xoqoysili",
        "word_ENG": "useful ",
        "word_AM": "ጠቃሚ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68682,
        "word_AF": "cawal affaafaya",
        "word_ENG": "pension ",
        "word_AM": "ጡረታ አበል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68724,
        "word_AF": "cawal affaafayli",
        "word_ENG": "pensioner",
        "word_AM": "ጡረተኛ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68766,
        "word_AF": "macatta",
        "word_ENG": "station ",
        "word_AM": "ጣቢያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68808,
        "word_AF": "essero",
        "word_ENG": "quotation",
        "word_AM": "ጥያቄ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68850,
        "word_AF": "amolladi daffeyna",
        "word_ENG": "plenary session ",
        "word_AM": "ጠቅላላ ስብስባ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68892,
        "word_AF": "baacata",
        "word_ENG": "in open sea",
        "word_AM": "ጥልቀት ያለው ባህር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68934,
        "word_AF": "naqboyta",
        "word_ENG": "enemy",
        "word_AM": "ጠላት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 68976,
        "word_AF": "xakaba",
        "word_ENG": "maintenance ",
        "word_AM": "ጠገና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69018,
        "word_AF": "qaran waqina",
        "word_ENG": "air space",
        "word_AM": "ጠፈር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69060,
        "word_AF": "raage gaadileyta",
        "word_ENG": "war veteran",
        "word_AM": "ጦር አርበኛ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69102,
        "word_AF": "cubbuseyna",
        "word_ENG": "researcher ",
        "word_AM": "ጥናት ምርመራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69144,
        "word_AF": "sibaaba",
        "word_ENG": "guard ",
        "word_AM": "ጥበቃ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69186,
        "word_AF": "lifiqi",
        "word_ENG": "claw",
        "word_AM": "ጥፍር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69228,
        "word_AF": "ceeri",
        "word_ENG": "hostility",
        "word_AM": "ጥላቻ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69270,
        "word_AF": "qaafiyat dacayri",
        "word_ENG": "hygiene ",
        "word_AM": "ጤና አጠባበቅ ዘዴ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69312,
        "word_AF": "faduulu",
        "word_ENG": "interference ",
        "word_AM": "ጣልቃ መግባት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69354,
        "word_AF": "warara",
        "word_ENG": "raid",
        "word_AM": "ጥቃት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69396,
        "word_AF": "fanat raddo",
        "word_ENG": "intervention ",
        "word_AM": "ጣልቃ ገብነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69438,
        "word_AF": "xakakkaba",
        "word_ENG": "journalist  editor",
        "word_AM": "ጠራዥ ጋዜጠኛ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69480,
        "word_AF": "lamiysime",
        "word_ENG": "couple ",
        "word_AM": "ጥንድ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69522,
        "word_AF": "addat cule wayti",
        "word_ENG": "non interference ",
        "word_AM": "ጣልቃ አለመግባባት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69564,
        "word_AF": "cawal galto",
        "word_ENG": "pension ",
        "word_AM": "ጡረታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69606,
        "word_AF": "naharsiinó kaliti",
        "word_ENG": "failure  to give  way",
        "word_AM": "ጥሎ ማለፍ ማሳጣት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69648,
        "word_AF": "miizi",
        "word_ENG": "table ",
        "word_AM": "ጠረጴዛ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69690,
        "word_AF": "astuul",
        "word_ENG": "fleet",
        "word_AM": "ጦር መርከቦች ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69732,
        "word_AF": "macxi mallayta",
        "word_ENG": "spearhead",
        "word_AM": "ጦር ጫፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69774,
        "word_AF": "amô ladiy xongolo",
        "word_ENG": " universal  suffrage",
        "word_AM": "ጠቅላላ ድምፅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69816,
        "word_AF": "tû ladiy baxxaqisiyya",
        "word_ENG": "to stipulate advantage ",
        "word_AM": "ጥቅም ማጉላት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69858,
        "word_AF": "amô millih",
        "word_ENG": "total",
        "word_AM": "ጠቅላላ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69900,
        "word_AF": "kaxxa sitta fan gacisi",
        "word_ENG": "grand total ",
        "word_AM": "ጠቅላላ ድምር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69942,
        "word_AF": "xakabak xinkiyyo",
        "word_ENG": "maintenance ",
        "word_AM": "ጥገና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 69984,
        "word_AF": "tû xiq mangaba",
        "word_ENG": "useful  majority ",
        "word_AM": "ጠቃሚ አብላጫ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70026,
        "word_AF": "adda xer cubbi",
        "word_ENG": "consideration ",
        "word_AM": "ጥልቅ ማስብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70068,
        "word_AF": "digir miqo",
        "word_ENG": "better  prayer ",
        "word_AM": "ጥሩ ተጫዋች ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70110,
        "word_AF": "naharsi duyye",
        "word_ENG": "raw materials ",
        "word_AM": "ጥሬ ዕቃ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70152,
        "word_AF": "ossa",
        "word_ENG": "addition ",
        "word_AM": "ጭማሪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70194,
        "word_AF": "aliino",
        "word_ENG": "atrocity",
        "word_AM": "ጭካኔ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70236,
        "word_AF": "bôda",
        "word_ENG": "gonorrhea",
        "word_AM": "ጨብጥ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70278,
        "word_AF": "aliinoli",
        "word_ENG": "inhuman",
        "word_AM": "ጨካኝ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70320,
        "word_AF": "gabaa kee gaba ,gabatibbixi",
        "word_ENG": "hand-to- hand combat ",
        "word_AM": "ጨበጣ /የ/ ውጊያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70362,
        "word_AF": "haasaawa",
        "word_ENG": "conversations",
        "word_AM": "ጭውውት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70404,
        "word_AF": "tabbixsimeemi",
        "word_ENG": "data",
        "word_AM": "ጭብጥ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70446,
        "word_AF": "mulcutiyya",
        "word_ENG": "salinity",
        "word_AM": "ጨውማነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70488,
        "word_AF": "dallam mali",
        "word_ENG": "tyrant",
        "word_AM": "ጨካኝ /አምባገነን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70530,
        "word_AF": "misinkicâ qabal-gexo",
        "word_ENG": "cerebral bleeding ",
        "word_AM": "ጭንቅላት ውስጥ መድማት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70572,
        "word_AF": "xukkuté",
        "word_ENG": "oppressor",
        "word_AM": "ጨቋኝ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70614,
        "word_AF": "xukko",
        "word_ENG": "oppression",
        "word_AM": "ጭቆና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70656,
        "word_AF": "garbo argiqiyya",
        "word_ENG": "forest cutting ",
        "word_AM": "ጫካ መጥረብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70698,
        "word_AF": "sirbok rigde",
        "word_ENG": "brass band ",
        "word_AM": "ጭፈራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70740,
        "word_AF": "dirab fooca",
        "word_ENG": "mask",
        "word_AM": "ጭምብል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70782,
        "word_AF": "koros diinih saqala",
        "word_ENG": "bishop ",
        "word_AM": "ጰጰስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70824,
        "word_AF": "koros diinih amoyta",
        "word_ENG": "pope ",
        "word_AM": "ሊቀ ጳጳስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70866,
        "word_AF": "ayro",
        "word_ENG": "sun",
        "word_AM": "ፀሐይ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70908,
        "word_AF": "ayrô liggida",
        "word_ENG": "solar year",
        "word_AM": "ፀሐይ -አቆጣጠር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70950,
        "word_AF": "tayyaara-sad",
        "word_ENG": "anti- aircraft ",
        "word_AM": "ፀረ- አውሮፕላን ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 70992,
        "word_AF": "dabbaaba-sad",
        "word_ENG": "ant-tank",
        "word_AM": "ፀረ- ታንክ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71034,
        "word_AF": "doolat-sad",
        "word_ENG": "anti-government ",
        "word_AM": "ፀረ - አገዛዝ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71076,
        "word_AF": "aboolita-sad",
        "word_ENG": "anti- meridian",
        "word_AM": "ፀረ- ሜሪዲያን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71118,
        "word_AF": "baddi-gubayti-sad",
        "word_ENG": "anti-submarine",
        "word_AM": "ፀረ- ባሕር ስርጓዥ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71160,
        "word_AF": "saaya",
        "word_ENG": "security ",
        "word_AM": "ፀጥታ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71202,
        "word_AF": "maktaba",
        "word_ENG": "office ",
        "word_AM": "ፅህፈት ቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71244,
        "word_AF": "gexsiti",
        "word_ENG": "behavior ",
        "word_AM": "ፀባይ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71286,
        "word_AF": "kutbe liinoh cakki",
        "word_ENG": "copy right ",
        "word_AM": "ጽሑፍ/የ/ባለቤትነት መብት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71328,
        "word_AF": "kutbeh aalata",
        "word_ENG": "typing  machine ",
        "word_AM": "ጽሕፈት ማሽን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71370,
        "word_AF": "saytunnoysé",
        "word_ENG": "dustman",
        "word_AM": "ፅዳት ሠራተኛ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71412,
        "word_AF": "dubbutu",
        "word_ENG": "eclipse ",
        "word_AM": "ፀሐይ ግርዶሽ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71454,
        "word_AF": "aqayyaare kutbe",
        "word_ENG": "writing  test ",
        "word_AM": "ጽሁፍ/የ/ፈተና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71496,
        "word_AF": "kutbê taama abeena",
        "word_ENG": "stenographer",
        "word_AM": "ጽህፈት ሠራተኛ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71538,
        "word_AF": "makko abeyna",
        "word_ENG": "security ",
        "word_AM": "ፀሐፊ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71580,
        "word_AF": "kutbê-buxa",
        "word_ENG": "secretariat ",
        "word_AM": "ጽሕፈት ቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71622,
        "word_AF": "maktaba",
        "word_ENG": "office ",
        "word_AM": "ጽ/ቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71664,
        "word_AF": "ayroytâ caylih maknaya",
        "word_ENG": "solar  system ",
        "word_AM": "ፀሐይ ስርዓት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71706,
        "word_AF": "waado-sinna",
        "word_ENG": "extremism",
        "word_AM": "ፅንፍነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71748,
        "word_AF": "xalisso",
        "word_ENG": "fertilization",
        "word_AM": "ጽንስት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71790,
        "word_AF": "qigdu",
        "word_ENG": "absolute ",
        "word_AM": "ፍፁም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71832,
        "word_AF": "kameerali",
        "word_ENG": "camera man",
        "word_AM": "ፎቶ አንሺ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71874,
        "word_AF": "faras abbiinu",
        "word_ENG": "cavalry",
        "word_AM": "ፈረስኝነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71916,
        "word_AF": "faras abba",
        "word_ENG": "rider",
        "word_AM": "ፈረስኛ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 71958,
        "word_AF": "filim abeyna",
        "word_ENG": "film- maker",
        "word_AM": "ፈልም ስሪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72000,
        "word_AF": "filim abitto",
        "word_ENG": "cinematography",
        "word_AM": "ፈልም /የ/ሥራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72042,
        "word_AF": "faayil",
        "word_ENG": "file",
        "word_AM": "ፋይል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72084,
        "word_AF": "fermah awliinu",
        "word_ENG": "delegation of signature ",
        "word_AM": "ደርማ መወከል ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72126,
        "word_AF": "figda",
        "word_ENG": "definition ",
        "word_AM": "ፍች",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72168,
        "word_AF": "ruksat qellata",
        "word_ENG": "defect of license",
        "word_AM": "ፈቃድ ጉድለት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72210,
        "word_AF": "maaliyyah ayfaafaya",
        "word_ENG": "financial service ",
        "word_AM": "ፋይናንስ አገልግሎት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72252,
        "word_AF": "aqayyaare",
        "word_ENG": "exam",
        "word_AM": "ፈተና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72294,
        "word_AF": "fardi",
        "word_ENG": "essence ",
        "word_AM": "ፍሬ ነገር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72336,
        "word_AF": "faatuurâ bicsiyya",
        "word_ENG": "to establish an invoice ",
        "word_AM": "ፋክቱር ማዘጋጀት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72378,
        "word_AF": "bakaqa",
        "word_ENG": "eruption",
        "word_AM": "ፍንዳታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72420,
        "word_AF": "xoytó",
        "word_ENG": "dribble",
        "word_AM": "ፍሳሽ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72462,
        "word_AF": "mayrawwaca",
        "word_ENG": "ventilator",
        "word_AM": "ፋን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72504,
        "word_AF": "maali goranto",
        "word_ENG": "search for fund",
        "word_AM": "ፈንድ ፍለጋ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72546,
        "word_AF": "feederaal ummuuno",
        "word_ENG": "federal  republic ",
        "word_AM": "ፌዴራላዊ ሪፐብሊክ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72588,
        "word_AF": "anaakara",
        "word_ENG": "rivalry",
        "word_AM": "ፋክክር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72630,
        "word_AF": "fabrika",
        "word_ENG": "factory ",
        "word_AM": "ፋብሪካ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72672,
        "word_AF": "xacaaca",
        "word_ENG": "relief ",
        "word_AM": "ፋታ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72714,
        "word_AF": "foxô -digloh iisa",
        "word_ENG": "forfeit",
        "word_AM": "ፎርፌ/በፎርፌ መሽነፍ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72756,
        "word_AF": "agaaradangaarawih araca",
        "word_ENG": "forum ",
        "word_AM": "ፎረም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72798,
        "word_AF": "faransaawih afat yaabé",
        "word_ENG": "french speaker ",
        "word_AM": "ፈረንሳይኛ ተናጋሪ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72840,
        "word_AF": "faransaniqbo",
        "word_ENG": "francophobia",
        "word_AM": "ፈረንሳይ የሚጠላ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72882,
        "word_AF": "faransakicini",
        "word_ENG": "francophile",
        "word_AM": "ፈረንሳይ ወዳጅ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72924,
        "word_AF": "caxfexxa",
        "word_ENG": "fruit",
        "word_AM": "ፍራፍሬ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 72966,
        "word_AF": "qadli malaaka",
        "word_ENG": "minister of justice ",
        "word_AM": "ፍትህ ሚ/ር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73008,
        "word_AF": "fabrikâ daabisso",
        "word_ENG": "implanting of a factory ",
        "word_AM": "ፋብሪካ ተከለ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73050,
        "word_AF": "qadaalat sinna",
        "word_ENG": "injustice",
        "word_AM": "ፋትህ አለመኖር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73092,
        "word_AF": "caxá",
        "word_ENG": "jury",
        "word_AM": "ፍርድ ሽንጎ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73134,
        "word_AF": "qadaalata",
        "word_ENG": "justice ",
        "word_AM": "ፍትህ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73176,
        "word_AF": "mooda bilqa",
        "word_ENG": "mode ",
        "word_AM": "ፋሽን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73218,
        "word_AF": "anqaasa",
        "word_ENG": "mockery",
        "word_AM": "ፌዝ መሳለቂያ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73260,
        "word_AF": "taswiiri",
        "word_ENG": "photo ",
        "word_AM": "ፎቶ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73302,
        "word_AF": "taswiir kora",
        "word_ENG": "photo copy",
        "word_AM": "ፎቶ ኮፒ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73344,
        "word_AF": "taswiir abe",
        "word_ENG": "photographer ",
        "word_AM": "ፎቶ አንሺ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73386,
        "word_AF": "falsafata",
        "word_ENG": "philosophy ",
        "word_AM": "ፍልስፍና",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73428,
        "word_AF": "ellecabo raddiisimi",
        "word_ENG": "contest of final",
        "word_AM": "ፍፃሜ ግጥሚያ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73470,
        "word_AF": "mizaaniyyat madqa",
        "word_ENG": "finance act",
        "word_AM": "ፋይናንስ ደንብ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73512,
        "word_AF": "caxá",
        "word_ENG": "court",
        "word_AM": "ፍርድ ቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73554,
        "word_AF": "ixxo",
        "word_ENG": "exploration ",
        "word_AM": "ፍለጋ አሳሽነት ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73596,
        "word_AF": "ixxiteyna",
        "word_ENG": "explorer ",
        "word_AM": "ፈላጊ አስች",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73638,
        "word_AF": "gaamiqat exxa",
        "word_ENG": "faculty ",
        "word_AM": "ፋካሊቲ /ዩኒቨርሲቲ ክልል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73680,
        "word_AF": "tallaaja",
        "word_ENG": "fridge ",
        "word_AM": "ፍሪጅ ማቀዝቀዣ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73722,
        "word_AF": "sissikaane",
        "word_ENG": "speed ",
        "word_AM": "ፍጥነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73764,
        "word_AF": "mallagle",
        "word_ENG": "volunteer",
        "word_AM": "ፈቃደኛ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73806,
        "word_AF": "raabiti labbatiinô farani",
        "word_ENG": "voluntary service ",
        "word_AM": "ፍቃደኝነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73848,
        "word_AF": "faksi",
        "word_ENG": "fax",
        "word_AM": "ፋክስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73890,
        "word_AF": "federaal",
        "word_ENG": "federal",
        "word_AM": "ፌዴራል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73932,
        "word_AF": "federeysiino",
        "word_ENG": "federalism",
        "word_AM": "ፌዴራሊዝም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 73974,
        "word_AF": "federaalinnu",
        "word_ENG": "federation  ",
        "word_AM": "ፌዴሬሽን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74016,
        "word_AF": "filmi",
        "word_ENG": "film",
        "word_AM": "ፈልም",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74058,
        "word_AF": "maaliyya",
        "word_ENG": "finance ",
        "word_AM": "ፋይናንስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74100,
        "word_AF": "foocak",
        "word_ENG": "face to face",
        "word_AM": "ፈት ለፈት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74142,
        "word_AF": "faatuura",
        "word_ENG": "invoice ",
        "word_AM": "ፋክቱር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74184,
        "word_AF": "siyaasâ sinnaane",
        "word_ENG": "non political ",
        "word_AM": "ፓለቲካ አልባነት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74226,
        "word_AF": "siyaasâ megloh araca",
        "word_ENG": "political  asylum ",
        "word_AM": "ፓለቲካ ጥገኝነት ስፍራ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74268,
        "word_AF": "pérezidaan amir",
        "word_ENG": "presidential  order",
        "word_AM": "ፕሬዝዳንታዊ ትዕዛዝ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74310,
        "word_AF": "poliis awliseyna",
        "word_ENG": "police  commisser",
        "word_AM": "ፓሊስ ኮሚሽነር",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74352,
        "word_AF": "poliis awliseyenta",
        "word_ENG": "police supreperintendent",
        "word_AM": "ፓሊስ ኮሚሽን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74394,
        "word_AF": "barlaamah adoyta",
        "word_ENG": "deputy ",
        "word_AM": "ፓርላማ አባል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74436,
        "word_AF": "konnabâ",
        "word_ENG": "protocol ",
        "word_AM": "ፕሮቶኮል",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74478,
        "word_AF": "baaxô bagih laqnah ossima",
        "word_ENG": "warming up of  the planet ",
        "word_AM": "ፕላኔት ሙቀት መጨመር ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74520,
        "word_AF": "siyaasâ-baro",
        "word_ENG": "political  solution ",
        "word_AM": "ፓለቲካዊ መፍትሄ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74562,
        "word_AF": "siyaasâ-qeegu",
        "word_ENG": "political  tendencies",
        "word_AM": "ፓለቲካ ዝንባሌ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74604,
        "word_AF": "saaqoota",
        "word_ENG": "schedule  protocol ",
        "word_AM": "ፕሮግራም /የጊዜ ሰሌዳ/",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74646,
        "word_AF": "tarmuusa",
        "word_ENG": "isotherm",
        "word_AM": "ፔርሙስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74688,
        "word_AF": "pasfik baddiida kaxxa-bada",
        "word_ENG": "pacific  ocean ",
        "word_AM": "ፓስፈክ ውቅያኖስ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74730,
        "word_AF": "agoobara",
        "word_ENG": "parachute",
        "word_AM": "ፓራሹት/ የአየር መዝለያ ጃንጥላ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74772,
        "word_AF": "miglisi",
        "word_ENG": "parliament ",
        "word_AM": "ፓርላማ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74814,
        "word_AF": "cizbi",
        "word_ENG": "party",
        "word_AM": "ፓርቲ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74856,
        "word_AF": "syaasâ xiso",
        "word_ENG": "political  party",
        "word_AM": "ፓለቲካ ፓርቲ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74898,
        "word_AF": "pazaporto",
        "word_ENG": "passport  plan",
        "word_AM": "ፓስፓርትፕላን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74940,
        "word_AF": "ekraaro",
        "word_ENG": "plan",
        "word_AM": "ፕላን",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 74982,
        "word_AF": "pilaaneeti",
        "word_ENG": "planet ",
        "word_AM": "ፕላኔት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 75024,
        "word_AF": "siyaasâ",
        "word_ENG": "politics ",
        "word_AM": "ፓለቲካ  ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 75066,
        "word_AF": "posta buxa",
        "word_ENG": "post office ",
        "word_AM": "ፓስታ ቤት",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 75108,
        "word_AF": "postâ taama",
        "word_ENG": "courier",
        "word_AM": "ፓስታ ሠራተኛ ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 75150,
        "word_AF": "siyaasâ dabboyta",
        "word_ENG": "polic exiled",
        "word_AM": "ፓለቲካ ስደተኛ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 75192,
        "word_AF": "postâ farmoyta",
        "word_ENG": "post man",
        "word_AM": "ፓስታ ተላላኪ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    },
    {
        "id": 75234,
        "word_AF": "baaxoh abbah awliino",
        "word_ENG": "presidential  manda",
        "word_AM": "ፕሬዝደንታዊ  ውክልና ",
        "tryOutAudioFile": "",
        "synonyms": [

        ],
        "isInDictionary": true,
        "hasTryOutAudioFile": false,
        "antonyms": [
            ""
        ],
        "defination": ""
    }
];

export default data;