/* Redux saga class
 * logins the user into the app
 * requires username and password.
 * un - username
 * pwd - password
 */
import { put, call, select } from 'redux-saga/effects';
import { delay } from 'redux-saga';

import { Alert } from 'react-native';
// import loginUser from 'app/api/methods/loginUser';
import * as dataActions from '../actions/dataActions';
import * as loaderActions from '../actions/loaderActions';
import data from '../assets/data';
import * as navigationActions from '../actions/navigationActions';

// Our worker Saga that logins the user
export default function* loadData() {
    yield put(loaderActions.enableLoader());

    yield put(dataActions.handleLoadingDataSuccess(data));
    yield put(loaderActions.disableLoader({}));
    yield call(navigationActions.navigateToHome);
}
